-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Dim 15 Septembre 2013 à 00:24
-- Version du serveur: 5.1.41
-- Version de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT=0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `db489062710`
--

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_ajaxdemo_colour`
--

DROP TABLE IF EXISTS `m5jbw_ajaxdemo_colour`;
CREATE TABLE IF NOT EXISTS `m5jbw_ajaxdemo_colour` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `colour_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` int(1) NOT NULL,
  `dflt` int(1) NOT NULL,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `main_image` varchar(100) NOT NULL,
  `thumbnail_image` varchar(100) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `m5jbw_ajaxdemo_colour`
--

INSERT INTO `m5jbw_ajaxdemo_colour` (`id`, `colour_id`, `ordering`, `published`, `dflt`, `title`, `alias`, `main_image`, `thumbnail_image`, `notes`) VALUES
(1, 1, 0, 1, 1, 'Red1', 'red1', 'red1.png', 'red1_t.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eleifend egestas nulla at lobortis. Integer placerat, nunc pharetra varius sagittis.'),
(2, 1, 1, 1, 0, 'Red2', 'red2', 'red2.png', 'red2_t.png', 'Velit eros congue risus, sit amet volutpat ipsum tortor imperdiet justo. Cras faucibus, urna non cursus porttitor, nunc nibh ornare lacus, sit amet posuere nisi lectus in metus. Cras pulvinar sodales mauris porta semper. Proin magna odio, egestas in euismod sed.'),
(3, 1, 2, 1, 0, 'Red3', 'red2', 'red3.png', 'red3_t.png', 'Consequat vel orci. Donec lacinia ligula justo, sed venenatis neque. Curabitur tempor, nulla vel gravida elementum, justo nulla posuere libero, eget convallis augue massa ac purus. Praesent tempor nibh sit amet diam gravida vitae rhoncus est placerat. Sed porttitor vehicula mauris.'),
(4, 2, 0, 1, 1, 'Orange1', 'orange1', 'orange1.png', 'orange1_t.png', 'Eget feugiat augue aliquam ut. Nam odio mi, consectetur sit amet accumsan eget, pretium porta mauris. Maecenas mollis.'),
(5, 2, 1, 1, 0, 'Orange2', 'orange2', 'orange2.png', 'orange2_t.png', 'Elit vel vulputate suscipit, ligula dui euismod dolor, condimentum accumsan diam urna nec mauris. Donec condimentum consequat dui.'),
(6, 2, 2, 1, 0, 'Orange3', 'orange3', 'orange3.png', 'orange3_t.png', 'Vitae aliquet libero congue eu. Vestibulum tristique lobortis ipsum, a varius neque lobortis nec. Morbi ac ullamcorper est.'),
(7, 3, 0, 1, 1, 'Yellow1', 'yellow1', 'yellow1.png', 'yellow1_t.png', 'Nunc dictum tempor diam in porttitor.'),
(8, 3, 1, 1, 0, 'Yellow2', 'yellow2', 'yellow2.png', 'yellow2_t.png', 'Praesent ultricies nisl non elit eleifend eu tincidunt mauris sodales. Phasellus at ligula magna. Praesent et libero nec nulla consequat scelerisque.'),
(9, 3, 2, 1, 0, 'Yellow3', 'yellow3', 'yellow3.png', 'yellow3_t.png', 'Sed eget massa commodo mauris scelerisque ullamcorper. Quisque id gravida ante. Etiam vulputate metus odio. Curabitur egestas sapien in erat tempor accumsan.'),
(10, 4, 0, 1, 1, 'Green1', 'green1', 'green1.png', 'green1_t.png', 'Nunc justo augue, dapibus vitae ullamcorper non, malesuada vitae quam. Pellentesque adipiscing iaculis nibh sit amet pretium.'),
(11, 4, 1, 1, 0, 'Green2', 'green2', 'green2.png', 'green2_t.png', 'Vestibulum vel consectetur augue. Nunc non velit vitae lorem elementum rhoncus eu id dolor. Sed pretium sagittis purus sed ultricies.'),
(12, 4, 2, 1, 0, 'Green3', 'green3', 'green3.png', 'green3_t.png', 'Sed adipiscing, lectus placerat hendrerit pulvinar, massa ipsum posuere nunc, et aliquam magna erat eu turpis.'),
(13, 5, 0, 1, 1, 'Blue1', 'blue1', 'blue1.png', 'blue1_t.png', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.'),
(14, 5, 1, 1, 0, 'Blue2', 'blue2', 'blue2.png', 'blue2_t.png', 'Vivamus cursus malesuada sem, quis fringilla nulla lacinia et.'),
(15, 5, 2, 1, 0, 'Blue3', 'blue3', 'blue3.png', 'blue3_t.png', 'Cras id turpis quis nisl hendrerit condimentum ut nec mi. Proin dictum sem nec lorem viverra id tempus orci tincidunt.');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_ajaxdemo_colours`
--

DROP TABLE IF EXISTS `m5jbw_ajaxdemo_colours`;
CREATE TABLE IF NOT EXISTS `m5jbw_ajaxdemo_colours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` int(1) NOT NULL DEFAULT '0',
  `featured` int(1) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `notes` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `m5jbw_ajaxdemo_colours`
--

INSERT INTO `m5jbw_ajaxdemo_colours` (`id`, `ordering`, `published`, `featured`, `title`, `alias`, `notes`) VALUES
(1, 1, 1, 1, 'Red', 'red', 'Red is a colour with a wavelength of about 700–635 nm'),
(2, 2, 1, 1, 'Orange', 'orange', 'Orange is a colour with a wavelength of about 635–590 nm'),
(3, 3, 1, 1, 'Yellow', 'yellow', 'Yellow is a colour with a wavelength of about 590–560 nm'),
(4, 4, 1, 1, 'Green', 'green', 'Green is a colour with a wavelength of about 560–490 nm'),
(5, 5, 1, 1, 'Blue', 'Blue', 'Blue is a colour with a wavelength of about 490–450 nm');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_assets`
--

DROP TABLE IF EXISTS `m5jbw_assets`;
CREATE TABLE IF NOT EXISTS `m5jbw_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=177 ;

--
-- Contenu de la table `m5jbw_assets`
--

INSERT INTO `m5jbw_assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES
(1, 0, 1, 430, 0, 'root.1', 'Root Asset', '{"core.login.site":{"6":1,"2":1},"core.login.admin":{"6":1},"core.login.offline":[],"core.admin":{"8":1},"core.manage":{"7":1},"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(2, 1, 2, 3, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 4, 11, 1, 'com_banners', 'com_banners', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(4, 1, 12, 13, 1, 'com_cache', 'com_cache', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(5, 1, 14, 15, 1, 'com_checkin', 'com_checkin', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(6, 1, 16, 17, 1, 'com_config', 'com_config', '{}'),
(7, 1, 18, 87, 1, 'com_contact', 'com_contact', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(8, 1, 88, 299, 1, 'com_content', 'com_content', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(9, 1, 300, 301, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 302, 303, 1, 'com_installer', 'com_installer', '{"core.admin":[],"core.manage":{"7":0},"core.delete":{"7":0},"core.edit.state":{"7":0}}'),
(11, 1, 304, 305, 1, 'com_languages', 'com_languages', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(12, 1, 306, 307, 1, 'com_login', 'com_login', '{}'),
(13, 1, 308, 309, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 310, 311, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 312, 313, 1, 'com_media', 'com_media', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":{"5":1},"core.edit":[],"core.edit.state":[]}'),
(16, 1, 314, 315, 1, 'com_menus', 'com_menus', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(17, 1, 37, 38, 1, 'com_messages', 'com_messages', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(18, 1, 318, 319, 1, 'com_modules', 'com_modules', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(19, 1, 320, 327, 1, 'com_newsfeeds', 'com_newsfeeds', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(20, 1, 328, 329, 1, 'com_plugins', 'com_plugins', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(21, 1, 330, 331, 1, 'com_redirect', 'com_redirect', '{"core.admin":{"7":1},"core.manage":[]}'),
(22, 1, 332, 333, 1, 'com_search', 'com_search', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(23, 1, 334, 335, 1, 'com_templates', 'com_templates', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(24, 1, 336, 339, 1, 'com_users', 'com_users', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(25, 1, 340, 357, 1, 'com_weblinks', 'com_weblinks', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1,"10":0,"12":0},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}'),
(26, 1, 358, 359, 1, 'com_wrapper', 'com_wrapper', '{}'),
(33, 1, 420, 421, 1, 'com_finder', 'com_finder', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(34, 8, 105, 108, 2, 'com_content.category.9', 'Non catégorisé', '{"core.create":{"10":0,"12":0},"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(35, 3, 7, 8, 2, 'com_banners.category.10', 'Non catégorisé', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(36, 7, 23, 24, 2, 'com_contact.category.11', 'Non catégorisé', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(37, 19, 323, 324, 2, 'com_newsfeeds.category.12', 'Non catégorisé', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(38, 25, 347, 348, 2, 'com_weblinks.category.13', 'Non catégorisé', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(39, 8, 109, 298, 2, 'com_content.category.14', 'Articles exemples', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(40, 3, 9, 10, 2, 'com_banners.category.15', 'Bannières Exemples', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(41, 7, 25, 86, 2, 'com_contact.category.16', 'Exemples de contacts', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(42, 19, 325, 326, 2, 'com_newsfeeds.category.17', 'Exemples de fils d''actualité', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(43, 25, 349, 356, 2, 'com_weblinks.category.18', 'Exemples de liens web', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(44, 39, 110, 247, 3, 'com_content.category.19', 'Joomla!', '{"core.create":{"10":0,"12":0},"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(45, 44, 111, 224, 4, 'com_content.category.20', 'Extensions', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(46, 45, 112, 127, 5, 'com_content.category.21', 'Composants', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(47, 45, 128, 189, 5, 'com_content.category.22', 'Modules', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(48, 45, 190, 201, 5, 'com_content.category.23', 'Templates', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(49, 45, 202, 203, 5, 'com_content.category.24', 'Langues', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(50, 45, 204, 223, 5, 'com_content.category.25', 'Plug-ins', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(51, 39, 248, 279, 3, 'com_content.category.26', 'Site des parcs', '{"core.create":{"10":0,"12":0},"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(52, 51, 249, 254, 4, 'com_content.category.27', 'Blog des parcs', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(53, 51, 255, 276, 4, 'com_content.category.28', 'Galerie photo', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(54, 39, 280, 293, 3, 'com_content.category.29', 'Boutique de fruits', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(55, 54, 281, 286, 4, 'com_content.category.30', 'Producteurs', '{"core.create":{"12":0},"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":{"10":1}}'),
(56, 43, 350, 351, 3, 'com_weblinks.category.31', 'Liens de parcs', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(57, 43, 352, 355, 3, 'com_weblinks.category.32', 'Liens Joomla!', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(58, 57, 353, 354, 4, 'com_weblinks.category.33', 'Autres ressources', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(59, 41, 26, 27, 3, 'com_contact.category.34', 'Site des parcs', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(60, 41, 28, 85, 3, 'com_contact.category.35', 'Boutique de fruits', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(61, 60, 29, 30, 4, 'com_contact.category.36', 'Notre personnel', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(62, 60, 31, 84, 4, 'com_contact.category.37', 'Encyclopédie des fruits', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(63, 62, 32, 33, 5, 'com_contact.category.38', 'A', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(64, 62, 34, 35, 5, 'com_contact.category.39', 'B', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(65, 62, 36, 37, 5, 'com_contact.category.40', 'C', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(66, 62, 38, 39, 5, 'com_contact.category.41', 'D', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(67, 62, 40, 41, 5, 'com_contact.category.42', 'E', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(68, 62, 42, 43, 5, 'com_contact.category.43', 'F', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(69, 62, 44, 45, 5, 'com_contact.category.44', 'G', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(70, 62, 46, 47, 5, 'com_contact.category.45', 'H', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(71, 62, 48, 49, 5, 'com_contact.category.46', 'I', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(72, 62, 50, 51, 5, 'com_contact.category.47', 'J', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(73, 62, 52, 53, 5, 'com_contact.category.48', 'K', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(74, 62, 54, 55, 5, 'com_contact.category.49', 'L', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(75, 62, 56, 57, 5, 'com_contact.category.50', 'M', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(76, 62, 58, 59, 5, 'com_contact.category.51', 'N', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(77, 62, 60, 61, 5, 'com_contact.category.52', 'O', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(78, 62, 62, 63, 5, 'com_contact.category.53', 'P', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(79, 62, 64, 65, 5, 'com_contact.category.54', 'Q', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(80, 62, 66, 67, 5, 'com_contact.category.55', 'R', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(81, 62, 68, 69, 5, 'com_contact.category.56', 'S', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(82, 62, 70, 71, 5, 'com_contact.category.57', 'T', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(83, 62, 72, 73, 5, 'com_contact.category.58', 'U', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(84, 62, 74, 75, 5, 'com_contact.category.59', 'V', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(85, 62, 76, 77, 5, 'com_contact.category.60', 'W', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(86, 62, 78, 79, 5, 'com_contact.category.61', 'X', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(87, 62, 80, 81, 5, 'com_contact.category.62', 'Y', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(88, 62, 82, 83, 5, 'com_contact.category.63', 'Z', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(89, 46, 113, 114, 6, 'com_content.article.1', 'Composants d''administration', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(90, 93, 130, 131, 7, 'com_content.article.2', 'Module Archive', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(91, 93, 132, 133, 7, 'com_content.article.3', 'Module Liste de catégories', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(92, 93, 134, 135, 7, 'com_content.article.4', 'Module Articles d''une catégorie', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(93, 47, 129, 144, 6, 'com_content.category.64', 'Modules Contenu', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(94, 47, 145, 152, 6, 'com_content.category.65', 'Modules Utilisateur', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(95, 47, 153, 166, 6, 'com_content.category.66', 'Modules Affichage', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(96, 47, 167, 180, 6, 'com_content.category.67', 'Modules Utilitaires', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(97, 48, 191, 192, 6, 'com_content.category.68', 'Atomic', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(98, 48, 193, 194, 6, 'com_content.category.69', 'Beez 20', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(99, 48, 195, 196, 6, 'com_content.category.70', 'Beez5', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(100, 48, 197, 198, 6, 'com_content.category.71', 'Milky Way', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(101, 50, 205, 206, 6, 'com_content.article.5', 'Authentification', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(102, 51, 277, 278, 4, 'com_content.article.6', 'Parcs australiens', '{"core.delete":[],"core.edit":{"2":1},"core.edit.state":[]}'),
(103, 95, 154, 155, 7, 'com_content.article.7', 'Module Bannières', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(104, 44, 225, 226, 4, 'com_content.article.8', 'Débutants', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(105, 46, 115, 116, 6, 'com_content.article.9', 'Contact', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(106, 46, 117, 118, 6, 'com_content.article.10', 'Contenu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(107, 109, 267, 268, 6, 'com_content.article.11', 'Montagne Cradle', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(108, 53, 256, 265, 5, 'com_content.category.72', 'Animaux', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(109, 53, 266, 275, 5, 'com_content.category.73', 'Paysages', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(110, 95, 156, 157, 7, 'com_content.article.12', 'Contenu personnalisé', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(111, 54, 287, 288, 4, 'com_content.article.13', 'Directions', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(112, 50, 207, 208, 6, 'com_content.article.14', 'Éditeurs de contenu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(113, 50, 209, 210, 6, 'com_content.article.15', 'Boutons xtd', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(114, 95, 158, 159, 7, 'com_content.article.16', 'Fils d''actualité RSS', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(115, 52, 250, 251, 5, 'com_content.article.17', 'Premier article du blog', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(116, 52, 252, 253, 5, 'com_content.article.18', 'Second article du blog', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(117, 95, 160, 161, 7, 'com_content.article.19', 'Pied de page', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(118, 54, 289, 290, 4, 'com_content.article.20', 'Boutique de fruits', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(119, 44, 227, 228, 4, 'com_content.article.21', 'Obtenir de l''aide', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(120, 44, 229, 230, 4, 'com_content.article.22', 'Comment débuter ?', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(121, 55, 282, 283, 5, 'com_content.article.23', 'L''orangeraie', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(122, 44, 231, 232, 4, 'com_content.article.24', 'Joomla!', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(123, 108, 257, 258, 6, 'com_content.article.25', 'Koala', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(124, 96, 168, 169, 7, 'com_content.article.26', 'Sélecteur de langue', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(125, 93, 136, 137, 7, 'com_content.article.27', 'Module Derniers articles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(126, 94, 146, 147, 7, 'com_content.article.28', 'Module Connexion', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(127, 166, 184, 185, 7, 'com_content.article.29', 'Module Menu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(128, 93, 138, 139, 7, 'com_content.article.30', 'Articles les plus consultés', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(129, 93, 140, 141, 7, 'com_content.article.31', 'Flash info', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(130, 44, 233, 234, 4, 'com_content.article.32', 'Paramètres', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(131, 108, 259, 260, 6, 'com_content.article.33', 'Phyllopteryx', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(132, 109, 269, 270, 6, 'com_content.article.34', 'Pinnacles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(133, 44, 235, 236, 4, 'com_content.article.35', 'Professionnels', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(134, 95, 162, 163, 7, 'com_content.article.36', 'Module Image aléatoire', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(135, 93, 142, 143, 7, 'com_content.article.37', 'Module Articles en relation', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(136, 44, 237, 238, 4, 'com_content.article.38', 'Sites exemples', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(137, 46, 119, 120, 6, 'com_content.article.39', 'Recherche', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(138, 96, 170, 171, 7, 'com_content.article.40', 'Module de Recherche', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(139, 50, 211, 212, 6, 'com_content.article.41', 'Plug-ins de recherche', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(140, 39, 294, 295, 3, 'com_content.article.42', 'Plan du site', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(141, 108, 261, 262, 6, 'com_content.article.43', 'Chat marsupial', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(142, 96, 172, 173, 7, 'com_content.article.44', 'Module Statistiques', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(143, 96, 174, 175, 7, 'com_content.article.45', 'Module Flux RSS', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(144, 50, 213, 214, 6, 'com_content.article.46', 'Plug-ins système', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(145, 44, 239, 240, 4, 'com_content.article.47', 'La Communauté Joomla!', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(146, 44, 241, 242, 4, 'com_content.article.48', 'Le "Projet Joomla!"', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(147, 48, 199, 200, 6, 'com_content.article.49', 'Typographie', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(148, 44, 243, 244, 4, 'com_content.article.50', 'Mise à jour', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(149, 50, 215, 216, 6, 'com_content.article.51', 'Plug-ins Utilisateurs', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(150, 46, 121, 122, 6, 'com_content.article.52', 'Composant Utilisateurs', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(151, 44, 245, 246, 4, 'com_content.article.53', 'Utiliser Joomla!', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(152, 46, 123, 124, 6, 'com_content.article.54', 'Composant Liens web', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(153, 95, 164, 165, 7, 'com_content.article.55', 'Module de Liens web', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(154, 94, 148, 149, 7, 'com_content.article.56', 'Module Qui est en ligne ?', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(155, 108, 263, 264, 6, 'com_content.article.57', 'Requins-tapis', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(156, 55, 284, 285, 5, 'com_content.article.58', 'Merveilleuses pastèques', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(157, 96, 176, 177, 7, 'com_content.article.59', 'Module Fenêtre intégrée', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(158, 46, 125, 126, 6, 'com_content.article.60', 'Composant Fils d''actualité', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(159, 166, 186, 187, 7, 'com_content.article.61', 'Module Fil de navigation', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(160, 50, 217, 218, 6, 'com_content.article.62', 'Plug-ins de contenu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(162, 109, 271, 272, 6, 'com_content.article.64', 'Montagne bleue', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(163, 109, 273, 274, 6, 'com_content.article.65', 'Ormiston Pound', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(165, 94, 150, 151, 7, 'com_content.article.66', 'Module Derniers inscrits', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(166, 47, 183, 188, 6, 'com_content.category.75', 'Modules Fil de navigation', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(167, 54, 291, 292, 4, 'com_content.category.76', 'Recettes', '{"core.create":{"12":1,"10":1},"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":{"12":1,"10":1}}'),
(168, 34, 106, 107, 3, 'com_content.article.67', 'Nouveautés de Joomla! 1.5 ?', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(169, 24, 337, 338, 2, 'com_users.category.77', 'Non catégorisé', ''),
(170, 50, 219, 220, 6, 'com_content.article.68', 'Captcha', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(171, 50, 221, 222, 6, 'com_content.article.69', 'Quick Icons', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(172, 96, 178, 179, 7, 'com_content.article.70', 'Recherche avancée', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(173, 1, 422, 423, 1, 'com_joomlaupdate', 'com_joomlaupdate', '{"core.admin":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(174, 1, 424, 427, 1, 'com_mediamallfactory', 'com_mediamallfactory', '{}'),
(175, 174, 425, 426, 2, 'com_mediamallfactory.category.78', 'Categorie 1', '{"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(176, 1, 428, 429, 1, 'com_ajaxdemo', 'ajaxdemo', '{}');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_associations`
--

DROP TABLE IF EXISTS `m5jbw_associations`;
CREATE TABLE IF NOT EXISTS `m5jbw_associations` (
  `id` varchar(50) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_associations`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_banners`
--

DROP TABLE IF EXISTS `m5jbw_banners`;
CREATE TABLE IF NOT EXISTS `m5jbw_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `m5jbw_banners`
--

INSERT INTO `m5jbw_banners` (`id`, `cid`, `type`, `name`, `alias`, `imptotal`, `impmade`, `clicks`, `clickurl`, `state`, `catid`, `description`, `custombannercode`, `sticky`, `ordering`, `metakey`, `params`, `own_prefix`, `metakey_prefix`, `purchase_type`, `track_clicks`, `track_impressions`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `reset`, `created`, `language`) VALUES
(2, 3, 0, 'Shop 1', 'shop-1', 0, 1433, 2, 'http://shop.joomla.org/amazoncom-bookstores.html', 1, 15, 'Obtenir des livres Joomla! par notre librairie.', '', 0, 1, '', '{"imageurl":"images\\/banners\\/white.png","width":"","height":"","alt":"Joomla! Books"}', 0, '', -1, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2012-01-01 00:00:01', 'fr-FR'),
(3, 2, 0, 'Shop 2', 'shop-2', 0, 1483, 2, 'http://shop.joomla.org', 1, 15, 'T Shirts, casquettes et plus dans la boutique Joomla!', '', 0, 2, '', '{"imageurl":"images\\/banners\\/white.png","width":"","height":"","alt":"Joomla! Shop"}', 0, '', -1, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2012-01-01 00:00:01', 'fr-FR'),
(4, 1, 0, 'Support Joomla!', 'support-joomla', 0, 1402, 2, 'http://contribute.joomla.org', 1, 15, 'Vos contributions de temps, de talent et d''argent rendent le projet Joomla! possible.', '', 0, 3, '', '{"imageurl":"images\\/banners\\/white.png","width":"","height":"","alt":""}', 0, '', -1, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'fr-FR');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_banner_clients`
--

DROP TABLE IF EXISTS `m5jbw_banner_clients`;
CREATE TABLE IF NOT EXISTS `m5jbw_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `m5jbw_banner_clients`
--

INSERT INTO `m5jbw_banner_clients` (`id`, `name`, `contact`, `email`, `extrainfo`, `state`, `checked_out`, `checked_out_time`, `metakey`, `own_prefix`, `metakey_prefix`, `purchase_type`, `track_clicks`, `track_impressions`) VALUES
(1, 'Joomla!', 'Administrator', 'email@email.com', '', 1, 0, '0000-00-00 00:00:00', '', 0, '', -1, -1, -1),
(2, 'Shop', 'Example', 'example@example.com', '', 1, 0, '0000-00-00 00:00:00', '', 0, '', -1, 0, 0),
(3, 'Bookstore', 'Bookstore Example', 'example@example.com', '', 1, 0, '0000-00-00 00:00:00', '', 0, '', -1, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_banner_tracks`
--

DROP TABLE IF EXISTS `m5jbw_banner_tracks`;
CREATE TABLE IF NOT EXISTS `m5jbw_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_banner_tracks`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_categories`
--

DROP TABLE IF EXISTS `m5jbw_categories`;
CREATE TABLE IF NOT EXISTS `m5jbw_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=79 ;

--
-- Contenu de la table `m5jbw_categories`
--

INSERT INTO `m5jbw_categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`) VALUES
(1, 0, 0, 0, 137, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(9, 34, 1, 131, 132, 1, 'non-categorise', 'com_content', 'Non catégorisé', 'non-categorise', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(10, 35, 1, 129, 130, 1, 'non-categorise', 'com_banners', 'Non catégorisé', 'non-categorise', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":"","foobar":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(11, 36, 1, 125, 126, 1, 'non-categorise', 'com_contact', 'Non catégorisé', 'non-categorise', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(12, 37, 1, 61, 62, 1, 'non-categorise', 'com_newsfeeds', 'Non catégorisé', 'non-categorise', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(13, 38, 1, 57, 58, 1, 'non-categorise', 'com_weblinks', 'Non catégorisé', 'non-categorise', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(14, 39, 1, 9, 56, 1, 'articles-exemples', 'com_content', 'Articles exemples', 'articles-exemples', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(15, 40, 1, 127, 128, 1, 'exemples-bannieres', 'com_banners', 'Bannières exemples', 'exemples-bannieres', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":"","foobar":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(16, 41, 1, 63, 124, 1, 'exemples-contacts', 'com_contact', 'Exemples de contacts', 'exemples-contacts', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(17, 42, 1, 59, 60, 1, 'exemples-flux-rss', 'com_newsfeeds', 'Exemples de Fils d''actualité', 'exemples-flux-rss', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(18, 43, 1, 1, 8, 1, 'exemples-liens-web', 'com_weblinks', 'Exemples de Liens Web', 'exemples-liens-web', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(19, 44, 14, 10, 39, 2, 'sample-data-articles/joomla', 'com_content', 'Joomla!', 'joomla', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(20, 45, 19, 11, 38, 3, 'sample-data-articles/joomla/extensions', 'com_content', 'Extensions', 'extensions', '', '<p>Le système de gestion de contenu Joomla! vous permet de créer des pages en utilisant diverses extensions. Il en existe 5 : composants, modules, templates, langues et plug-ins. Votre site inclut par défaut toutes les extensions nécessaires à la création d''un site simple, mais des milliers d''extensions complémentaires, de tous types, sont disponibles. Le <a href="http://extensions.joomla.org" style="color: #1b57b1; text-decoration: none; font-weight: normal;" target="_blank">Joomla! Extensions Directory</a> est le plus important site regroupant des extensions Joomla.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(21, 46, 20, 12, 13, 4, 'sample-data-articles/joomla/extensions/components', 'com_content', 'Composants', 'composants', '', '<p><img src="administrator/templates/bluestork/images/header/icon-48-component.png" class="image-left" alt="Component Image" border="0" />Les Composants sont les extensions les plus complètes, gérant l''essentiel du contenu de votre site. Chaque composant comporte un ou plusieurs types de présentation des données qui déterminent le mode d''affichage de ce contenu. Dans l''administration de Joomla existent des composants complémentaires tels que ceux gérant les menus, les redirections ou les extensions.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(22, 47, 20, 14, 25, 4, 'sample-data-articles/joomla/extensions/modules', 'com_content', 'Modules', 'modules', '', '<p><img src="administrator/templates/bluestork/images/header/icon-48-module.png" alt="Media Image" class="image-left" border="0" />Les modules sont de petits "blocs" de contenu pouvant être affichés en différentes positions sur une page web. Les menus de ce site sont affichés par des modules. Le "système Joomla!" comprend 17 modules distincts, allant de celui de connexion à celui de recherche ou d''image aléatoire. Chaque module a un nom débutant par "mod_", mais lors de son affichage, c''est son titre qui apparaît. Dans la description de cette section, les titres sont identiques aux noms.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(23, 48, 20, 26, 33, 4, 'sample-data-articles/joomla/extensions/templates', 'com_content', 'Templates', 'templates', '', '<p><img src="administrator/templates/bluestork/images/header/icon-48-themes.png" alt="Media Image" class="image-left" border="0" />Les Templates donnent leur style à votre site. Ils déterminent le positionnement, les couleurs, l''aspect graphique etc. qui font de votre site un site unique. Le pack d''installation inclut trois templates pour le site et deux pour l''administration. <a href="http://help.joomla.org/proxy/index.php?option=com_help&keyref=Help16:Extensions_Template_Manager_Templates" target="_blank">Aide</a></p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(24, 49, 20, 34, 35, 4, 'sample-data-articles/joomla/extensions/languages', 'com_content', 'Langues', 'langues', '', '<p><img src="administrator/templates/bluestork/images/header/icon-48-language.png" border="0" alt="Languages Image" class="image-left" border="0" />Joomla s''installe par défaut en anglais, mais des traductions de l''interface, des exemples et des écrans d''aide sont disponibles dans des dizaines de langues.</p><p><a href="http://community.joomla.org/translations.html" target="_blank">Informations de traduction</a></p><p>S''il n''existe pas de pack pour votre langue, vous y trouverez des instructions pour créer votre propre traduction, que vous pourrez partager en créant une équipe de traduction, et officialiser.</p><p>La traduction de l''interface est installée depuis le gestionnaire d''installation de l''administration du site, puis géré depuis le gestionnaire de langues.</p><p>Si vous utilisez deux langues, ou plus, vous pouvez activer le plug-in et le module sélecteur de langue. Ils doivent toujours être utilisés ensemble. Si vous créer un contenu multilingue et marquez votre article, vos éléments de menu ou vos modules comme étant dans une langue spécifique, et suivez les <a href="http://info-graf.fr/trunk/fr/instructions-multilangue" target="_blank">instructions complètes</a>, vos visiteurs pourront sélectionner le contenu spécifique à une langue en utilisant ce module. Par défaut, le plug-in et le module sont désactivés.</p><p>De nombreuses extensions susceptibles de vous aider à gérer vos traductions sont disponible sur le <a href="http://extensions.joomla.org" target="_blank">Joomla! Extensions Directory</a>.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(25, 50, 20, 36, 37, 4, 'sample-data-articles/joomla/extensions/plugins', 'com_content', 'Plug-ins', 'plugins', '', '<p><img src="administrator/templates/bluestork/images/header/icon-48-plugin.png" alt="Plugin Image" class="image-left" />Les Plug-ins sont de petites extensions orientées "tâches" qui améliorent le moteur Joomla. Certains sont associés à des extensions spécifiques, d''autres comme les éditeurs de texte sont utilisés de toutes parts dans Joomla. La plupart des débutants n''ont aucune nécessité de modifier les réglages de plug-ins installés avec Joomla. <a href="http://help.joomla.org/proxy/index.php?option=com_help&keyref=Help16:Extensions_Plugin_Manager_Edit" target="_blank">Aide</a></p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(26, 51, 14, 40, 49, 2, 'sample-data-articles/park-site', 'com_content', 'Site des Parcs', 'site-parcs', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, 'fr-FR'),
(27, 52, 26, 41, 42, 3, 'sample-data-articles/park-site/park-blog', 'com_content', 'Blog des parcs', 'blog-parcs', '', '<p><span style="font-size: 12px;">Ici, je vais vous parler des parcs australiens sous forme de blog.</span></p><p>Vous pouvez créer un blog sur votre site en créant une catégorie dans laquelle vous publiez vos articles de blog (celui-ci est nommé "Blog des parcs"). Chaque publication est un article de cette catégorie. Si vous paramétrez un lien de menu d''une colonne vers la catégorie et que vous affichez la description de la catégorie, votre blog aura l''aspect de la page actuelle.</p><p>Pour améliorer votre blog, vous pouvez installer des extensions telles que <em><a href="http://extensions.joomla.org/extensions/contacts-and-feedback/articles-comments" target="_blank" style="color: #1b57b1; text-decoration: none; font-weight: normal;">commentaires</a>, <a href="http://extensions.joomla.org/extensions/social-web" style="color: #1b57b1; text-decoration: none; font-weight: normal;" target="_blank">interaction avec des réseaux sociaux</a>, <a href="http://extensions.joomla.org/extensions/content-sharing" style="color: #1b57b1; text-decoration: none; font-weight: normal;" target="_blank">tagging</a>, et <a href="http://extensions.joomla.org/extensions/content-sharing" style="color: #1b57b1; text-decoration: none; font-weight: normal;" target="_blank">rester en contact avec vos visiteurs</a>. </em>Vous pouvez également activer le flux d''actualité RSS ou ATOM inclut dans Joomla (gestion des articles ou des catégories, Paramètres, activez l''affichage du "Lien de flux RSS" ou publiez le module "Lien RSS ou ATOM" sur la page).</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"images\\/sampledata\\/parks\\/banner_cradle.jpg"}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, 'fr-FR'),
(28, 53, 26, 43, 48, 3, 'sample-data-articles/park-site/photo-gallery', 'com_content', 'Galerie Photo', 'galerie-photo', '', '<p><img src="images/sampledata/parks/banner_cradle.jpg" border="0" /></p><p>Ce sont des photos de parcs que j''ai visités (je ne les ai pas prises moi-même, elles proviennent de <a href="http://commons.wikimedia.org/wiki/Main_Page" style="color: #1b57b1; text-decoration: none; font-weight: normal;" target="_blank">Wikimedia Commons</a>).</p><p><em>Cela vous montre comment créer une galerie d''images toute simple, en utilisant des articles avec com_content.</em></p><p><em>Dans chaque article, insérez une vignette de votre image avant un "lire la suite", puis l''image en taille normale. Paramétrez l''article afin de masquer le texte d''introduction.</em></p>', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, 'fr-FR'),
(29, 54, 14, 50, 55, 2, 'sample-data-articles/fruit-shop-site', 'com_content', 'Boutique de fruits', 'boutique-fruit', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(30, 55, 29, 51, 52, 3, 'sample-data-articles/fruit-shop-site/growers', 'com_content', 'Producteurs', 'producteurs', '', '<p>Nous recherchons en permanence les meilleurs producteurs de fruits du pays.</p><p><em>Vous pouvez autoriser chaque fournisseur à avoir une page qu''il pourra gérer. Pour tester, vous devrez créer des utilisateurs qui font partie du groupe des fournisseurs, et les assigner en tant qu''auteurs pour les articles de la catégorie "fournisseurs". <br />Créez une page dans la catégorie "Producteur" pour cet utilisateur, et affectez-le comme auteur de cette page. Cet  utilisateur pourra ainsi modifier sa page.</em></p><p><em>Cela illustre une utilisation de la fonctionnalité des droits sur les articles.</em></p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(31, 56, 18, 2, 3, 2, 'exemples-liens-web/liens-des-parcs', 'com_weblinks', 'Liens des parcs', 'liens-parcs', '', '<p>Vous trouverez ici une liste de quelques-uns de mes parcs favoris.</p><p><em>Le composant de Liens web procure un excellent moyen de créer une liste de liens externes correctement formatés et classés en catégories. Vous pouvez créer ces liens depuis l''interface frontale de votre site.</em></p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"images\\/sampledata\\/parks\\/banner_cradle.jpg"}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, 'fr-FR'),
(32, 57, 18, 4, 7, 2, 'exemples-liens-web/liens-joomla', 'com_weblinks', 'Liens Joomla!', 'liens-joomla', '', '<p>Une sélection de liens spécifiques à Joomla.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(33, 58, 32, 5, 6, 3, 'exemples-liens-web/liens-joomla/autres-ressources', 'com_weblinks', 'Autres ressources', 'autres-ressources', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(34, 59, 16, 64, 65, 2, 'exemples-contacts/site-parcs-australiens', 'com_contact', 'Site Parcs australiens', 'site-parcs-australiens', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, 'fr-FR'),
(35, 60, 16, 66, 123, 2, 'exemples-contacts/site-boutique-fruits', 'com_contact', 'Site Boutique de fruits', 'site-boutique-fruits', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(36, 61, 35, 67, 68, 3, 'exemples-contacts/site-boutique-fruits/notre-personnel', 'com_contact', 'Notre personnel', 'notre-personnel', '', '<p>N''hésitez pas à contacter notre personnel pour tout besoin d''assistance</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(37, 62, 35, 69, 122, 3, 'exemples-contacts/site-boutique-fruits/encyclopdie-des-fruits', 'com_contact', 'Encyclopédie des fruits', 'encyclopdie-fruits', '', '<p style="text-align: justify;">Notre encyclopédie sur les différentes sortes de fruits.<br /><br />Nous aimons les fruits et voulons que le monde en sache plus sur l''ensemble des variétés qui nous sont disponibles.<br /><br />Bien qu''il s''agisse de petits moments, nous travaillons sur le développement de cette encyclopédie dès que nous le pouvons.<br /><br />Toutes les images peuvent être trouvés sur <a href="http://commons.wikimedia.org/wiki/Main_Page" target="_blank">Wikimedia Commons</a>.</p><p><img src="images/sampledata/fruitshop/apple.jpg" border="0" alt="Apples" title="Apples" /></p><p style="text-align: justify;"><em>Cette  encyclopédie est réalisée en utilisant l''élément de contact. Chaque  fruit est un contact distinct et chaque catégorie une lettre de l''alphabet. Un style CSS est utilisé pour créer la disposition horizontale des lettres de  l''alphabet.</em></p><p style="text-align: justify;"><em>Si  vous le souhaitiez, vous pourriez permettre à certains utilisateurs (par exemple vos producteurs de fruits) d''avoir un accès à cette catégorie du composant «Contact» pour les laisser vous aider à créer de nouveaux  contenus de l''encyclopédie.</em></p>', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(38, 63, 37, 70, 71, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/a', 'com_contact', 'A', 'a', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(39, 64, 37, 72, 73, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/b', 'com_contact', 'B', 'b', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(40, 65, 37, 74, 75, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/c', 'com_contact', 'C', 'c', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(41, 66, 37, 76, 77, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/d', 'com_contact', 'D', 'd', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(42, 67, 37, 78, 79, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/e', 'com_contact', 'E', 'e', '', '', 0, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(43, 68, 37, 80, 81, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/f', 'com_contact', 'F', 'f', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(44, 69, 37, 82, 83, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/g', 'com_contact', 'G', 'g', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(45, 70, 37, 84, 85, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/h', 'com_contact', 'H', 'h', '', '', 0, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(46, 71, 37, 86, 87, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/i', 'com_contact', 'I', 'i', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(47, 72, 37, 88, 89, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/j', 'com_contact', 'J', 'j', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(48, 73, 37, 90, 91, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/k', 'com_contact', 'K', 'k', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(49, 74, 37, 92, 93, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/l', 'com_contact', 'L', 'l', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(50, 75, 37, 94, 95, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/m', 'com_contact', 'M', 'm', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(51, 76, 37, 96, 97, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/n', 'com_contact', 'N', 'n', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(52, 77, 37, 98, 99, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/o', 'com_contact', 'O', 'o', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(53, 78, 37, 100, 101, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/p', 'com_contact', 'P', 'p', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(54, 79, 37, 102, 103, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/q', 'com_contact', 'Q', 'q', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(55, 80, 37, 104, 105, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/r', 'com_contact', 'R', 'r', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(56, 81, 37, 106, 107, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/s', 'com_contact', 'S', 's', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(57, 82, 37, 108, 109, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/t', 'com_contact', 'T', 't', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(58, 83, 37, 110, 111, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/u', 'com_contact', 'U', 'u', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(59, 84, 37, 112, 113, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/v', 'com_contact', 'V', 'v', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(60, 85, 37, 114, 115, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/w', 'com_contact', 'W', 'w', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(61, 86, 37, 116, 117, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/x', 'com_contact', 'X', 'x', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(62, 87, 37, 118, 119, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/y', 'com_contact', 'Y', 'y', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(63, 88, 37, 120, 121, 4, 'sample-data-contact/shop-site/fruit-encyclopedia/z', 'com_contact', 'Z', 'z', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(64, 93, 22, 15, 16, 5, 'sample-data-articles/joomla/extensions/modules/articles-modules', 'com_content', 'Modules de contenu', 'modules-articles', '', '<p>Les modules de contenu affichent des articles ainsi que d''autres informations provenant du composant de contenu.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(65, 94, 22, 17, 18, 5, 'sample-data-articles/joomla/extensions/modules/user-modules', 'com_content', 'Modules Utilisateur', 'modules-utilisateur', '', '<p>Les modules utilisateur interagissent avec le système de gestion des utilisateurs, leur permettant de s''identifier, de montrer qui est connecté, ou d''afficher les membres les plus récemment inscrits.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(66, 95, 22, 19, 20, 5, 'sample-data-articles/joomla/extensions/modules/display-modules', 'com_content', 'Modules d''affichage', 'modules-affichage', '', '<p>Ces modules affichent les informations provenant de composants autres que ceux de contenu (articles) ou d''utilisateurs. Cela inclut les liens web, les fils d''actualité (RSS/RDF/ATOM) et le gestionnaire de médias.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(67, 96, 22, 21, 22, 5, 'sample-data-articles/joomla/extensions/modules/utility-modules', 'com_content', 'Modules utilitaires', 'modules-utilitaires', '', '<p>Les modules utilitaires proposent des fonctionnalités telles que la recherche, la syndication ou les statistiques.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(68, 97, 23, 31, 32, 5, 'sample-data-articles/joomla/extensions/templates/atomic', 'com_content', 'Atomic', 'atomic', '', '<p>Atomic est un template a minima destiné à être un point de départ pour la création de votre propre template, vous permettant d''apprendre la création de template Joomla.</p><p><img src="templates/atomic/template_thumbnail.png" border="0" alt="The Atomic Template" style="border: 0; float: right;" /></p><ul><li><a href="index.php?Itemid=285">Accueil</a></li><li><a href="index.php?Itemid=316">Typographie</a></li></ul>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(69, 98, 23, 27, 28, 5, 'sample-data-articles/joomla/extensions/templates/beez-20', 'com_content', 'Beez 2', 'beez-2', '', '<p><img src="templates/beez_20/template_thumbnail.png" border="0" alt="Miniature Beez 2" align="right" style="float: right;" /></p><p>Beez 2.0 est un template souple, facile à personnaliser, qui convient à toutes sortes de sites. Il répond aux normes d''accessibilité et montre toute une série de techniques CSS et JavaScript. C''est le template par défaut de Joomla.</p><ul><li><a href="index.php?Itemid=424">Page d''accueil</a></li><li><a href="index.php?Itemid=423">Typographie</a></li></ul>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(70, 99, 23, 29, 30, 5, 'sample-data-articles/joomla/extensions/templates/beez-5', 'com_content', 'Beez 5', 'beez-5', '', '<p><img src="templates/beez5/template_thumbnail.png" border="0" alt="Miniature Beez 5" align="right" style="float: right;" /></p><p>Beez 5 est une évolution HTML5 de template Joomla. Il utilise un certain nombre de techniques HTML5 pour améliorer la présentation d''un site. Il est utilisé comme template du site exemple Fruit Shop.</p><ul><li><a href="index.php?Itemid=458">Accueil</a></li><li><a href="index.php?Itemid=457">Typographie</a></li></ul>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(72, 108, 28, 44, 45, 4, 'sample-data-articles/park-site/photo-gallery/animals', 'com_content', 'Animaux', 'animaux', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, 'fr-FR'),
(73, 109, 28, 46, 47, 4, 'sample-data-articles/park-site/photo-gallery/scenery', 'com_content', 'Paysages', 'paysages', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, 'fr-FR'),
(75, 166, 22, 23, 24, 5, 'sample-data-articles/joomla/extensions/modules/navigation-modules', 'com_content', 'Modules de navigation', 'modules-menus', '', '<p>Les modules de navigation (menus) permettent à vos visiteurs de se déplacer dans votre site et d''y trouver ce qu''ils y cherchent.</p><p>Les Menus proposent votre site selon la structure que vous avez choisie, et aident à la navigation. Bien qu''ils soient tous basés sur le même module, leur variété d''utilisation montre à quel point ce dernier est polyvalent.</p><p>Un menu peut être extrêmement simple (par exemple le menu horizontal ou celui des Parcs australiens) et particulièrement complexe (comme le menu "A propos de Joomla!" qui comporte plusieurs niveaux). Il peut aussi servir à présenter un plan de site, présent dans le menu "Ce site".</p><p>Le Fil de navigatione, quant à lui, précise au visiteur sa position dans le site.</p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(76, 167, 29, 53, 54, 3, 'sample-data-articles/fruit-shop-site/recipes', 'com_content', 'Recettes', 'recettes', '', '<p>Ici, les clients peuvent proposer leurs recettes à base de fruits.</p><p>Il est intéressant de promouvoir l''utilisation des mots-clés afin de permettre de retrouver aisément les différentes recettes faites avec le même fruit.</p><p>Pour voir cette fonctionnalité en action, créez un utilisateur dans le groupe des clients et un autre dans le groupe des fournisseurs. Ces utilisateurs pourront créer leurs propres pages de recettes, et les modifier. Ils ne seront par contre pas autorisés à en modifier d''autres.<br /><br /></p>', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 342, '2012-01-01 00:00:01', 42, '2012-01-01 00:00:01', 0, '*'),
(77, 169, 1, 133, 134, 1, 'non-categorise', 'com_users', 'Non catégorisé', 'non-categorise', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 342, '2012-01-01 00:00:01', 0, '2012-01-01 00:00:01', 0, '*'),
(78, 175, 1, 135, 136, 1, 'categorie-1', 'com_mediamallfactory', 'Categorie 1', 'categorie-1', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"","thumbnail":{"current":"","new":""}}', '', '', '{"author":"","robots":""}', 342, '2013-09-09 16:46:27', 0, '0000-00-00 00:00:00', 0, '*');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_contact_details`
--

DROP TABLE IF EXISTS `m5jbw_contact_details`;
CREATE TABLE IF NOT EXISTS `m5jbw_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `m5jbw_contact_details`
--

INSERT INTO `m5jbw_contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `imagepos`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`, `sortname1`, `sortname2`, `sortname3`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`) VALUES
(1, 'Nom du contact', 'nom-contact', 'Fonction', 'Adresse', 'Ville', 'Département', 'Pays', 'Code postal', 'Téléphone', 'Fax', '<p>Informations sur le contact.</p>', 'images/powered_by.png', 'top', 'email@example.com', 1, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"","show_contact_list":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"1","linka_name":"Twitter","linka":"http:\\/\\/twitter.com\\/joomla","linkb_name":"YouTube","linkb":"http:\\/\\/www.youtube.com\\/user\\/joomla","linkc_name":"Facebook","linkc":"http:\\/\\/www.facebook.com\\/joomla","linkd_name":"FriendFeed","linkd":"http:\\/\\/friendfeed.com\\/joomla","linke_name":"Scribed","linke":"http:\\/\\/www.scribd.com\\/people\\/view\\/504592-joomla","contact_layout":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":""}', 0, 16, 1, '', '', 'last', 'first', 'middle', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Webmaster', 'webmaster', '', '', '', '', '', '', '', '', '<p>Informations de contact de notre Webmaster.</p>', '', NULL, 'webmaster@example.com', 0, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"","show_contact_list":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"","linka_name":"","linka":"","linkb_name":"","linkb":"","linkc_name":"","linkc":"","linkd_name":"","linkd":"","linke_name":"","linke":"","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"","redirect":""}', 0, 34, 1, '', '', '', '', '', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Propriétaire', 'proprietaire', '', '', '', '', '', '', '', '', '<p>Je suis le propriétaire de ce magasin.</p><p>Veuillez me contacter si vous souhaitez devenir un de nos revendeurs.</p>', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 2, '{"show_contact_category":"","show_contact_list":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"","linka_name":"","linka":"","linkb_name":"","linkb":"","linkc_name":"","linkc":"","linkd_name":"","linkd":"","linke_name":"","linke":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":""}', 0, 36, 1, '', '', '', '', '', '*', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Acheteur', 'acheteur', '', '', '', '', '', '', '', '', '<p>Je suis en charge de l''achat des fruits.</p><p>Si vous vendez de bons fruits, veuillez me contacter.</p>', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"","show_contact_list":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"0","linka_name":"","linka":"","linkb_name":"","linkb":"","linkc_name":"","linkc":"","linkd_name":"","linkd":"","linke_name":"","linke":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":""}', 0, 36, 1, '', '', '', '', '', '*', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'Bananes', 'bananes', 'Scientific Name: Musa', 'Image Credit: EnzikRights: Creative Commons Share Alike Unported 3.0\r\nSource: http://commons.wikimedia.org/wiki/File:Bananas_-_Morocco.jpg', '', 'Type: Herbaceous', 'Large Producers: India, China, Brasil', '', '', '', '<p>Les bananes sont une excellente source de potassium.</p><p> </p>', 'images/sampledata/fruitshop/bananas_2.jpg', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"show_with_link","show_contact_list":"","presentation_style":"plain","show_name":"","show_position":"1","show_email":"","show_street_address":"","show_suburb":"","show_state":"1","show_postcode":"","show_country":"1","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"1","linka_name":"Wikipedia: Banana English","linka":"http:\\/\\/en.wikipedia.org\\/wiki\\/Banana","linkb_name":"Wikipedia:  \\u0939\\u093f\\u0928\\u094d\\u0926\\u0940 \\u0915\\u0947\\u0932\\u093e","linkb":"http:\\/\\/hi.wikipedia.org\\/wiki\\/%E0%A4%95%E0%A5%87%E0%A4%B2%E0%A4%BE","linkc_name":"Wikipedia:Banana Portugu\\u00eas","linkc":"http:\\/\\/pt.wikipedia.org\\/wiki\\/Banana","linkd_name":"Wikipedia: \\u0411\\u0430\\u043d\\u0430\\u043d  \\u0420\\u0443\\u0441\\u0441\\u043a\\u0438\\u0439","linkd":"http:\\/\\/ru.wikipedia.org\\/\\u0411\\u0430\\u043d\\u0430\\u043d","linke_name":"","linke":"","contact_layout":"beez5:encyclopedia"}', 0, 39, 1, '', '', '', '', '', '*', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Pommes', 'pommes', 'Scientific Name: Malus domestica', 'Image Credit: Fievet\r\nRights: Public Domain\r\nSource: http://commons.wikimedia.org/wiki/File:Pommes_vertes.JPG', '', 'Family: Rosaceae', 'Large: Producers: China, United States', '', '', '', '<p>La pomme est un fruit polyvalent utilisé pour se nourrir, cuisiner, et se préserver.<br /><br />Il existe plus de 7500 différentes sortes de pommes cultivées dans le monde entier.</p>', 'images/sampledata/fruitshop/apple.jpg', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"","show_contact_list":"","presentation_style":"plain","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"1","linka_name":"Wikipedia: Apples English","linka":"http:\\/\\/en.wikipedia.org\\/wiki\\/Apple","linkb_name":"Wikipedia: Manzana Espa\\u00f1ol ","linkb":"http:\\/\\/es.wikipedia.org\\/wiki\\/Manzana","linkc_name":"Wikipedia: \\u82f9\\u679c \\u4e2d\\u6587","linkc":"http:\\/\\/zh.wikipedia.org\\/zh\\/\\u82f9\\u679c","linkd_name":"Wikipedia: Tofaa Kiswahili","linkd":"http:\\/\\/sw.wikipedia.org\\/wiki\\/Tofaa","linke_name":"","linke":"","contact_layout":"beez5:encyclopedia"}', 0, 38, 1, '', '', '', '', '', '*', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Tamarin', 'tamarin', 'Scientific Name: Tamarindus indica', 'Image Credit: Franz Eugen Köhler, Köhler''s Medizinal-Pflanzen \r\nRights: Public DomainSource:http://commons.wikimedia.org/wiki/File:Koeh-134.jpg', '', 'Family: Fabaceae', 'Large Producers: India, United States', '', '', '', '<p>Le tamarin est un fruit polyvalent utilisé dans le monde entier.</p><p style="text-align: justify;">Peu mûr, il est utilisé dans les sauces chaudes ; pleinement mûri, il est la base de nombreuses boissons rafraîchissantes.</p>', 'images/sampledata/fruitshop/tamarind.jpg', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"","show_contact_list":"","presentation_style":"plain","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"1","linka_name":"Wikipedia: Tamarind English","linka":"http:\\/\\/en.wikipedia.org\\/wiki\\/Tamarind","linkb_name":"Wikipedia: \\u09a4\\u09c7\\u0981\\u09a4\\u09c1\\u09b2  \\u09ac\\u09be\\u0982\\u09b2\\u09be  ","linkb":"http:\\/\\/bn.wikipedia.org\\/wiki\\/\\u09a4\\u09c7\\u0981\\u09a4\\u09c1\\u09b2 ","linkc_name":"Wikipedia: Tamarinier Fran\\u00e7ais","linkc":"http:\\/\\/fr.wikipedia.org\\/wiki\\/Tamarinier","linkd_name":"Wikipedia:Tamaline lea faka-Tonga","linkd":"http:\\/\\/to.wikipedia.org\\/wiki\\/Tamaline","linke_name":"","linke":"","contact_layout":"beez5:encyclopedia"}', 0, 57, 1, '', '', '', '', '', '*', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Addresse de la boutique', 'addresse-boutique', '', '', 'Our City', 'Our Province', 'Our Country', '', '555-555-5555', '', '<p>Voici les informations nécessaires pour venir à notre boutique.</p>', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"","show_contact_list":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"","linka_name":"","linka":"","linkb_name":"","linkb":"","linkc_name":"","linkc":"","linkd_name":"","linkd":"","linke_name":"","linke":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":""}', 0, 35, 1, '', '', '', '', '', '*', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_content`
--

DROP TABLE IF EXISTS `m5jbw_content`;
CREATE TABLE IF NOT EXISTS `m5jbw_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `title_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'Deprecated in Joomla! 3.0',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(10) unsigned NOT NULL DEFAULT '0',
  `mask` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=71 ;

--
-- Contenu de la table `m5jbw_content`
--

INSERT INTO `m5jbw_content` (`id`, `asset_id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(1, 89, 'Composants d''Administration', 'composants-administration', '', '<p style="text-align: justify;">Tous les composants cités ici sont également utilisés dans la partie "administration" du site. Il existe des composants qui n''ont aucun affichage dans l''interface frontale mais, qui contribuent à la gestion votre site. Les composants les plus importants sont...</p>\r\n<ul><li>le gestionnaire de médias ;</li>\r\n<li>le gestionnaire d''extensions ;</li>\r\n<li>le gestionnaire de menus ;</li><li>le gestionnaire de bannières ;</li>\r\n<li>le gestionnaire de redirection ;</li>\r\n<li>la configuration générale.</li>\r\n<p> </p></ul>\r\n<hr title="Gestionnaire de médias" alt="Gestionnaire de médias" class="system-pagebreak" style="color: gray; border: 1px dashed gray;" />\r\n<p> </p>\r\n<h3 style="text-align: justify;">Le gestionnaire de médias</h3>\r\n<p style="text-align: justify;">Le composant «Gestionnaire de médias» vous permet de placer des images sur votre serveur et de les insérer dans le contenu de votre site. En option, vous pouvez activer le chargement Flash permettant l''envoi d''images en lots. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Content_Media_Manager" target="_blank">Aide</a></p>\r\n<hr title="Gestionnaire d''extensions" alt="Gestionnaire d''extensions" class="system-pagebreak" style="color: gray; border: 1px dashed gray;" />\r\n<p> </p>\r\n<h3>Le gestionnaire d''extensions</h3><p style="text-align: justify;">Le composant «Gestionnaire d''extensions» vous permet d''installer, de mettre à jour, de  désinstaller et d''administrer toutes les extensions. Il a été entièrement repensé pour Joomla! 1.6, toutefois, le mode de fonctionnement de l''installation et de la désinstallation reste le même que celui de  Joomla! 1.5. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Extension_Manager_Install" target="_blank">Aide</a></p>\r\n<hr title="Gestionnaire de menus" alt="Gestionnaire de menus" class="system-pagebreak" style="color: gray; border: 1px dashed gray;" />\r\n<p> </p>\r\n<h3>Le gestionnaire de menus</h3>\r\n<p style="text-align: justify;">Le composant «Gestionnaire de menus» permet de créer les menus visibles sur le site. Il permet également d''assigner des modules et des styles de template à certains éléments de menus. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Menus_Menu_Manager" target="_blank">Aide</a></p>\r\n<hr title="Gestionnaire bannières" alt="Gestionnaire bannières" class="system-pagebreak" style="color: gray; border: 1px dashed gray;" />\r\n<p> </p>\r\n<h3>Le gestionnaire de bannières</h3><p style="text-align: justify;">Le composant «Gestionnaire de bannières» permet de manière simple d''afficher des images aléatoires ou en séquence dans un module, et si vous voulez insérer de la publicité, permet de compter le nombre d''affichage et de clics sur une image. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Components_Banners_Banners_Edit" target="_blank">Aide</a></p>\r\n<hr title="Gestionnaire de redirection" class="system-pagebreak" />\r\n<p> </p>\r\n<h3>Le gestionnaire de redirection</h3><p>Le composant de redirection est utilisé pour gérer les liens brisés qui produisent des erreurs 404 en raison de pages introuvables. Si activé, il vous permettra de rediriger les liens brisés vers des pages spécifiques. Il peut également être utilisé pour gérer les URL modifiées en raison de migration de site. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Components_Redirect_Manager" target="_blank">Aide</a></p>\r\n<hr title="Configuration générale" alt="Configuration générale" class="system-pagebreak" style="color: gray; border: 1px dashed gray;" />\r\n<p> </p>\r\n<h3>La configuration générale</h3><p style="text-align: justify;">Il s''agit de la zone où l''administrateur du site configure des fonctionnalités telles que l''attribution du groupe aux nouveaux enregistrés, l''utilisation de la réécriture d''URL, des méta-données (texte descriptif utilisé par les moteurs de recherche et d''indexation), etc. Si vous êtes un nouvel utilisateur de Joomla, laissez les valeurs par défaut, c''est une bonne configuration pour débuter, bien que lorsque le site sera prêt à être publié, il faudra penser à modifier les méta-données pour tenir compte du contenu. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Site_Global_Configuration" target="_blank">Aide</a></p>', '', 1, 0, 0, 21, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 9, 0, 7, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(2, 90, 'Module Articles archivés', 'module-articles-archives', '', '<p>Le module «Articles archivés» affiche une liste des mois correspondant à ceux de publication des articles archivés. Dès que vous changez le statut d''un article en l''archivant, cette liste est mise à jour. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Articles_Archive" title="Archive Module" target="_blank">Aide</a></p>\r\n<div class="sample-module">{loadmodule articles_archive,Articles archivés}</div>', '', 1, 0, 0, 64, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","page_title":"","alternative_readmore":"","layout":""}', 5, 0, 5, 'modules, content', '', 1, 5, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(3, 91, 'Module Liste de catégories', 'module-liste-categories', '', '<p style="text-align: justify;">Le module «Liste de catégories» (mod_articles_categories) permet d''afficher la liste des catégories d''une catégorie parente. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Articles_Categories" title="Categories Module" target="_blank">Aide</a></p>\r\n<div class="sample-module">{loadmodule articles_categories,Liste de catégories}</div>', '', 1, 0, 0, 64, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","page_title":"","alternative_readmore":"","layout":""}', 5, 0, 6, 'modules, content', '', 1, 6, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(4, 92, 'Module Articles d''une catégorie', 'module-articles-categorie', '', '<p>Le module «Articles d''une catégorie» (mod_articles_category) vous montre l''affichage des articles d''une catégorie déterminée. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Articles_Category" target="_blank">Aide</a></p>\r\n<div class="sample-module">{loadmodule articles_category,Articles d''une catégorie}</div>', '', 1, 0, 0, 64, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","page_title":"","alternative_readmore":"","layout":""}', 8, 0, 7, '', 'articles,content', 1, 10, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(5, 101, 'Plug-ins Authentification', 'plugins-authentification', '', '<p style="text-align: justify;">Les plug-ins d''authentification interviennent lors de la connexion au site  ou à son administration. L''authentification Joomla est activée par   défaut, mais vous pouvez utiliser l''authentification Gmail ou LDAP, ou installer un plugin pour un autre système. Un exemple inclus permet de créer un nouveau plugin d''authentification.</p>\r\n<p>Est activé par défaut :</p>\r\n<ul><li>Plug-in Joomla - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Authentication_-_GMail" target="_blank">Aide</a></li></ul>\r\n<p>Sont désactivés par défaut :</p>\r\n<ul><li>Plug-in Gmail - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Authentication_-_GMail" target="_blank">Aide</a></li>\r\n<li>Plug-in LDAP - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Authentication_-_LDAP" target="_blank">Aide</a></li></ul>', '', 1, 0, 0, 25, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 3, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(6, 102, 'Parcs Australiens', 'parcs-australiens', '', '<p><img src="images/sampledata/parks/banner_cradle.jpg" border="0" alt="Cradle Park Banner" /></p>\r\n<p style="text-align: justify;">Bienvenue !</p>\r\n<p style="text-align: justify;">Ceci est un site basique sur les splendides parcs d''Australie.</p>\r\n<p style="text-align: justify;">Vous pourrez y lire les récits de mes visites dans ces différents parcs, y   voir des photos et trouver des liens vers les sites de certains parcs.</p>\r\n<p style="text-align: justify;"><em>Ce site est un exemple d''utilisation du système Joomla pour créer un   site simple, comme un "site vitrine", un blog personnel ou la   présentation d''informations sur un sujet qui vous intéresse.</em></p>\r\n<p style="text-align: justify;"><em>Vous trouverez d''autres informations sur le site dans le module "A propos des Parcs".</em></p>', '', 1, 0, 0, 26, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 2, 0, 1, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(7, 103, 'Module Bannières', 'module-bannieres', '', '<p>Le module «Bannières» (mod_banners) permet d''afficher sur le site des  bannières gérées, côté administration, par le composant bannières. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Banners" target="_blank">Aide</a></p><div class="sample-module">{loadmodule banners,Bannières}</div>', '', 1, 0, 0, 66, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 4, 0, 6, '', '', 1, 4, '', 0, '*', ''),
(8, 104, 'Débutants', 'debutants', '', '<p style="text-align: justify;">Si vous vous lancez dans votre premier site Joomla, voir votre premier site web, vous êtes au bon endroit ! Joomla va vous aider à   créer votre site web, d''une manière rapide et aisée.</p><p style="text-align: justify;">Commencez à utiliser votre site en vous connectant à l''administration avec l''identifiant et le mot de passe du compte que vous avez créé  lors  de l''installation de Joomla.</p>', '<p style="text-align: justify;">Explorez les articles et autres ressources présentes dans les données   de ce site pour comprendre comment fonctionne Joomla (Lorsque  vous  aurez tout lu, vous pourrez supprimer ou archiver toutes ces  données  exemples).</p><p style="text-align: justify;">Vous aurez peut-être aussi envie de visiter l''espace "Débutants" de <a href="http://docs.joomla.org/" target="_blank">Joomla documentation</a> (en anglais), le <a href="http://forum.joomla.org/" target="_blank">forum d''entraide officiel</a> ou le <a href="http://forum.joomla.fr/" target="_blank">forum d''entraide francophone</a>. Vous voudrez peut-être également vous abonner à la liste de diffusion de "Sécurité" et à celles des "Annonces" de Joomla.</p><p style="text-align: justify;">Pour vous aider, visitez les pages de présentation de sites faits avec Joomla pour voir   l''étonnante variété de la façon dont les gens utilisent Joomla pour raconter leurs histoire sur le web.</p><p style="text-align: justify;">L''installation de base de Joomla vous permet d''avoir immédiatement un site fonctionnel, et lorsque vous serez prêt à y ajouter de nouvelles fonctionnalités, la puissance de Joomla se révèlera dans la variété et le nombre d''extensions de toutes sortes mise à disposition par les développeurs. Visitez le <a href="http://extensions.joomla.org/" target="_blank">site des extensions </a>de Joomla pour voir les milliers d''extensions susceptibles de faire pratiquement tout ce que vous voudriez pouvoir faire avec un site. <br />Vous ne trouvez pas votre bonheur ? Vous pouvez solliciter un développeur sur le forum francophone ou officiel.</p><p style="text-align: justify;">Vous voulez en savoir plus ? Participez au prochain <a href="http://www.joomladay.fr/" target="_blank">JoomlaDay</a>, l''évènement annuel proposé par l''Association Francophone des Utilisateurs de Joomla! (<a href="http://www.afuj.fr/" target="_blank">AFUJ</a>)  ou à rejoignez le <a href="http://www.joomgroupe.fr/" target="_blank">Joomgroupe</a> le plus proche de votre région. Il n''y en a pas près de chez vous ? Pourquoi ne pas en créer un vous-même ?</p>', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"administrator/templates/bluestork/images/header/icon-48-user.png","float_intro":"left","image_intro_alt":"Débutants Joomla!","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 4, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(9, 105, 'Composant Contact', 'composant-contact', '', '<p>Le composant «Contact» (com_contact) permet de proposer des fiches de  contacts avec ou sans formulaires. Il est ainsi possible de créer des   annuaires   complexes pour différents usages. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Components_Contacts_Contacts" target="_blank">Aide</a></p>', '', 1, 0, 0, 21, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 2, 0, 2, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(10, 106, 'Composant Contenu', 'composant-contenu', '', '<p style="text-align: justify;">Le composant «Contenu» (com_content) est celui que vous utilisez pour la gestion des articles. Il est extrêmement flexible et propose de très nombreux types d''affichage.</p><p style="text-align: justify;">Les articles peuvent être créés et édités depuis l''interface frontale du site, permettant une gestion des contenus simple et accessible à de non professionnels du Web. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Content_Article_Manager" target="_blank">Aide</a></p>', '', 1, 0, 0, 21, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 2, 0, 1, '', '', 1, 6, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(11, 107, 'Montagne Cradle ', 'montagne-cradle', '', '<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 73, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-17 04:42:36', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/landscape\\/250px_cradle_mountain_seen_from_barn_bluff.jpg","float_intro":"","image_intro_alt":"Cradle Mountain","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/landscape\\/800px_cradle_mountain_seen_from_barn_bluff.jpg","float_fulltext":"none","image_fulltext_alt":"Cradle Mountain","image_fulltext_caption":"Source: http:\\/\\/commons.wikimedia.org\\/wiki\\/File:Rainforest,bluemountainsNSW.jpg Author: Alan J.W.C. License: GNU Free Documentation License v . 1.2 or later"}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 1, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(12, 110, 'Module Contenu HTML personnalisé', 'module-contenu-personnalise', '', '<p style="text-align: justify;">Le  module «Contenu personnalisé» (mod_custom) permet d''afficher un contenu  HTML que vous avez créé à l''aide de l''éditeur WYSIWYG. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Custom_HTML" title="Custom HTML Module" target="_blank">Aide</a></p><div class="sample-module">{loadmodule custom,HTML personnalisé}</div>', '', 1, 0, 0, 66, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 13, 0, 1, '', '', 1, 13, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(13, 111, 'Venir à la boutique', 'venir-boutique', '', '<p>Comment venir jusqu''à la boutique ?</p><p><strong>En voiture</strong></p><p>Suivez la rue principale jusqu''à l''intersection avec le Boulevard des Remparts et cherchez notre enseigne.</p><p><strong>A pied</strong></p><p>Depuis le centre-ville, marchez vers le nord dans la rue principale jusqu''à voir notre enseigne.</p><p><strong>En bus</strong></p><p>Prenez le 73 jusqu''au terminus. Nous sommes à l''angle nord-est.</p>', '', 1, 0, 0, 29, '2012-01-01 00:00:01', 342, 'Fruit Shop Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 2, '', '', 1, 0, '', 0, '*', ''),
(14, 112, 'Plug-ins Éditeurs de contenu', 'plugins-editeurs', '', '<p style="text-align: justify;">Les éditeurs sont utilisés dans Joomla chaque fois que du contenu   doit être créé. TinyMCE est l''éditeur utilisé par défaut la plupart du   temps, alors que CodeMirror est utilisé dans le gestionnaire de   templates. "No Editor" permet de créer et modifier du code HTML.</p><p>Sont activés par défaut :</p><ul><li>Plug-in CodeMirror <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Editor_-_CodeMirror" target="_blank">Aide</a></li><li>Plug-in TinyMCE (par défaut) - <a href="http://www.tinymce.com/" target="_blank">Aide</a></li><li>Plug-in Non WYSIWYG <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Editor_-_None" target="_blank">Aide</a></li></ul><p>Sont désactivés par défaut :</p><ul><li>Aucun</li></ul>', '', 1, 0, 0, 25, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 2, 0, 5, '', '', 1, 0, '', 0, '*', ''),
(15, 113, 'Plug-ins Bouton', 'plugins-bouton-editeur', '', '<p style="text-align: justify;">Ces plug-ins correspondent aux boutons situés sous l''éditeur. Ils ne fonctionnent que si le plug-in est activé.</p><p>Sont activés par défaut :</p><ul><li>Plug-in Bouton image - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Button_-_Image" target="_blank">Aide</a></li><li>Plug-in Bouton Lire la suite - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Button_-_Readmore" target="_blank">Aide</a></li><li>Plug-in Bouton Saut de page - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Button_-_Pagebreak" target="_blank">Aide</a></li><li>Plug-in Bouton Article - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Button_-_Article" target="_blank">Aide</a></li></ul><p>Sont désactivés par défaut :</p><ul><li>Aucun</li></ul>', '', 1, 0, 0, 25, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 6, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(16, 114, 'Module Fil d''actualité', 'module-fil-actualite', '', '<p style="text-align: justify;">Le module «Fil d''actualité RSS/RDF/ATOM» (mod_feed) permet d''afficher grâce au flux d''actualité des articles provenant d''un autre site. <a href="http://docs.joomla.org/Help15:Screen.modulessite.edit.15#Feed_Display" title="Module Fil d''actualité RSS/RDF/ATOM" target="_blank">Aide</a></p><div class="sample-module">{loadmodule feed,Fil d''actualité}</div>', '', 1, 0, 0, 66, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 3, 0, 2, '', '', 1, 3, '', 0, '*', ''),
(17, 115, 'Premier article du blog', 'premier-article-blog', '', '<p><em>Lorem Ipsum is filler text that is commonly used by designers before the content for a new site is ready.</em></p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed faucibus purus vitae diam posuere nec eleifend elit dictum. Aenean sit amet erat purus, id fermentum lorem. Integer elementum tristique lectus, non posuere quam pretium sed. Quisque scelerisque erat at urna condimentum euismod. Fusce vestibulum facilisis est, a accumsan massa aliquam in. In auctor interdum mauris a luctus. Morbi euismod tempor dapibus. Duis dapibus posuere quam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In eu est nec erat sollicitudin hendrerit. Pellentesque sed turpis nunc, sit amet laoreet velit. Praesent vulputate semper nulla nec varius. Aenean aliquam, justo at blandit sodales, mauris leo viverra orci, sed sodales mauris orci vitae magna.</p>', '<p>Quisque a massa sed libero tristique suscipit. Morbi tristique molestie metus, vel vehicula nisl ultrices pretium. Sed sit amet est et sapien condimentum viverra. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus viverra tortor porta orci convallis ac cursus erat sagittis. Vivamus aliquam, purus non luctus adipiscing, orci urna imperdiet eros, sed tincidunt neque sapien et leo. Cras fermentum, dolor id tempor vestibulum, neque lectus luctus mauris, nec congue tellus arcu nec augue. Nulla quis mi arcu, in bibendum quam. Sed placerat laoreet fermentum. In varius lobortis consequat. Proin vulputate felis ac arcu lacinia adipiscing. Morbi molestie, massa id sagittis luctus, sem sapien sollicitudin quam, in vehicula quam lectus quis augue. Integer orci lectus, bibendum in fringilla sit amet, rutrum eget enim. Curabitur at libero vitae lectus gravida luctus. Nam mattis, ligula sit amet vestibulum feugiat, eros sem sodales mi, nec dignissim ante elit quis nisi. Nulla nec magna ut leo convallis sagittis ac non erat. Etiam in augue nulla, sed tristique orci. Vestibulum quis eleifend sapien.</p><p>Nam ut orci vel felis feugiat posuere ut eu lorem. In risus tellus, sodales eu eleifend sed, imperdiet id nulla. Nunc at enim lacus. Etiam dignissim, arcu quis accumsan varius, dui dui faucibus erat, in molestie mauris diam ac lacus. Sed sit amet egestas nunc. Nam sollicitudin lacinia sapien, non gravida eros convallis vitae. Integer vehicula dui a elit placerat venenatis. Nullam tincidunt ligula aliquet dui interdum feugiat. Maecenas ultricies, lacus quis facilisis vehicula, lectus diam consequat nunc, euismod eleifend metus felis eu mauris. Aliquam dapibus, ipsum a dapibus commodo, dolor arcu accumsan neque, et tempor metus arcu ut massa. Curabitur non risus vitae nisl ornare pellentesque. Pellentesque nec ipsum eu dolor sodales aliquet. Vestibulum egestas scelerisque tincidunt. Integer adipiscing ultrices erat vel rhoncus.</p><p>Integer ac lectus ligula. Nam ornare nisl id magna tincidunt ultrices. Phasellus est nisi, condimentum at sollicitudin vel, consequat eu ipsum. In venenatis ipsum in ligula tincidunt bibendum id et leo. Vivamus quis purus massa. Ut enim magna, pharetra ut condimentum malesuada, auctor ut ligula. Proin mollis, urna a aliquam rutrum, risus erat cursus odio, a convallis enim lectus ut lorem. Nullam semper egestas quam non mattis. Vestibulum venenatis aliquet arcu, consectetur pretium erat pulvinar vel. Vestibulum in aliquet arcu. Ut dolor sem, pellentesque sit amet vestibulum nec, tristique in orci. Sed lacinia metus vel purus pretium sit amet commodo neque condimentum.</p><p>Aenean laoreet aliquet ullamcorper. Nunc tincidunt luctus tellus, eu lobortis sapien tincidunt sed. Donec luctus accumsan sem, at porttitor arcu vestibulum in. Sed suscipit malesuada arcu, ac porttitor orci volutpat in. Vestibulum consectetur vulputate eros ut porttitor. Aenean dictum urna quis erat rutrum nec malesuada tellus elementum. Quisque faucibus, turpis nec consectetur vulputate, mi enim semper mi, nec porttitor libero magna ut lacus. Quisque sodales, leo ut fermentum ullamcorper, tellus augue gravida magna, eget ultricies felis dolor vitae justo. Vestibulum blandit placerat neque, imperdiet ornare ipsum malesuada sed. Quisque bibendum quam porta diam molestie luctus. Sed metus lectus, ornare eu vulputate vel, eleifend facilisis augue. Maecenas eget urna velit, ac volutpat velit. Nam id bibendum ligula. Donec pellentesque, velit eu convallis sodales, nisi dui egestas nunc, et scelerisque lectus quam ut ipsum.</p>', 1, 0, 0, 27, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 2, '', '', 1, 0, '', 0, '*', ''),
(18, 116, 'Second article du blog', 'second-article-blog', '', '<p><em>Lorem Ipsum is text that is traditionally used by designers when working on a site before the content is ready.</em></p><p>Pellentesque bibendum metus ut dolor fermentum ut pulvinar tortor hendrerit. Nam vel odio vel diam tempus iaculis in non urna. Curabitur scelerisque, nunc id interdum vestibulum, felis elit luctus dui, ac dapibus tellus mauris tempus augue. Duis congue facilisis lobortis. Phasellus neque erat, tincidunt non lacinia sit amet, rutrum vitae nunc. Sed placerat lacinia fermentum. Integer justo sem, cursus id tristique eget, accumsan vel sapien. Curabitur ipsum neque, elementum vel vestibulum ut, lobortis a nisl. Fusce malesuada mollis purus consectetur auctor. Morbi tellus nunc, dapibus sit amet rutrum vel, laoreet quis mauris. Aenean nec sem nec purus bibendum venenatis. Mauris auctor commodo libero, in adipiscing dui adipiscing eu. Praesent eget orci ac nunc sodales varius.</p>', '<p>Nam eget venenatis lorem. Vestibulum a interdum sapien. Suspendisse potenti. Quisque auctor purus nec sapien venenatis vehicula malesuada velit vehicula. Fusce vel diam dolor, quis facilisis tortor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Pellentesque libero nisi, pellentesque quis cursus sit amet, vehicula vitae nisl. Curabitur nec nunc ac sem tincidunt auctor. Phasellus in mattis magna. Donec consequat orci eget tortor ultricies rutrum. Mauris luctus vulputate molestie. Proin tincidunt vehicula euismod. Nam congue leo non erat cursus a adipiscing ipsum congue. Nulla iaculis purus sit amet turpis aliquam sit amet dapibus odio tincidunt. Ut augue diam, congue ut commodo pellentesque, fermentum mattis leo. Sed iaculis urna id enim dignissim sodales at a ipsum. Quisque varius lobortis mollis. Nunc purus magna, pellentesque pellentesque convallis sed, varius id ipsum. Etiam commodo mi mollis erat scelerisque fringilla. Nullam bibendum massa sagittis diam ornare rutrum.</p><p>Praesent convallis metus ut elit faucibus tempus in quis dui. Donec fringilla imperdiet nibh, sit amet fringilla velit congue et. Quisque commodo luctus ligula, vitae porttitor eros venenatis in. Praesent aliquet commodo orci id varius. Nulla nulla nibh, varius id volutpat nec, sagittis nec eros. Cras et dui justo. Curabitur malesuada facilisis neque, sed tempus massa tincidunt ut. Sed suscipit odio in lacus auctor vehicula non ut lacus. In hac habitasse platea dictumst. Sed nulla nisi, lacinia in viverra at, blandit vel tellus. Nulla metus erat, ultrices non pretium vel, varius nec sem. Morbi sollicitudin mattis lacus quis pharetra. Donec tincidunt mollis pretium. Proin non libero justo, vitae mattis diam. Integer vel elit in enim varius posuere sed vitae magna. Duis blandit tempor elementum. Vestibulum molestie dui nisi.</p><p>Curabitur volutpat interdum lorem sed tempus. Sed placerat quam non ligula lacinia sodales. Cras ultrices justo at nisi luctus hendrerit. Quisque sit amet placerat justo. In id sapien eu neque varius pharetra sed in sapien. Etiam nisl nunc, suscipit sed gravida sed, scelerisque ut nisl. Mauris quis massa nisl, aliquet posuere ligula. Etiam eget tortor mauris. Sed pellentesque vestibulum commodo. Mauris vitae est a libero dapibus dictum fringilla vitae magna.</p><p>Nulla facilisi. Praesent eget elit et mauris gravida lobortis ac nec risus. Ut vulputate ullamcorper est, volutpat feugiat lacus convallis non. Maecenas quis sem odio, et aliquam libero. Integer vel tortor eget orci tincidunt pulvinar interdum at erat. Integer ullamcorper consequat eros a pellentesque. Cras sagittis interdum enim in malesuada. Etiam non nunc neque. Fusce non ligula at tellus porta venenatis. Praesent tortor orci, fermentum sed tincidunt vel, varius vel dui. Duis pulvinar luctus odio, eget porta justo vulputate ac. Nulla varius feugiat lorem sed tempor. Phasellus pulvinar dapibus magna eget egestas. In malesuada lectus at justo pellentesque vitae rhoncus nulla ultrices. Proin ut sem sem. Donec eu suscipit ipsum. Cras eu arcu porttitor massa feugiat aliquet at quis nisl.</p>', 1, 0, 0, 27, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 0, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 1, '', '', 1, 0, '', 0, '*', ''),
(19, 117, 'Module Pied de page', 'module-pied-de-page', '', '<p style="text-align: justify;">Le module «Pied de page» (mod_footer) permet d''afficher l''information de copyright Joomla! en pied de page. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Footer" title="Module Pied de page" target="_blank">Aide</a></p><div class="sample-module">{loadmodule footer,Pied de page}</div>', '', 1, 0, 0, 66, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 4, 0, 3, '', '', 1, 4, '', 0, '*', ''),
(20, 118, 'Boutique de fruits', 'boutique-de-fruits', '', '<h2 style="text-align: justify;">Bienvenue dans la Boutique de fruits !</h2><p style="text-align: justify;">Nous vendons des fruits provenant du monde entier. Nous vous invitons à visiter notre site pour en savoir plus sur notre activité. Nous espérons que vous allez entrer dans la boutique et y acheter quelques   fruits.</p><p style="text-align: justify;"><em>Ce mini-site a pour but de vous montrer comment mettre en place  un  site commercial, ici celui d''une boutique vendant des fruits. Il  vous  montre comment utiliser la gestion d''accès pour gérer le contenu  de  votre site. Si vous créez un "vrai" site, vous voudrez peut-être en  un  e-commerce, un catalogue, y ajouter des listes de diffusion ou  autres  fonctionnalités dont vous trouverez un large choix sur le <a href="http://extensions.joomla.fr/" target="_blank">site francophone des extensions</a> ou sur </em><a href="http://extensions.joomla.org/" target="_blank"><em> Joomla! Extensions Directory</em></a>.</p><p style="text-align: justify;"><em>Pour mieux comprendre le fonctionnement de ce site, vous devriez   créer un utilisateur appartenant au groupe des clients et un autre au   groupe des producteurs. En vous connectant avec des droits différents, vous pourrez voir comment fonctionne ce contrôle d''accès.</em></p>', '', 1, 0, 0, 29, '2012-01-01 00:00:01', 342, 'Notre Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 1, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(21, 119, 'Obtenir de l''aide', 'obtenir-aide', '', '<p><img class="image-left" src="administrator/templates/hathor/images/header/icon-48-help_header.png" border="0" /> Vous pouvez obtenir de l''aide pour Joomla à différents endroits.</p><p>La plupart du temps, vous verrez cet icône d''aide. Cliquez sur cet icône pour accéder à plus d''informations concernant les options et fonctions en rapport avec la page sur laquelle vous vous trouvez.</p><ul><li><a href="http://forum.joomla.fr/" target="_blank">Forum francophone</a></li><li><a href="http://aide.joomla.fr/" target="_blank">Aide francophone</a></li><li><a href="http://forum.joomla.org/" target="_blank">Forum officiel (EN)</a></li><li><a href="http://docs.joomla.org/" target="_blank">Documentation (EN)</a></li><li><a href="http://resoures.joomla.org/" target="_blank">Liste de professionnels (EN)</a></li><li><a href="http://shop.joomla.org/amazoncom-bookstores.html" target="_blank">Livres sur Joomla! (EN)</a></li></ul>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 10, 0, 8, '', '', 1, 17, '', 0, '*', ''),
(22, 120, 'Comment débuter ?', 'comment-debuter', '', '<p style="text-align: justify;">La création d''un site web avec Joomla est simple, le déploiement de ce site exemple vous y aidera. <br />Les quelques principes de base présentés ci-dessous vous guideront dans la compréhension de ce logiciel.</p><h3>Qu''est-ce qu''un Système de Gestion de Contenu ?</h3><p style="text-align: justify;">Un   système de gestion de contenu (SGC ou CMS de l''anglais Content  Management System) est un logiciel qui vous permet de créer  et gérer  des pages Web facilement, séparant la création des contenus de la  gestion technique nécessaire à une diffusion sur le web.</p><p style="text-align: justify;">Le  contenu rédactionnel est stocké et restitué par une base de données, l''aspect (police, taille, couleur, emplacement, etc.) est géré par un  template (habillage du site). Le logiciel Joomla permet d''unir ces deux  structures de manière conviviale et de les rendre accessibles au plus  grand nombre d''utilisateurs.</p><h3>Deux interfaces</h3><p>Un site Joomla est structuré en deux parties distinctes : la partie visible du site appelée «Frontal» de <em>Front end</em> en anglais et, la partie d''administration pure appelée «Administration» de <em>Administrator</em>.</p><h3 style="text-align: justify;">Administration</h3><p style="text-align: justify;">Vous   pouvez accéder à l''administration en cliquant sur le sur le lien «Administration du site» présent dans le module de menu «Ce site» ou, en  ajoutant  <em>/administrator</em> dans l''URL après le nom de domaine.</p><p style="text-align: justify;">Utilisez le nom d''utilisateur et le mot de passe créés lors de l''installation de Joomla.</p><h3>Frontal</h3><p style="text-align: justify;">Si votre profil possède les droits suffisants, vous  pouvez créer des articles et les éditer depuis l''interface  frontale du site.</p><p style="text-align: justify;">Connectez-vous  par le module «Connexion» ou le lien de menu «Connexion» en utilisant  le nom d''utilisateur et le mot de passe créés lors de l''installation de  Joomla.</p><h3>Créer un article en frontal</h3><p style="text-align: justify;">Lorsque vous êtes connecté, un nouveau menu nommé «Menu Membres» apparaît. Cliquez sur le lien  «Proposer un article» pour afficher l''éditeur de texte et d''insertion de médias.</p><p style="text-align: justify;">Pour enregistrer l''article, vous devez insérer du contenu, spécifier à quelle catégorie il appartient et, son statut de publication. Pour le modifier, cliquez sur l''icône d''édition <img src="media/system/images/edit.png" border="0" alt="Editer un article" width="18" height="18" style="vertical-align: middle;" />.</p><p style="text-align: justify;">Vous pouvez travailler sur des articles non publiés ou de publication programmée et, dans le cadre d''un travail collaboratif, ne les rendre visibles qu''à un groupe d''utilisateurs donnés avant de les rendre publics.</p><h3>En savoir plus</h3><p>Une pleine utilisation de Joomla requiert certaines connaissances approfondies que vous pourrez acquérir dans la <a href="http://docs.joomla.org/" target="_blank">documentation officielle de Joomla</a> ou sur le <a href="http://aide.joomla.fr/" target="_blank">site d''aide francophone</a> et dans le <a href="http://forum.joomla.org/" target="_blank">forum officiel</a> ou le <a href="http://forum.joomla.fr/" target="_blank">forum francophone</a>.</p>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 9, '', '', 1, 5, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(23, 121, 'L''Orangeraie', 'orangeraie', '', '<p>Dans nos vergers, nous cultivons les meilleures oranges du monde, ainsi que d''autres agrumes tels que des citrons et pamplemousses. Notre famille s''occupe de ces vergers depuis des générations.</p>', '', 1, 0, 0, 30, '2012-01-01 00:00:01', 342, 'Fruit Shop Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 2, '', '', 1, 0, '', 0, '*', '');
INSERT INTO `m5jbw_content` (`id`, `asset_id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(24, 122, 'Joomla!', 'joomla', '', '<p style="text-align: justify;">Félicitations, vous venez de créer un site Joomla.</p><p style="text-align: justify;">Joomla rend facile la création d''un site tel que vous le rêvez et simplifie les mises à jour et la maintenance.</p><p style="text-align: justify;">Joomla est une plateforme flexible et puissante, que vous ayez besoin de créer un petit site pour vous-même ou un énorme site recevant des centaines de milliers de visiteurs.</p><p style="text-align: justify;">Joomla est Open Source, ce qui signifie que vous pouvez l''utiliser comme vous le souhaitez.</p>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"administrator/templates/bluestork/images/header/icon-48-themes.png","float_intro":"left","image_intro_alt":"Bienvenue sur votre site Joomla!","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 2, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(25, 123, 'Koala', 'koala', '', '<p> </p>\r\n<p> </p>\r\n<p> </p>\r\n<p> </p>\r\n<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 72, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/animals\\/180px_koala_ag1.jpg","float_intro":"","image_intro_alt":"Koala  Miniature","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/animals\\/800px_koala_ag1.jpg","float_fulltext":"","image_fulltext_alt":"Koala Climbing Tree","image_fulltext_caption":"Source: http:\\/\\/commons.wikimedia.org\\/wiki\\/File:Koala-ag1.jpg Author: Arnaud Gaillard License: Creative Commons Share Alike Attribution Generic 1.0"}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 9, 0, 2, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(26, 124, 'Module Sélecteur de langue', 'module-selecteur-langue', '', '<p style="text-align: justify;">Le  module «Sélecteur de langue» (mod_languages) permet d''afficher les labels propres à Joomla dans une des langues présentes dans la liste. Ces langues correspondent au packs de langue installés dans Joomla. Le changement de langue affectera également l''affichage des contenus articles ou modules, des menus et des liens s''ils ont été traduits.</p><p style="text-align: justify;">Lors d''un changement de langue, l''utilisateur est redirigé sur la page d''accueil définie pour la langue choisie. Par la suite, la navigation s''effectuera dans la langue choisie.</p><p style="text-align: justify;"><em>Le plug-in de filtrage des langues doit être activé pour que ce module fonctionne correctement.</em> <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Language_Switcher" title="Module Sélecteur de langue" target="_blank">Aide</a></p><p style="text-align: justify;">Pour voir le module de changement de langue en action, aller dans l''administration du site et activez le plug-in de filtrage des langues et le module de changement de langue puis, visitez le site de la boutique de fruits ou celui des parcs australiens. <a href="http://info-graf.fr/trunk/fr/instructions-multilangue" target="_blank">Suivez ensuite les instructions dans ce tutoriel</a>.</p>', '', 1, 0, 0, 67, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, 3, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(27, 125, 'Module Derniers articles', 'module-derniers-articles', '', '<p style="text-align: justify;">Le module «Derniers articles» (mod_articles_latest) montre une liste des articles les plus récents. Certains peuvent avoir une date d''expiration dépassée, même s''ils font partie des plus récents. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Latest_News" title="Latest Articles" target="_blank">Aide</a></p><div class="sample-module">{loadmodule articles_latest,Derniers articles}</div>', '', 1, 0, 0, 64, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 9, 0, 1, 'modules, content', '', 1, 15, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(28, 126, 'Module Connexion', 'module-connexion', '', '<p style="text-align: justify;">Le  module «Connexion» (mod_login) affiche un formulaire de saisie  d''identifiant et mot de passe. Il comporte également un lien permettant  de régénérer un mot de passe oublié. Si l''enregistrement des  utilisateurs est activé (dans les paramètres généraux du site), un autre  lien permet au visiteurs de créer leur compte de membre. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Login" target="_blank" title="Module Connexion">Aide</a></p><div class="sample-module">{loadmodule login,Identification}</div>', '', 1, 0, 0, 65, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 4, 0, 2, '', '', 1, 5, '', 0, '*', ''),
(29, 127, 'Module de Menu', 'module-menu', '', '<p style="text-align: justify;">Le module «Menu» (mod_menu) permet d''afficher un menu dans l''interface  frontale du site. Les menus peuvent être affichés sous différentes  formes en utilisant les options de paramétrage et les styles de menu CSS. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Menu" target="_blank">Aide</a></p><div class="sample-module">{loadmodule mod_menu,Menu exemple}</div>', '', 1, 0, 0, 75, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 8, 0, 1, '', '', 1, 12, '', 0, '*', ''),
(30, 128, 'Module Articles les plus consultés', 'articles-plus-consultes', '', '<p style="text-align: justify;">Le  module «Articles les plus consultés» (mod_articles_popular) affiche une liste  des articles publiés, dont le nombre de pages vues est le plus élevé. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Most_Read" title="Articles les plus consultés" target="_blank">Aide</a></p><div class="sample-module">{loadmodule articles_popular,Articles les plus consultés}</div>', '', 1, 0, 0, 64, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 0, 2, 'modules, content', '', 1, 10, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(31, 129, 'Module Flash info', 'module-flash-infos', '', '<p style="text-align: justify;">Le  module «Flash info» (mod_articles_news) permet d''afficher un nombre  donné d''articles appartenant à une catégorie définie, triés par date ou  par sélection aléatoire. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Articles_Newsflash" target="_blank" title="Module Flash info" target="_blank">Aide</a></p><div class="sample-module">{loadmodule articles_news,Flash info}</div>', '', 1, 0, 0, 64, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","page_title":"","alternative_readmore":"","layout":""}', 4, 0, 3, 'modules, content', '', 1, 10, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(32, 130, 'Paramètres d''affichage', 'parametres-affichage', '', '<p style="text-align: justify;">Vous pouvez contrôler les détails d''affichage par des «Paramètres» ; par exemple si le nom de l''auteur est affiché, qui peut voir quoi, le nombre d''éléments d''une liste, etc.</p><p style="text-align: justify;">Les paramètres par défaut de chaque composant peuvent être modifiés en utilisant le bouton «Paramètres» de la barre d''outils du composant.</p><p style="text-align: justify;">Les paramètres peuvent également être changés pour un élément unique, comme un article, un contact, au niveau du lien de menu correspondant.</p><p style="text-align: justify;">Si les valeurs par défaut créées lors de l''installation du site vous conviennent, conservez-les. Lorsque vous  aurez  plus d''expérience avec Joomla, vous serez en mesure de les adapter plus finement.</p>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 10, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(33, 131, 'Phyllopteryx', 'phyllopteryx', '', '<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 72, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/animals\\/200px_phyllopteryx_taeniolatus1.jpg","float_intro":"","image_intro_alt":"Phyllopteryx","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/animals\\/800px_phyllopteryx_taeniolatus1.jpg","float_fulltext":"","image_fulltext_alt":"Phyllopteryx","image_fulltext_caption":"Source: http:\\/\\/en.wikipedia.org\\/wiki\\/File:Phyllopteryx_taeniolatus1.jpg Author: Richard Ling License: GNU Free Documentation License v 1.2 or later"}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 3, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(34, 132, 'Pinnacles', 'pinnacles', '', '<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 73, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/landscape\\/120px_pinnacles_western_australia.jpg","float_intro":"","image_intro_alt":"Kings Canyon","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/landscape\\/800px_pinnacles_western_australia.jpg","float_fulltext":"","image_fulltext_alt":"Kings Canyon","image_fulltext_caption":"Source: http:\\/\\/commons.wikimedia.org\\/wiki\\/File:Pinnacles_Western_Australia.jpg  Author: Martin Gloss  License: GNU Free Documentation license v 1.2 or later."}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, 4, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(35, 133, 'Professionnels', 'professionnels', '', '<p style="text-align: justify;">Joomla 2.5 est, dans la continuité du développement du Framework Joomla, un moyen puissant et flexible de transformer votre projet web en réalité. Avec son administration désormais totalement MVC, la possibilité de contrôler son aspect et la gestion de ses extensions est maintenant complète.</p>', '<p style="text-align: justify;">Créer le design que vous souhaitez est plus simple que jamais avec les styles des templates et les fichiers dupliqués puis personnalisés (overrides).</p><p style="text-align: justify;">L''utilisation uniquement de PHP5 et supérieur ainsi que la   suppression du mode legacy pour la rétrocompatibilité des extensions créées pour Joomla 1.0 rend ce CMS plus léger et plus rapide que jamais. Les fichiers langue peuvent désormais être chargés sans risque de perte des modifications lors de mises à jour. Les extensions dotées de fichiers XML appropriés pourront être mis à jour depuis l''administration d''un simple clic.</p><p style="text-align: justify;">Les listes de contrôle d''accès sont maintenant intégrées, utilisant un nouveau système développé pour Joomla 1.6. Ce système ACL a été pensé pour les développeurs, afin qu''il soit simple à incorporer dans les extensions.</p><p>Une nouvelle bibliothèque de formulaire permet d''en créer de toutes sortes, rendant plus simple l''interaction avec les utilisateurs.</p><p>La bibliothèque de scripts MooTools 1.2 fournit un framework javascript très flexible qui est une avancée majeure par rapport à MooTools 1.0.</p><p style="text-align: justify;">Une nouvelle gestion des événements à travers le moteur Joomla facilite la création de plug-ins et améliore leur application.</p><p>Pour en savoir plus :</p><ul><li><a href="http://docs.joomla.org/ACL_Tutorial_for_Joomla_1.6" target="_blank>Les ACL de Joomla!</a></li><li><a href="http://docs.joomla.org/API16:JCategories" target="_blank>Les catégories imbriquées</a></li><li><a href="http://docs.joomla.org/API16:JForm" target="_blank>Bibliothèque JForm</a></li><li><a href="http://docs.joomla.org/Working_with_Mootools_1.3" target="_blank>Mootools 1.3</a></li><li><a href="http://docs.joomla.org/Layout_Overrides_in_Joomla_1.6" target="_blank>Le système "Override"</a></li><li><a href="http://api.joomla.org" target="_blank>Joomla! API</a></li><li><a href="http://docs.joomla.org/API16:JDatabaseQuery" target="_blank>Utilisation de  JDatabaseQuery</a></li><li><a href="http://docs.joomla.org/What''s_new_in_Joomla_1.6#Events" target="_blank>Nouveautés et mise à jour</a></li><li><a href="http://docs.joomla.org/Xml-rpc_changes_in_Joomla!_1.6" target="_blank>Système Xmlrpc</a></li><li><a href="http://docs.joomla.org/What''s_new_in_Joomla_1.6#Extension_management" target="_blank>Installation et mise à jour d''extensions</a></li><li><a href="http://docs.joomla.org/Setting_up_your_workstation_for_Joomla!_development" target="_blank>Configuration de votre environnement de développement</a></li><li><a href="github.com/joomla" target="_blank>Platforme référentielle de Joomla!</a></li></ul>', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"administrator/templates/bluestork/images/header/icon-48-config.png","float_intro":"left","image_intro_alt":"Professionnels Joomla!","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 16, 0, 5, '', '', 1, 11, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(36, 134, 'Module Image aléatoire', 'module-image-aleatoire', '', '<p>Le module «Image aléatoire» (mod_random_image) affiche une image aléatoire présente dans le dossier sélectionné. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Random_Image" target="_blank" title="Module Image aléatoire">Aide</a></p><div class="sample-module">{loadmodule random_image,Image aléatoire}</div>', '', 1, 0, 0, 66, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 0, 4, '', '', 1, 6, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(37, 135, 'Module Articles en relation', 'module-articles-relation', '', '<p style="text-align: justify;">Le module «Articles en relation» (mod_related_items) affiche les articles en relation avec  celui consulté. Les relations sont faites à parti des mots-clés. Tous les mots-clés de l''article en cours de visualisation sont comparés à ceux de tous les autres articles publiés. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Articles_Related" title="Module Articles en relation" target="_blank>Aide</a></p><div class="sample-module">{loadmodule related_items,Articles en relation}</div>', '', 1, 0, 0, 64, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 0, 4, 'modules, content', '', 1, 5, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(38, 136, 'Sites exemples', 'sites-exemples', '', '<p style="text-align: justify;">L''installation inclut des données exemples destinées à vous montrer   quelques-unes des possibilités que propose Joomla pour construire un site   web. En plus des informations sur Joomla, deux sites   exemples (sites dans le site) ont été inclus dans le but de vous aider à créer   votre propre site.</p><p style="text-align: justify;">Le premier est un simple site sur les <a href="index.php?Itemid=243">Parcs australiens</a>.   Il vous montre comment on peut créer rapidement et facilement un site   personnel avec les seuls éléments de base de Joomla. Il comprend un   blog personnel, des liens web et une galerie d''images très simple.</p><p style="text-align: justify;">Le second site est légèrement plus complexe et vous présente ce que   vous auriez à faire pour créer un site pour une petite entreprise, dans cet exemple il s''agit d''une <a href="index.php?Itemid=429">boutique de fruits</a> .</p><p style="text-align: justify;">Lors de la construction d''un tel site, ou de quelque chose de   totalement différent, vous aurez probablement envie ou besoin d''ajouter   des <a href="http://extensions.joomla.org/" target="_blank">extensions </a>et de créer ou acheter votre propre template. La plupart des utilisateurs commencent par modifier les <a href="http://docs.joomla.org/How_do_you_modify_a_template%3F" target="_blank">templates</a> livrés avec Joomla en incluant des images et d''autres éléments de design en relation avec le sujet de leur site.</p>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 11, '', '', 1, 6, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(39, 137, 'Composant Recherche', 'composant-recherche', '', '<p>Joomla! 2.5 offre deux options de recherche.</p><p>Le composant «Recherche» (com_search) offre des fonctionnalités de recherche sur les informations contenues dans les composants système. De nombreuses extensions tierces peuvent être également incluses dans cette recherche à l''aide de plug-ins additifs. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Components_Search" target="_blank">Aide</a></p>\r\n<p>Le composant «Recherche avancée» (com_finder) offre une recherche semblable à celle des principaux moteurs de recherche.<br />La recherche avancée est désactivée par défaut. Si vous choisissez de l''activer, vous devez effectuer les opérations suivantes : <ul><li>activer le plug-in de recherche avancée dans le gestionnaire des plug-ins ;</li><li>si le module de recherche est publié, le dépublier et publier celui de la recherche avancée ;</li><li>accéder au gestionnaire de recherche avancée, et cliquer sur le bouton «Index» pour indexer les contenus existants.</li></ul> </p>', '', 1, 0, 0, 21, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 3, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(40, 138, 'Module de Recherche', 'module-recherche', '', '<p style="text-align: justify;">Le  module «Recherche» (mod_search) affiche un champ de formulaire pour  effectuer une recherche dans les pages du site. Les contenus explorés  dépendent des plug-ins activés (voir Plug-ins Recherche).</p><p><a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Search" target="_blank" title="Module Recherche">Aide</a></p><div class="sample-module">{loadmodule search,Recherche}</div>', '', 1, 0, 0, 67, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 4, 0, 4, '', '', 1, 6, '', 0, '*', ''),
(41, 139, 'Plug-ins de recherche', 'plugins-recherche', '', '<p style="text-align: justify;">Le composant de recherche utilise des plug-ins contrôlant quelles types de contenus doivent être explorés. De nombreuses   extensions tierces comprennent des plug-ins étendant le champ de   recherche.</p><p style="text-align: justify;">Si les recherches sont particulièrement longue, vous pouvez les accélérer en désactivant les plug-ins de recherche qui ne sont pas indispensables.</p><p>Sont activés par défaut :</p><ul><li>Plug-in Contenu (content) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Search_-_Content" target="_blank">Aide</a></li><li>Plug-in Contacts (contacts) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Search_-_Contacts" target="_blank">Aide</a></li><li>Plug-in Liens web (weblinks) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Search_-_Weblinks" target="_blank">Aide</a></li><li>Plug-in Flux RSS (newsfeeds) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Search_-_Newsfeeds" target="_blank">Aide</a></li><li>Plug-in Catégories (categories) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Search_-_Categories" target="_blank">Aide</a></li></ul>', '', 1, 0, 0, 25, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 3, 0, 1, '', '', 1, 0, '', 0, '*', ''),
(42, 140, 'Plan du site', 'plan-site', '', '<p>{loadposition sitemapload}</p><p><em>En plaçant tout vos articles dans des catégories, vous permettez aux    visiteurs et aux moteurs de recherche d''y accéder depuis  un menu.</em></p>', '', 1, 0, 0, 14, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 1, '', '', 1, 1, '', 0, '*', ''),
(43, 141, 'Chat marsupial', 'chat-marsupial', '', '<p> </p>\r\n<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 72, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/animals\\/220px_spottedquoll_2005_seanmcclean.jpg","float_intro":"","image_intro_alt":"Spotted Quoll","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/animals\\/789px_spottedquoll_2005_seanmcclean.jpg","float_fulltext":"","image_fulltext_alt":"Spotted Quoll","image_fulltext_caption":"Source: http:\\/\\/en.wikipedia.org\\/wiki\\/File:SpottedQuoll_2005_SeanMcClean.jpg Author: Sean McClean License: GNU Free Documentation License v 1.2 or later"}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 4, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(44, 142, 'Module Statistiques', 'module-statistiques', '', '<p>Le module «Statistiques» (mod_stats) affiche des informations sur votre serveur, ainsi que des statistiques sur les visiteurs de votre site  Web, le nombre d''articles dans votre base de données ou le nombre de liens web.</p><div class="sample-module">{loadmodule mod_stats,Statistiques}</div>', '', 1, 0, 0, 67, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 0, 5, '', '', 1, 5, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(45, 143, 'Module Lien de flux RSS ou ATOM', 'module-flux-actualite', '', '<p style="text-align: justify;">Le  module «Lien de flux RSS ou ATOM» (mod_syndicate) permet d''afficher un lien RSS ou ATOM de flux d''actualité permettant d''afficher les articles de votre site sur un autre site ou un lecteur de flux d''actualité. Ce module ne s''affiche que sur les pages où cette fonctionnalité est disponible. Cela signifie qu''il ne s''affichera pas sur une page d''article unique, de contact ou de lien web telle la présente page. <a href="http://docs.joomla.org/Help15:Screen.modulessite.edit.15#Syndicate" target="_blank" title="Module Flux RSS">Aide</a></p><div class="sample-module">{loadposition syndicate,Flux RSS/ATOM}</div>', '', 1, 0, 0, 67, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, 6, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(46, 144, 'Plug-ins système', 'plugins-systeme', '', '<p style="text-align: justify;">Les plug-ins système interviennent à chaque chargement de page de   votre site. Ils contrôlent de nombreuses fonctions telles les URL, le cache, la mémorisation de connexion, etc.</p><p style="text-align: justify;">Une nouveauté à partir de la version 1.6 : le plug-in de redirection qui permet de gérer les changements d''URL.</p><p>Sont activés par défaut :</p><ul><li>Plug-in Mémorisation (remember) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#System_-_Remember_Me" target="_blank">Aide</a></li><li>Plug-in SEF (sef) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#System_-_SEF" target="_blank">Aide</a></li><li>Plug-in Débogage (debug) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#System_-_Debug" target="_blank">Aide</a></li></ul><p>Sont désactivés par défaut :</p><ul><li>Plug-in Cache (cache) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#System_-_Cache" target="_blank">Aide</a></li><li>Plug-in Rapport de connexion (log) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#System_-_Log" target="_blank">Aide</a></li><li>Plug-in Redirection (redirect) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#System_-_Redirect" target="_blank">Aide</a></li><li>Plug-in Filtre de langue (languagefilter) - <a href="http://info-graf.fr/trunk/fr/instructions-multilangue" target="_blank">Aide FR</></li></ul>', '', 1, 0, 0, 25, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 0, 2, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(47, 145, 'La Communauté Joomla!', 'communaute-joomla', '', '<p style="text-align: justify;">Joomla est la transcription phonétique d''un mot swahili qui signifie «Tous  Ensemble», représentant cette communauté de milliers de personnes qui, travaillant ensemble et avec plaisir, rendent le projet Joomla!   possible.</p><p style="text-align: justify;">Nous  espérons que vous ferez partie de cette communauté à votre  tour en  réalisant vos sites web avec Joomla, les personnes de toutes  compétences, de tous niveaux et du monde entier   sont les bienvenues.</p><p style="text-align: justify;">Partagez vos expériences, vos découvertes (le <a href="http://forum.joomla.fr/" target="_blank">forum </a>est idéal pour démarrer), participez à un JoomlaDay ou un <a href="http://community.joomla.org/events.html" target="_blank">Joomla! event</a>, rejoignez ou créez un <a href="http://www.joomgroupe.fr/" target="_blank">Joomgroupe</a>, que vous soyez développeur, administrateur de site, graphiste, utilisateur final ou simple fan, il existe de nombreuses manières de participer.</p>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, 3, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(48, 146, 'Le "Projet Joomla!"', 'projet-joomla', '', '<p style="text-align: justify;">Le projet Joomla se compose de toutes les personnes qui utilisent et/ou soutiennent Joomla.</p><p style="text-align: justify;">Notre mission est de fournir une plate-forme flexible pour la publication numérique et le travail collaboratif.</p><p style="text-align: justify;">Les valeurs fondamentales sont les suivantes:</p><ul><li>Liberté</li><li>Égalité</li><li>Confiance</li><li>Communauté</li><li>Collaboration</li><li>Facilité d''utilisation</li></ul><p>Les objectifs sont les suivants :</p><ul><li>Les personnes qui publient et collaborent en communauté à travers le monde</li><li>Un logiciel qui est gratuit, sécurisé et de haute qualité</li><li>Une communauté agréable à laquelle il est gratifiant de participer</li><li>Accessibilité à toutes les personnes du monde, dans leur langue préférée</li><li>Un projet évoluant de façon autonome</li><li>Un projet socialement responsable</li><li>Un projet destiné à conserver la confiance de ses utilisateurs</li></ul><p style="text-align: justify;">Il y a, répartis dans le monde, des millions d''utilisateurs de Joomla et des milliers de personnes qui contribuent à son développement.</p><p style="text-align: justify;">Le projet Joomla se divise en trois secteurs :</p><ul><li>le groupe «Production» chargé de tout ce qui est dans le logiciel et la documentation ;</li><li>le groupe «Communauté», responsable des relations avec la communauté ;</li><li>Open Source Matters, l''organisation à  but non lucratif responsable de la gestion juridique, financière et des questions d''organisation.</li></ul><p>Joomla! est un projet libre et open source, sous licence GNU General Public version 2 ou plus.</p>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 1, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(49, 147, 'Typographie', 'typographie', '', '<h1>H1 ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmonpqrstuvwzyz</h1><h2>H2 ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmonpqrstuvwzyz</h2><h3>H3 ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmonpqrstuvwzyz</h3><h4>H4 ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmonpqrstuvwzyz</h4><h5>H5 ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmonpqrstuvwzyz</h5><h6>H6 ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmonpqrstuvwzyz</h6><p>P Le rapide  renard brun a couru sur le chien paresseux. LE RAPIDE RENARD BRUN A COURU SUR LE CHIEN PARESSEUX.</p><ul><li>élément</li><li>élément</li><li>élément   <ul><li>élément</li><li>élément</li><li>élément   <ul><li>élément</li><li>élément</li><li>élément</li></ul></li></ul></li></ul><ol><li>élément</li><li>élément</li><li>élément <ol><li>élément</li><li>élément</li><li>élément<ol><li>élément</li><li>élément</li><li>élément</li></ol></li></ol> </li></ol>', '', 1, 0, 0, 23, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 1, '', '', 1, 0, '', 0, '*', '');
INSERT INTO `m5jbw_content` (`id`, `asset_id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(50, 148, 'Habitués', 'habitues', '', '<p style="text-align:justify">Si vous êtes un habitué de Joomla! 1.5, la version 2.5 vous paraîtra très familière. Elle possède de nouveaux templates et une interface    utilisateur améliorée, mais la plupart des fonctionnalités sont identiques. Les changements les plus importants sont l''amélioration du contrôle d''accès (ACL) et celle de la gestion multi-niveaux des catégories.</p>', '<p>Le nouveau gestionnaire d''utilisateurs vous permettra de gérer qui à accès à quoi dans votre site. Vous pouvez conserver l''organisation des groupes d''accès tel que vous la connaissez dans Joomla! 1.5 ou la rendre aussi complexe que nécessaire. Vous pourrez en savoir plus sur <a href="http://docs.joomla.org/ACL_Tutorial_for_Joomla_1.6" target="_blank">comment fonctionne le contrôle d''accès</a> sur le <a href="http://docs.joomla.org/" target="_blank">site de documentation Joomla!</a> (liens en anglais).</p><p>Le contenu de Joomla! 1.5 et 1.0 était organisé en sections et catégories. Depuis la version 1.6, les sections sont supprimées et vous pouvez créer des catégories <span style="text-decoration: underline;">dans</span> des catégories, en allant aussi loin  que vous le souhaitez. Les exemples vous montrent différentes  utilisations des catégories imbriquées.</p><p>Toutes les maquettes ont été redéfinies pour améliorer l''accessibilité et la flexibilité. Si vous voulez conserver les thèmes de la version 1.5, vous les trouverez dans le répertoire html du template MilkyWay. Copiez simplement dans votre template les gabarits que vous voulez.</p><p>Mettre à jour votre site et vos extensions quand nécessaire sera plus simple que jamais, grâce aux améliorations de l''installeur.</p><p>Pour en savoir plus sur <strong>comment migrer un site Joomla! 1.5 en version 2.5</strong>, lisez cet <a href="http://docs.joomla.org/Migrating_from_1.5_to_1.6" target="_blank">article</a>.</p>', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"administrator/templates/bluestork/images/header/icon-48-banner-tracks.png","float_intro":"left","image_intro_alt":"Habitués Joomla!","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 0, 6, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(51, 149, 'Plug-ins Utilisateurs', 'plugins-utilisateur', '', '<p>Est activé par défaut :</p><ul><li>Plug-in Joomla! - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#User_-_Joomla.21" target="_blank">Aide</a></li></ul><p style="text-align: justify;">Deux nouveaux plugins sont disponibles depuis la version 1.6 de Joomla, mais sont désactivés par défaut :</p><ul><li>Plug-in Création fiche de contact (contactcreator) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#User_-_Contact_Creator" target="_blank">Aide</a><br />Crée une nouvelle fiche de contact pour chaque nouvel utilisateur enregistré</li><li>Plug-in Exemple de profil (profile) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#User_-_Profile" target="_blank">Aide</a><br />Exemple d''insertion de champs  supplémentaires dans  le formulaire d''enregistrement des utilisateurs et dans l''affichage du profil. Ce plug-in se veut être un exemple des types d''extensions de profil que vous pouvez créer</li></ul>', '', 1, 0, 0, 25, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, 4, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(52, 150, 'Composant Utilisateurs', 'composant-utilisateurs', '', '<p style="text-align: justify;">Le  composant «Utilisateurs» (com_users) permet à vos visiteurs de  s''enregistrer, se connecter et se déconnecter, changer leur mot de  passe et d''autres informations, régénérer leur mot de passe en cas de  perte. Côté administration, il vous permet de créer, gérer et bloquer  les utilisateurs, de créer des groupes et des niveaux d''accès.</p><p style="text-align: justify;">Notez que certaines pages réservées aux utilisateurs enregistrés ne seront visibles qu''après identification. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Users_User_Manager" target="_blank">Aide</a></p>', '', 1, 0, 0, 21, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 2, 0, 5, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(53, 151, 'Utiliser Joomla!', 'utiliser-joomla', '', '<p style="text-align: justify;">Avec  Joomla, vous pouvez créer un simple site personnel   comme un site  e-commerce complexe ou un réseau social avec des   millions de  visiteurs.</p><p style="text-align: justify;">Cette  section d''exemples vous propose une brève introduction aux   concepts et  fonctions de référence afin de vous aider à   comprendre comment  fonctionne Joomla.</p><p style="text-align: justify;">Lorsque vous n''aurez plus besoin de ces exemples, vous pourrez désactiver ces articles ou, dans l''administration du site, désactiver leur catégorie ou supprimer tous les articles puis toutes les   catégories.</p>', '', 1, 0, 0, 19, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 7, '', '', 1, 12, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(54, 152, 'Composant Liens web', 'composant-liens-web', '', '<p>Le composant «Liens Web» (com_weblinks) permet d''organiser de manière structurée les liens externes et de les présenter de manière attractive, cohérente et instructive. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Components_Weblinks_Links" target="_blank">Aide</a></p>', '', 1, 0, 0, 21, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 2, 0, 6, '', '', 1, 4, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(55, 153, 'Module de Liens Web', 'module-liens-web', '', '<p>Le module «Liens web» (mod_weblinks) affiche la liste des liens d''une catégorie spécifique de liens web.  <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Weblinks" title="Weblinks Module" target="_blank">Aide</a></p><div class="sample-module">{loadmodule weblinks,Liens web}</div>', '', 1, 0, 0, 66, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 7, 0, 5, '', '', 1, 23, '', 0, '*', ''),
(56, 154, 'Module Qui est en ligne ?', 'module-qui-est-en-ligne', '', '<p style="text-align: justify;">Le  module «Qui est en ligne ?» (mod_whosonline) affiche le nombre d''invités  (visiteurs   anonymes) et de membres enregistrés connectés sur le site. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Who_Online" title="Who''s Online" target="_blank">Aide</a></p><div class="sample-module">{loadmodule whosonline,Qui est en ligne}</div>', '', 1, 0, 0, 65, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 4, 0, 1, '', '', 1, 5, '', 0, '*', ''),
(57, 155, 'Requins-tapis', 'requins-tapis', '', '<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 72, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/animals\\/180px_wobbegong.jpg","float_intro":"","image_intro_alt":"Wobbegon","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/animals\\/800px_wobbegong.jpg","float_fulltext":"","image_fulltext_alt":"Wobbegon","image_fulltext_caption":"Source: http:\\/\\/en.wikipedia.org\\/wiki\\/File:Wobbegong.jpg Author: Richard Ling Rights: GNU Free Documentation License v 1.2 or later"}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 1, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(58, 156, 'Merveilleuses pastèques', 'merveilleuses-pasteques', '', '<p>La pastèque est un véritable festin, particulièrement sain.</p><p style="text-align: justify;">Nous produisons les pastèques les plus suaves au monde et avons la plus grande variété de pastèques de tout le pays.</p>', '', 1, 0, 0, 30, '2012-01-01 00:00:01', 342, 'Fruit Shop Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 1, '', '', 1, 0, '', 0, '*', ''),
(59, 157, 'Module Fenêtre intégrée', 'module-fenetre-integree', '', '<p style="text-align: justify;">Le  module «Fenêtre intégrée» (mod_wrapper) permet d''afficher une page d''un  autre site dans une fenêtre intégrée (Iframe ou Wrapper). <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Wrapper" title="Wrapper Module" target="_blank">Aide</a></p><div class="sample-module">{loadmodule wrapper,Fenêtre intégrée}</div>', '', 1, 0, 0, 67, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 8, 0, 1, '', '', 1, 15, '', 0, '*', ''),
(60, 158, 'Composant Fils d''actualité', 'composant-fils-actualite', '', '<p style="text-align: justify;">Le composant «Fils d''actualité» (com_newsfeeds) permet d''organiser et présenter sur votre site des informations provenant d''autres sites par le biais de flux RSS, RDF ou ATOM. Par exemple, les sites joomla.org et joomla.fr proposent de nombreux flux que vous pouvez afficher sur votre site. Vous pouvez utiliser les menus pour afficher un fil d''actualité unique, une liste de fils d''actualité d''une catégorie, ou la liste de toutes les catégories de fils d''actualité. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Components_Newsfeeds_Feeds" target="_blank">Aide</a></p>', '', 1, 0, 0, 21, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, 4, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(61, 159, 'Module Fil de navigation', 'module-fil-navigation', '', '<p>Le module «Fil de navigation» (mod_breadcrumbs) permet d''afficher le chemin parcouru dans le site. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Breadcrumbs" title="Module Fil de navigation" target="_blank">Aide</a></p><div class="sample-module">{loadmodule breadcrumbs,breadcrumbs}</div>', '', 1, 0, 0, 75, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 5, 0, 2, '', '', 1, 9, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(62, 160, 'Plug-ins de contenu', 'plugins-contenu', '', '<p>Les plug-ins de contenu s''exécutent quand certains éléments insérés dans un contenu sont chargés.</p><p>Sont activés par défaut :</p><ul><li>Plug-in Protection des adresses e-mails (emailcloak) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Content_-_Email_Cloaking" target="_blank">Aide</a></li><li>Plug-in Chargement de module (loadmodule) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Content_-_Load_Modules" target="_blank">Aide</a></li><li>Plug-in Saut de page (article divisé en plusieurs pages - pagebreak) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Content_-_Pagebreak" target="_blank">Aide</a></li><li>Plug-in Page Navigation (insertion des liens Suivant et Précédent - pagenavigation) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Content_-_Page_Navigation" target="_blank">Aide</a></li><li>Plug-in Vote (vote sur les articles) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Content_-_Vote" target="_blank">Aide</a></li></ul><p>Est désactivé par défaut :</p><ul><li>Code Highlighting (Geshi) - <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit#Content_-_Code_Highlighter_.28GeSHi.29" target="_blank">Aide</a></li></ul>', '', 1, 0, 0, 25, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 2, 0, 7, '', '', 1, 1, '', 0, '*', ''),
(64, 162, 'Montagne bleue', 'montagne-bleue', '', '<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 73, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/landscape\\/120px_rainforest_bluemountainsnsw.jpg","float_intro":"none","image_intro_alt":"Rain Forest Blue Mountains","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/landscape\\/727px_rainforest_bluemountainsnsw.jpg","float_fulltext":"","image_fulltext_alt":"Rain Forest Blue Mountains","image_fulltext_caption":"Source: http:\\/\\/commons.wikimedia.org\\/wiki\\/File:Rainforest,bluemountainsNSW.jpg Author: Adam J.W.C. License: GNU Free Documentation License"}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, 2, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(65, 163, 'Ormiston Pound', 'ormiston-pound', '', '<p> </p>\r\n', '\r\n<p> </p>', 1, 0, 0, 73, '2012-01-01 00:00:01', 342, 'Parks Webmaster', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '{"image_intro":"images\\/sampledata\\/parks\\/landscape\\/180px_ormiston_pound.jpg","float_intro":"none","image_intro_alt":"Ormiston Pound","image_intro_caption":"","image_fulltext":"images\\/sampledata\\/parks\\/landscape\\/800px_ormiston_pound.jpg","float_fulltext":"","image_fulltext_alt":"Ormiston Pound","image_fulltext_caption":"Source: http:\\/\\/commons.wikimedia.org\\/wiki\\/File:Ormiston_Pound.JPG Author: License: GNU Free Public Documentation License"}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 0, 3, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(66, 165, 'Module Derniers inscrits', 'module-derniers-inscrits', '', '<p>Le module «Derniers inscrits» (mod_users_latest) affiche la liste des derniers utilisateurs inscrits sur le site.  <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;keyref=Help16:Extensions_Module_Manager_Latest_Users" target="_blank">Aide</a></p><div class="sample-module">{loadmodule users_latest,Derniers Inscrits}</div>', '', 1, 0, 0, 65, '2012-01-01 00:00:01', 342, 'Joomla!', '2012-01-01 00:00:01', 42, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"1","link_titles":"","show_intro":"","show_category":"1","link_category":"1","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 4, 0, 3, '', '', 1, 6, '', 0, '*', ''),
(67, 168, 'Qu''y a-t-il de nouveau dans Joomla 1.5?', 'nouveau-dans-joomla-15', '', '<p>Cet article est délibérément archivé comme exemple.</p><p>As with previous releases, Joomla! provides a unified and easy-to-use framework for delivering content for Web sites of all kinds. To support the changing nature of the Internet and emerging Web technologies, Joomla! required substantial restructuring of its core functionality and we also used this effort to simplify many challenges within the current user interface. Joomla! 1.5 has many new features.</p>\r\n<p style="margin-bottom: 0in;">In Joomla! 1.5, you''''ll notice:</p>\r\n<ul>\r\n<li>Substantially improved usability, manageability, and scalability far beyond the original Mambo foundations</li>\r\n<li>Expanded accessibility to support internationalisation, double-byte characters and right-to-left support for Arabic, Farsi, and Hebrew languages among others</li>\r\n<li>Extended integration of external applications through Web services</li>\r\n<li>Enhanced content delivery, template and presentation capabilities to support accessibility standards and content delivery to any destination</li>\r\n<li>A more sustainable and flexible framework for Component and Extension developers</li>\r\n<li>Backward compatibility with previous releases of Components, Templates, Modules, and other Extensions</li>\r\n</ul>', '', 2, 0, 0, 9, '2012-01-01 00:00:01', 342, 'Joomla! 1.5', '2012-01-01 00:00:01', 0, 0, '0000-00-00 00:00:00', '2012-01-01 00:00:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_readmore":"","show_print_icon":"","show_email_icon":"","show_hits":"","page_title":"","alternative_readmore":"","layout":""}', 1, 0, 0, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(68, 170, 'Captcha', 'captcha', '', '<p>Les plug-ins Captcha sont utilisés pour éviter le spam par les formulaires tels que ceux d''inscription, de contact et de connexion. L''installation de base de Joomla inclut un plug-in Captcha qui utilise le service de ReCaptcha®, mais vous pouvez installer d''autres plug-ins qui utilisent différents systèmes Captcha.</p>\r\n<p>Actif par défaut:</p>\r\n<ul>\r\n<li>ReCaptcha <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit">Aide</a></li>\r\n</ul>\r\n<p>Note: Pour obtenir la clé d''utilisation de ReCaptcha®, vous devez vous inscrire sur le site Recaptcha.net et accepter les conditions d''utilisation. Des instructions complètes sont disponibles dans l''interface d''édition du plug-in, disponible par la getsion des plug-ins de Joomla.</p>', '', 1, 0, 0, 25, '2012-01-17 03:20:45', 342, 'Joomla!', '2012-01-17 03:35:46', 42, 0, '0000-00-00 00:00:00', '2012-01-17 03:20:45', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, 1, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(69, 171, 'Icônes de raccourci', 'icones-raccourci', '', '<p>Le groupe des plug-ins "Icône raccourci" permet d''afficher des icônes d''alerte sur la page d''accueil de l''administration si une mise à jour pour Joomla ou pour une extension tierce installée est disponible. Ces plug-ins sont liés au module "Icônes de raccourcis" par un nom de groupe qui doit être identique dans les plug-ins et le module.</p>\r\n<p>Activé par défaut:</p>\r\n<ul>\r\n<li>Icône raccourci - Alerte de mises à jour Joomla! <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit">Aide</a>.</li>\r\n<li>Icône raccourci - Alerte de mises à jour d''extensions <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help17:Extensions_Plugin_Manager_Edit">Aide</a></li>\r\n</ul>', '', 1, 0, 0, 25, '2012-01-17 03:27:39', 342, 'Joomla!', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2012-01-17 03:27:39', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 0, 0, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(70, 170, 'Module Recherche avancée', 'recherche-avance', '', '<p>Le module «Recherche avancée» (mod_finder) propose une recherche utilisant l''indexation du composant de recherche avancée. Vous ne devez l''utiliser que si vous avez indexé votre contenu, activé le plug-in de recherche avancée, et que vous actualisez l''index du site lorsque des modifications sont apportées aux contenus ou que de nouveaux sont créés. <a href="http://help.joomla.org/proxy/index.php?option=com_help&amp;amp;keyref=Help25:Extensions_Module_Manager_Smart_Search">Aide</a>.</p>\r\n<div class="sample-module">{loadmodule finder,Smart Search}</div>', '', 1, 0, 0, 67, '2012-01-17 03:42:36', 342, '', '2012-01-17 16:15:48', 42, 0, '0000-00-00 00:00:00', '2012-01-17 03:42:36', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":"","urlatext":"","targeta":"","urlb":"","urlbtext":"","targetb":"","urlc":"","urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 10, 0, 0, '', '', 1, 13, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_content_frontpage`
--

DROP TABLE IF EXISTS `m5jbw_content_frontpage`;
CREATE TABLE IF NOT EXISTS `m5jbw_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_content_frontpage`
--

INSERT INTO `m5jbw_content_frontpage` (`content_id`, `ordering`) VALUES
(8, 2),
(35, 4),
(24, 1),
(50, 3);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_content_rating`
--

DROP TABLE IF EXISTS `m5jbw_content_rating`;
CREATE TABLE IF NOT EXISTS `m5jbw_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_content_rating`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_core_log_searches`
--

DROP TABLE IF EXISTS `m5jbw_core_log_searches`;
CREATE TABLE IF NOT EXISTS `m5jbw_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_core_log_searches`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_countries`
--

DROP TABLE IF EXISTS `m5jbw_countries`;
CREATE TABLE IF NOT EXISTS `m5jbw_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hits` int(11) NOT NULL DEFAULT '0',
  `iso` varchar(2) NOT NULL,
  `iso3` varchar(3) NOT NULL,
  `numcode` smallint(6) NOT NULL,
  `phone_code` varchar(5) NOT NULL,
  `currency` varchar(50) NOT NULL,
  `iso4217` varchar(5) NOT NULL,
  `currency_symbol` varchar(5) NOT NULL,
  `active_currency` int(1) NOT NULL DEFAULT '0',
  `currency_format` varchar(25) NOT NULL DEFAULT '2,''.'','' ''',
  `fr` varchar(255) NOT NULL,
  `en` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=239 ;

--
-- Contenu de la table `m5jbw_countries`
--

INSERT INTO `m5jbw_countries` (`id`, `hits`, `iso`, `iso3`, `numcode`, `phone_code`, `currency`, `iso4217`, `currency_symbol`, `active_currency`, `currency_format`, `fr`, `en`) VALUES
(1, 0, 'AF', 'AFG', 4, '93', 'Afghan afghani', 'AFN', '', 0, '', 'Afghanistan', 'Afghanistan'),
(2, 0, 'ZA', 'ZAF', 710, '27', 'South African rand', 'ZAR', 'R', 0, '', 'Afrique du Sud', 'South Africa'),
(3, 0, 'AL', 'ALB', 8, '355', 'Albanian lek', 'ALL', '', 0, '', 'Albanie', 'Albania'),
(4, 0, 'DZ', 'DZA', 12, '213', 'Algerian dinar', 'DZD', '', 0, '', 'Algérie', 'Algeria'),
(5, 1, 'DE', 'DEU', 276, '49', 'European euro', 'EUR', '€', 0, '', 'Allemagne', 'Germany'),
(6, 0, 'AD', 'AND', 20, '376', '', '', '', 0, '', 'Andorre', 'Andorra'),
(7, 0, 'AO', 'AGO', 24, '244', 'Angolan kwanza', 'AOA', '', 0, '', 'Angola', 'Angola'),
(8, 0, 'AI', 'AIA', 660, '1264', '', '', '', 0, '', 'Anguilla', 'Anguilla'),
(9, 0, 'AQ', '', 0, '', '', '', '', 0, '', 'Antarctique', 'Antarctica'),
(10, 0, 'AG', 'ATG', 28, '1268', '', '', '', 0, '', 'Antigua-et-Barbuda', 'Antigua and Barbuda'),
(11, 0, 'AN', 'ANT', 530, '599', 'Netherlands Antillean gulden', 'ANG', 'NAƒ', 0, '', 'Antilles néerlandaises', 'Netherlands Antilles'),
(12, 0, 'SA', 'SAU', 682, '966', 'Saudi riyal', 'SAR', 'SR', 0, '', 'Arabie saoudite', 'Saudi Arabia'),
(13, 0, 'AR', 'ARG', 32, '54', 'Argentine peso', 'ARS', '', 0, '', 'Argentine', 'Argentina'),
(14, 0, 'AM', 'ARM', 51, '374', 'Armenian dram', 'AMD', '', 0, '', 'Arménie', 'Armenia'),
(15, 0, 'AW', 'ABW', 533, '297', 'Aruban florin', 'AWG', 'ƒ', 0, '', 'Aruba', 'Aruba'),
(16, 0, 'AU', 'AUS', 36, '61', 'Australian dollar', 'AUD', '$', 0, '', 'Australie', 'Australia'),
(17, 0, 'AT', 'AUT', 40, '43', 'European euro', 'EUR', '€', 0, '', 'Autriche', 'Austria'),
(18, 0, 'AZ', 'AZE', 31, '994', 'Azerbaijani manat', 'AZN', '', 0, '', 'Azerbaïdjan', 'Azerbaijan'),
(19, 0, 'BJ', 'BEN', 204, '229', '', '', '', 0, '', 'Bénin', 'Benin'),
(20, 0, 'BS', 'BHS', 44, '1242', 'Bahamian dollar', 'BSD', 'B$', 0, '', 'Bahamas', 'Bahamas'),
(21, 0, 'BH', 'BHR', 48, '973', 'Bahraini dinar', 'BHD', '', 0, '', 'Bahreïn', 'Bahrain'),
(22, 0, 'BD', 'BGD', 50, '880', 'Bangladeshi taka', 'BDT', '', 0, '', 'Bangladesh', 'Bangladesh'),
(23, 0, 'BB', 'BRB', 52, '1246', 'Barbadian dollar', 'BBD', 'Bds$', 0, '', 'Barbade', 'Barbados'),
(24, 0, 'PW', 'PLW', 585, '680', '', '', '', 0, '', 'Belau', 'Palau'),
(25, 1, 'BE', 'BEL', 56, '32', 'European euro', 'EUR', '€', 0, '', 'Belgique', 'Belgium'),
(26, 0, 'BZ', 'BLZ', 84, '501', 'Belize dollar', 'BZD', 'BZ$', 0, '', 'Belize', 'Belize'),
(27, 0, 'BM', 'BMU', 60, '1441', 'Bermudian dollar', 'BMD', 'BD$', 0, '', 'Bermudes', 'Bermuda'),
(28, 0, 'BT', 'BTN', 64, '975', 'Bhutanese ngultrum', 'BTN', 'Nu.', 0, '', 'Bhoutan', 'Bhutan'),
(29, 0, 'BY', 'BLR', 112, '375', 'Belarusian ruble', 'BYR', 'Br', 0, '', 'Biélorussie', 'Belarus'),
(30, 0, 'MM', 'MMR', 104, '95', 'Myanma kyat', 'MMK', 'K', 0, '', 'Birmanie', 'Myanmar'),
(31, 0, 'BO', 'BOL', 68, '591', 'Bolivian boliviano', 'BOB', 'Bs.', 0, '', 'Bolivie', 'Bolivia'),
(32, 0, 'BA', 'BIH', 70, '387', 'Bosnia and Herzegovina konvertibilna marka', 'BAM', 'KM', 0, '', 'Bosnie-Herzégovine', 'Bosnia and Herzegovina'),
(33, 0, 'BW', 'BWA', 72, '267', 'Botswana pula', 'BWP', 'P', 0, '', 'Botswana', 'Botswana'),
(34, 0, 'BR', 'BRA', 76, '55', 'Brazilian real', 'BRL', 'R$', 0, '', 'Brésil', 'Brazil'),
(35, 0, 'BN', 'BRN', 96, '673', 'Brunei dollar', 'BND', 'B$', 0, '', 'Brunei', 'Brunei Darussalam'),
(36, 0, 'BG', 'BGR', 100, '359', 'Bulgarian lev', 'BGN', '', 0, '', 'Bulgarie', 'Bulgaria'),
(37, 0, 'BF', 'BFA', 854, '226', '', '', '', 0, '', 'Burkina Faso', 'Burkina Faso'),
(38, 0, 'BI', 'BDI', 108, '257', 'Burundi franc', 'BIF', 'FBu', 0, '', 'Burundi', 'Burundi'),
(39, 0, 'CI', 'CIV', 384, '225', '', '', '', 0, '', 'Côte d''Ivoire', 'Cote D''Ivoire'),
(40, 0, 'KH', 'KHM', 116, '855', 'Cambodian riel', 'KHR', '', 0, '', 'Cambodge', 'Cambodia'),
(41, 0, 'CM', 'CMR', 120, '237', '', '', '', 0, '', 'Cameroun', 'Cameroon'),
(42, 0, 'CA', 'CAN', 124, '1', 'Canadian dollar', 'CAD', '$', 0, '', 'Canada', 'Canada'),
(43, 0, 'CV', 'CPV', 132, '238', 'Cape Verdean escudo', 'CVE', 'Esc', 0, '', 'Cap-Vert', 'Cape Verde'),
(44, 0, 'CL', 'CHL', 152, '56', 'Chilean peso', 'CLP', '$', 0, '', 'Chili', 'Chile'),
(45, 2, 'CN', 'CHN', 156, '86', 'Chinese renminbi', 'CNY', '¥', 0, '', 'Chine', 'China'),
(46, 0, 'CY', 'CYP', 196, '357', 'European euro', 'EUR', '€', 0, '', 'Chypre', 'Cyprus'),
(47, 0, 'CO', 'COL', 170, '57', 'Colombian peso', 'COP', 'Col$', 0, '', 'Colombie', 'Colombia'),
(48, 0, 'KM', 'COM', 174, '269', 'Comorian franc', 'KMF', '', 0, '', 'Comores', 'Comoros'),
(49, 0, 'CG', 'COG', 178, '242', '', '', '', 0, '', 'Congo', 'Congo'),
(50, 0, 'KP', 'PRK', 408, '850', 'North Korean won', 'KPW', 'W', 0, '', 'Corée du Nord', 'Korea, Democratic People''s Republic of'),
(51, 0, 'KR', 'KOR', 410, '82', 'South Korean won', 'KRW', 'W', 0, '', 'Corée du Sud', 'Korea, Republic of'),
(52, 0, 'CR', 'CRI', 188, '506', 'Costa Rican colon', 'CRC', '¢', 0, '', 'Costa Rica', 'Costa Rica'),
(53, 0, 'HR', 'HRV', 191, '385', 'Croatian kuna', 'HRK', 'kn', 0, '', 'Croatie', 'Croatia'),
(54, 0, 'CU', 'CUB', 192, '53', 'Cuban peso', 'CUC', '$', 0, '', 'Cuba', 'Cuba'),
(55, 0, 'DK', 'DNK', 208, '45', 'Danish krone', 'DKK', 'Kr', 0, '', 'Danemark', 'Denmark'),
(56, 0, 'DJ', 'DJI', 262, '253', 'Djiboutian franc', 'DJF', 'Fdj', 0, '', 'Djibouti', 'Djibouti'),
(57, 0, 'DM', 'DMA', 212, '1767', '', '', '', 0, '', 'Dominique', 'Dominica'),
(58, 0, 'EG', 'EGY', 818, '20', 'Egyptian pound', 'EGP', '£', 0, '', 'Egypte', 'Egypt'),
(59, 0, 'AE', 'ARE', 784, '971', 'UAE dirham', 'AED', '', 0, '', 'Emirats arabes unis', 'United Arab Emirates'),
(60, 0, 'EC', 'ECU', 218, '593', '', '', '', 0, '', 'Equateur', 'Ecuador'),
(61, 0, 'ER', 'ERI', 232, '291', 'Eritrean nakfa', 'ERN', 'Nfa', 0, '', 'Erythrée', 'Eritrea'),
(62, 0, 'ES', 'ESP', 724, '34', 'European euro', 'EUR', '€', 0, '', 'Espagne', 'Spain'),
(63, 0, 'EE', 'EST', 233, '372', 'Estonian kroon', 'EEK', 'KR', 0, '', 'Estonie', 'Estonia'),
(64, 0, 'US', 'USA', 840, '1', 'United States dollar', 'USD', 'US$', 1, '2/''.''/'',''', 'Etats-Unis', 'United States'),
(65, 0, 'ET', 'ETH', 231, '251', 'Ethiopian birr', 'ETB', 'Br', 0, '', 'Ethiopie', 'Ethiopia'),
(66, 0, 'FI', 'FIN', 246, '358', 'European euro', 'EUR', '€', 0, '', 'Finlande', 'Finland'),
(67, 1, 'FR', 'FRA', 250, '33', 'European euro', 'EUR', '€', 1, '2/''.''/'' ''', 'France', 'France'),
(68, 0, 'GE', 'GEO', 268, '995', 'Georgian lari', 'GEL', '', 0, '', 'Géorgie', 'Georgia'),
(69, 0, 'GA', 'GAB', 266, '241', '', '', '', 0, '', 'Gabon', 'Gabon'),
(70, 0, 'GM', 'GMB', 270, '220', 'Gambian dalasi', 'GMD', 'D', 0, '', 'Gambie', 'Gambia'),
(71, 0, 'GH', 'GHA', 288, '233', 'Ghanaian cedi', 'GHS', '', 0, '', 'Ghana', 'Ghana'),
(72, 0, 'GI', 'GIB', 292, '350', 'Gibraltar pound', 'GIP', '£', 0, '', 'Gibraltar', 'Gibraltar'),
(73, 0, 'GR', 'GRC', 300, '30', 'European euro', 'EUR', '€', 0, '', 'Grèce', 'Greece'),
(74, 0, 'GD', 'GRD', 308, '1473', '', '', '', 0, '', 'Grenade', 'Grenada'),
(75, 0, 'GL', 'GRL', 304, '299', '', '', '', 0, '', 'Groenland', 'Greenland'),
(76, 0, 'GP', 'GLP', 312, '590', '', '', '', 0, '', 'Guadeloupe', 'Guadeloupe'),
(77, 0, 'GU', 'GUM', 316, '671', '', '', '', 0, '', 'Guam', 'Guam'),
(78, 0, 'GT', 'GTM', 320, '502', 'Guatemalan quetzal', 'GTQ', 'Q', 0, '', 'Guatemala', 'Guatemala'),
(79, 0, 'GN', 'GIN', 324, '224', 'Guinean franc', 'GNF', 'FG', 0, '', 'Guinée', 'Guinea'),
(80, 0, 'GQ', 'GNQ', 226, '240', 'Central African CFA franc', 'GQE', 'CFA', 0, '', 'Guinée équatoriale', 'Equatorial Guinea'),
(81, 0, 'GW', 'GNB', 624, '245', '', '', '', 0, '', 'Guinée-Bissao', 'Guinea-Bissau'),
(82, 0, 'GY', 'GUY', 328, '592', 'Guyanese dollar', 'GYD', 'GY$', 0, '', 'Guyana', 'Guyana'),
(83, 0, 'GF', 'GUF', 254, '592', '', '', '', 0, '', 'Guyane française', 'French Guiana'),
(84, 0, 'HT', 'HTI', 332, '509', 'Haitian gourde', 'HTG', 'G', 0, '', 'Haïti', 'Haiti'),
(85, 0, 'HN', 'HND', 340, '504', 'Honduran lempira', 'HNL', 'L', 0, '', 'Honduras', 'Honduras'),
(86, 1, 'HK', 'HKG', 344, '852', 'Hong Kong dollar', 'HKD', 'HK$', 0, '', 'Hong Kong', 'Hong Kong'),
(87, 0, 'HU', 'HUN', 348, '36', 'Hungarian forint', 'HUF', 'Ft', 0, '', 'Hongrie', 'Hungary'),
(88, 0, 'BV', '', 0, '', '', '', '', 0, '', 'Ile Bouvet', 'Bouvet Island'),
(89, 0, 'CX', '', 0, '', '', '', '', 0, '', 'Ile Christmas', 'Christmas Island'),
(90, 0, 'NF', 'NFK', 574, '672', '', '', '', 0, '', 'Ile Norfolk', 'Norfolk Island'),
(91, 0, 'KY', 'CYM', 136, '1345', 'Cayman Islands dollar', 'KYD', 'KY$', 0, '', 'Iles Cayman', 'Cayman Islands'),
(92, 0, 'CK', 'COK', 184, '682', '', '', '', 0, '', 'Iles Cook', 'Cook Islands'),
(93, 0, 'FO', 'FRO', 234, '298', '', '', '', 0, '', 'Iles Féroé', 'Faroe Islands'),
(94, 0, 'FK', 'FLK', 238, '500', 'Falkland Islands pound', 'FKP', '£', 0, '', 'Iles Falkland', 'Falkland Islands (Malvinas)'),
(95, 0, 'FJ', 'FJI', 242, '679', 'Fijian dollar', 'FJD', 'FJ$', 0, '', 'Iles Fidji', 'Fiji'),
(96, 0, 'GS', '', 0, '', '', '', '', 0, '', 'Iles Géorgie du Sud et Sandwich du Sud', 'South Georgia and the South Sandwich Islands'),
(97, 0, 'HM', '', 0, '', '', '', '', 0, '', 'Iles Heard et McDonald', 'Heard Island and Mcdonald Islands'),
(98, 0, 'MH', 'MHL', 584, '692', '', '', '', 0, '', 'Iles Marshall', 'Marshall Islands'),
(99, 0, 'PN', 'PCN', 612, '', '', '', '', 0, '', 'Iles Pitcairn', 'Pitcairn'),
(100, 0, 'SB', 'SLB', 90, '677', 'Solomon Islands dollar', 'SBD', 'SI$', 0, '', 'Iles Salomon', 'Solomon Islands'),
(101, 0, 'SJ', 'SJM', 744, '', '', '', '', 0, '', 'Iles Svalbard et Jan Mayen', 'Svalbard and Jan Mayen'),
(102, 0, 'TC', 'TCA', 796, '1649', '', '', '', 0, '', 'Iles Turks-et-Caicos', 'Turks and Caicos Islands'),
(103, 0, 'VI', 'VIR', 850, '1', '', '', '', 0, '', 'Iles Vierges américaines', 'Virgin Islands, U.s.'),
(104, 0, 'VG', 'VGB', 92, '1284', '', '', '', 0, '', 'Iles Vierges britanniques', 'Virgin Islands, British'),
(105, 0, 'CC', '', 0, '', '', '', '', 0, '', 'Iles des Cocos (Keeling)', 'Cocos (Keeling) Islands'),
(106, 0, 'UM', '', 0, '', '', '', '', 0, '', 'Iles mineures éloignées des Etats-Unis', 'United States Minor Outlying Islands'),
(107, 0, 'IN', 'IND', 356, '91', 'Indian rupee', 'INR', 'Rs', 0, '', 'Inde', 'India'),
(108, 0, 'ID', 'IDN', 360, '62', 'Indonesian rupiah', 'IDR', 'Rp', 0, '', 'Indonésie', 'Indonesia'),
(109, 0, 'IR', 'IRN', 364, '98', 'Iranian rial', 'IRR', '', 0, '', 'Iran', 'Iran, Islamic Republic of'),
(110, 0, 'IQ', 'IRQ', 368, '964', 'Iraqi dinar', 'IQD', '', 0, '', 'Iraq', 'Iraq'),
(111, 0, 'IE', 'IRL', 372, '353', 'European euro', 'EUR', '€', 0, '', 'Irlande', 'Ireland'),
(112, 0, 'IS', 'ISL', 352, '354', 'Icelandic kr?na', 'ISK', 'kr', 0, '', 'Islande', 'Iceland'),
(114, 1, 'IT', 'ITA', 380, '39', 'European euro', 'EUR', '€', 0, '', 'Italie', 'Italy'),
(115, 0, 'JM', 'JAM', 388, '1876', 'Jamaican dollar', 'JMD', 'J$', 0, '', 'Jamaïque', 'Jamaica'),
(116, 1, 'JP', 'JPN', 392, '81', 'Japanese yen', 'JPY', '¥', 1, '2/''.''/'' ''', 'Japon', 'Japan'),
(117, 0, 'JO', 'JOR', 400, '962', 'Jordanian dinar', 'JOD', '', 0, '', 'Jordanie', 'Jordan'),
(118, 0, 'KZ', 'KAZ', 398, '', 'Kazakhstani tenge', 'KZT', 'T', 0, '', 'Kazakhstan', 'Kazakhstan'),
(119, 0, 'KE', 'KEN', 404, '254', 'Kenyan shilling', 'KES', 'KSh', 0, '', 'Kenya', 'Kenya'),
(120, 0, 'KG', 'KGZ', 417, '996', 'Kyrgyzstani som', 'KGS', '', 0, '', 'Kirghizistan', 'Kyrgyzstan'),
(121, 0, 'KI', 'KIR', 296, '686', '', '', '', 0, '', 'Kiribati', 'Kiribati'),
(122, 0, 'KW', 'KWT', 414, '965', 'Kuwaiti dinar', 'KWD', '', 0, '', 'Koweït', 'Kuwait'),
(123, 0, 'LA', 'LAO', 418, '', 'Lao kip', 'LAK', 'KN', 0, '', 'Laos', 'Lao People''s Democratic Republic'),
(124, 0, 'LS', 'LSO', 426, '266', 'Lesotho loti', 'LSL', 'M', 0, '', 'Lesotho', 'Lesotho'),
(125, 0, 'LV', 'LVA', 428, '371', 'Latvian lats', 'LVL', 'Ls', 0, '', 'Lettonie', 'Latvia'),
(126, 0, 'LB', 'LBN', 422, '961', 'Lebanese lira', 'LBP', '', 0, '', 'Liban', 'Lebanon'),
(127, 0, 'LR', 'LBR', 430, '231', 'Liberian dollar', 'LRD', 'L$', 0, '', 'Liberia', 'Liberia'),
(128, 0, 'LY', 'LBY', 434, '218', 'Libyan dinar', 'LYD', 'LD', 0, '', 'Libye', 'Libyan Arab Jamahiriya'),
(129, 0, 'LI', 'LIE', 438, '', '', '', '', 0, '', 'Liechtenstein', 'Liechtenstein'),
(130, 0, 'LT', 'LTU', 440, '370', 'Lithuanian litas', 'LTL', 'Lt', 0, '', 'Lituanie', 'Lithuania'),
(131, 0, 'LU', 'LUX', 442, '352', 'European euro', 'EUR', '€', 0, '', 'Luxembourg', 'Luxembourg'),
(132, 0, 'MO', 'MAC', 446, '853', 'Macanese pataca', 'MOP', 'P', 0, '', 'Macao', 'Macao'),
(133, 0, 'MG', 'MDG', 450, '261', 'Malagasy ariary', 'MGA', 'FMG', 0, '', 'Madagascar', 'Madagascar'),
(134, 0, 'MY', 'MYS', 458, '60', 'Malaysian ringgit', 'MYR', 'RM', 0, '', 'Malaisie', 'Malaysia'),
(135, 0, 'MW', 'MWI', 454, '265', 'Malawian kwacha', 'MWK', 'MK', 0, '', 'Malawi', 'Malawi'),
(136, 0, 'MV', 'MDV', 462, '960', 'Maldivian rufiyaa', 'MVR', 'Rf', 0, '', 'Maldives', 'Maldives'),
(137, 0, 'ML', 'MLI', 466, '223', '', '', '', 0, '', 'Mali', 'Mali'),
(138, 0, 'MT', 'MLT', 470, '356', 'European Euro', 'EUR', '€', 0, '', 'Malte', 'Malta'),
(139, 0, 'MP', 'MNP', 580, '670', '', '', '', 0, '', 'Mariannes du Nord', 'Northern Mariana Islands'),
(140, 0, 'MA', 'MAR', 504, '212', 'Moroccan dirham', 'MAD', '', 0, '', 'Maroc', 'Morocco'),
(141, 0, 'MQ', 'MTQ', 474, '', '', '', '', 0, '', 'Martinique', 'Martinique'),
(142, 0, 'MU', 'MUS', 480, '230', 'Mauritian rupee', 'MUR', 'Rs', 0, '', 'Maurice', 'Mauritius'),
(143, 0, 'MR', 'MRT', 478, '222', 'Mauritanian ouguiya', 'MRO', 'UM', 0, '', 'Mauritanie', 'Mauritania'),
(144, 0, 'YT', '', 0, '', '', '', '', 0, '', 'Mayotte', 'Mayotte'),
(145, 0, 'MX', 'MEX', 484, '52', 'Mexican peso', 'MXN', '$', 0, '', 'Mexique', 'Mexico'),
(146, 0, 'FM', 'FSM', 583, '691', '', '', '', 0, '', 'Micronésie', 'Micronesia, Federated States of'),
(147, 0, 'MD', 'MDA', 498, '373', 'Moldovan leu', 'MDL', '', 0, '', 'Moldavie', 'Moldova, Republic of'),
(148, 0, 'MC', 'MCO', 492, '377', '', '', '', 0, '', 'Monaco', 'Monaco'),
(149, 0, 'MN', 'MNG', 496, '976', 'Mongolian tugrik', 'MNT', '?', 0, '', 'Mongolie', 'Mongolia'),
(150, 0, 'MS', 'MSR', 500, '1664', '', '', '', 0, '', 'Montserrat', 'Montserrat'),
(151, 0, 'MZ', 'MOZ', 508, '258', 'Mozambican metical', 'MZM', 'MTn', 0, '', 'Mozambique', 'Mozambique'),
(152, 0, 'NP', 'NPL', 524, '977', 'Nepalese rupee', 'NPR', 'NRs', 0, '', 'Népal', 'Nepal'),
(153, 0, 'NA', 'NAM', 516, '264', 'Namibian dollar', 'NAD', 'N$', 0, '', 'Namibie', 'Namibia'),
(154, 0, 'NR', 'NRU', 520, '674', '', '', '', 0, '', 'Nauru', 'Nauru'),
(155, 0, 'NI', 'NIC', 558, '505', 'Nicaraguan c?rdoba', 'NIO', 'C$', 0, '', 'Nicaragua', 'Nicaragua'),
(156, 0, 'NE', 'NER', 562, '227', '', '', '', 0, '', 'Niger', 'Niger'),
(157, 0, 'NG', 'NGA', 566, '234', 'Nigerian naira', 'NGN', '?', 0, '', 'Nigeria', 'Nigeria'),
(158, 0, 'NU', 'NIU', 570, '683', '', '', '', 0, '', 'Nioué', 'Niue'),
(159, 0, 'NO', 'NOR', 578, '47', 'Norwegian krone', 'NOK', 'kr', 0, '', 'Norvège', 'Norway'),
(160, 0, 'NC', 'NCL', 540, '687', '', '', '', 0, '', 'Nouvelle-Calédonie', 'New Caledonia'),
(161, 0, 'NZ', 'NZL', 554, '64', 'New Zealand dollar', 'NZD', 'NZ$', 0, '', 'Nouvelle-Zélande', 'New Zealand'),
(162, 0, 'OM', 'OMN', 512, '968', 'Omani rial', 'OMR', '', 0, '', 'Oman', 'Oman'),
(163, 0, 'UG', 'UGA', 800, '256', 'Ugandan shilling', 'UGX', 'USh', 0, '', 'Ouganda', 'Uganda'),
(164, 0, 'UZ', 'UZB', 860, '998', 'Uzbekistani som', 'UZS', '', 0, '', 'Ouzbékistan', 'Uzbekistan'),
(165, 0, 'PE', 'PER', 604, '51', 'Peruvian nuevo sol', 'PEN', 'S/.', 0, '', 'Pérou', 'Peru'),
(166, 0, 'PK', 'PAK', 586, '92', 'Pakistani rupee', 'PKR', 'Rs.', 0, '', 'Pakistan', 'Pakistan'),
(167, 0, 'PA', 'PAN', 591, '507', 'Panamanian balboa', 'PAB', 'B./', 0, '', 'Panama', 'Panama'),
(168, 0, 'PG', 'PNG', 598, '675', 'Papua New Guinean kina', 'PGK', 'K', 0, '', 'Papouasie-Nouvelle-Guinée', 'Papua New Guinea'),
(169, 0, 'PY', 'PRY', 600, '595', 'Paraguayan guarani', 'PYG', '', 0, '', 'Paraguay', 'Paraguay'),
(170, 0, 'NL', 'NLD', 528, '31', 'European euro', 'EUR', '€', 0, '', 'Pays-Bas', 'Netherlands'),
(171, 0, 'PH', 'PHL', 608, '63', 'Philippine peso', 'PHP', '?', 0, '', 'Philippines', 'Philippines'),
(172, 0, 'PL', 'POL', 616, '48', 'Polish zloty', 'PLN', '', 0, '', 'Pologne', 'Poland'),
(173, 0, 'PF', 'PYF', 258, '689', '', '', '', 0, '', 'Polynésie française', 'French Polynesia'),
(174, 0, 'PR', 'PRI', 630, '', '', '', '', 0, '', 'Porto Rico', 'Puerto Rico'),
(175, 0, 'PT', 'PRT', 620, '351', 'European euro', 'EUR', '€', 0, '', 'Portugal', 'Portugal'),
(176, 0, 'QA', 'QAT', 634, '974', 'Qatari riyal', 'QAR', 'QR', 0, '', 'Qatar', 'Qatar'),
(177, 0, 'CF', 'CAF', 140, '236', '', '', '', 0, '', 'République centrafricaine', 'Central African Republic'),
(178, 0, 'CD', 'COD', 180, '242', 'Congolese franc', 'CDF', 'F', 0, '', 'République démocratique du Congo', 'Congo, the Democratic Republic of the'),
(179, 0, 'DO', 'DOM', 214, '809', 'Dominican peso', 'DOP', 'RD$', 0, '', 'République dominicaine', 'Dominican Republic'),
(180, 0, 'CZ', 'CZE', 203, '', 'Czech koruna', 'CZK', 'Kc', 0, '', 'République tchèque', 'Czech Republic'),
(181, 0, 'RE', 'REU', 638, '262', '', '', '', 0, '', 'Réunion', 'Reunion'),
(182, 0, 'RO', 'ROM', 642, '40', 'Romanian leu', 'RON', 'L', 0, '', 'Roumanie', 'Romania'),
(183, 1, 'GB', 'GBR', 826, '44', 'British pound', 'GBP', '£', 1, '2/''.''/'',''', 'Royaume-Uni', 'United Kingdom'),
(184, 0, 'RU', 'RUS', 643, '7', 'Russian ruble', 'RUB', 'R', 0, '', 'Russie', 'Russian Federation'),
(185, 0, 'RW', 'RWA', 646, '250', 'Rwandan franc', 'RWF', 'RF', 0, '', 'Rwanda', 'Rwanda'),
(186, 0, 'SN', 'SEN', 686, '221', '', '', '', 0, '', 'Sénégal', 'Senegal'),
(187, 0, 'EH', 'ESH', 732, '', '', '', '', 0, '', 'Sahara occidental', 'Western Sahara'),
(188, 0, 'KN', 'KNA', 659, '1869', '', '', '', 0, '', 'Saint-Christophe-et-Niévès', 'Saint Kitts and Nevis'),
(189, 0, 'SM', 'SMR', 674, '378', '', '', '', 0, '', 'Saint-Marin', 'San Marino'),
(190, 0, 'PM', 'SPM', 666, '508', '', '', '', 0, '', 'Saint-Pierre-et-Miquelon', 'Saint Pierre and Miquelon'),
(191, 0, 'VA', 'VAT', 336, '39', '', '', '', 0, '', 'Saint-Siège ', 'Holy See (Vatican City State)'),
(192, 0, 'VC', 'VCT', 670, '1784', '', '', '', 0, '', 'Saint-Vincent-et-les-Grenadines', 'Saint Vincent and the Grenadines'),
(193, 0, 'SH', 'SHN', 654, '290', 'Saint Helena pound', 'SHP', '£', 0, '', 'Sainte-Hélène', 'Saint Helena'),
(194, 0, 'LC', 'LCA', 662, '1758', '', '', '', 0, '', 'Sainte-Lucie', 'Saint Lucia'),
(195, 0, 'SV', 'SLV', 222, '503', '', '', '', 0, '', 'Salvador', 'El Salvador'),
(196, 0, 'WS', 'WSM', 882, '685', 'Samoan tala', 'WST', 'WS$', 0, '', 'Samoa', 'Samoa'),
(197, 0, 'AS', 'ASM', 16, '684', '', '', '', 0, '', 'Samoa américaines', 'American Samoa'),
(198, 0, 'ST', 'STP', 678, '239', 'S?o Tomé and Pr?ncipe dobra', 'STD', 'Db', 0, '', 'Sao Tomé-et-Principe', 'Sao Tome and Principe'),
(199, 0, 'SC', 'SYC', 690, '248', 'Seychellois rupee', 'SCR', 'SR', 0, '', 'Seychelles', 'Seychelles'),
(200, 0, 'SL', 'SLE', 694, '232', 'Sierra Leonean leone', 'SLL', 'Le', 0, '', 'Sierra Leone', 'Sierra Leone'),
(201, 1, 'SG', 'SGP', 702, '65', 'Singapore dollar', 'SGD', 'S$', 0, '', 'Singapour', 'Singapore'),
(202, 0, 'SI', 'SVN', 705, '386', 'European euro', 'EUR', '€', 0, '', 'Slovénie', 'Slovenia'),
(203, 0, 'SK', 'SVK', 703, '421', 'European euro', 'EUR', '€', 0, '', 'Slovaquie', 'Slovakia'),
(204, 0, 'SO', 'SOM', 706, '252', 'Somali shilling', 'SOS', 'Sh.', 0, '', 'Somalie', 'Somalia'),
(205, 0, 'SD', 'SDN', 736, '249', 'Sudanese pound', 'SDG', '', 0, '', 'Soudan', 'Sudan'),
(206, 0, 'LK', 'LKA', 144, '94', 'Sri Lankan rupee', 'LKR', 'Rs', 0, '', 'Sri Lanka', 'Sri Lanka'),
(207, 0, 'SE', 'SWE', 752, '46', 'Swedish krona', 'SEK', 'kr', 0, '', 'Suède', 'Sweden'),
(208, 0, 'CH', 'CHE', 756, '41', 'Swiss franc', 'CHF', 'Fr.', 1, '2/''.''/'' ''', 'Suisse', 'Switzerland'),
(209, 0, 'SR', 'SUR', 740, '597', 'Surinamese dollar', 'SRD', '$', 0, '', 'Suriname', 'Suriname'),
(210, 0, 'SZ', 'SWZ', 748, '268', 'Swazi lilangeni', 'SZL', 'E', 0, '', 'Swaziland', 'Swaziland'),
(211, 0, 'SY', 'SYR', 760, '963', 'Syrian pound', 'SYP', '', 0, '', 'Syrie', 'Syrian Arab Republic'),
(212, 9, 'TW', 'TWN', 158, '886', 'New Taiwan dollar', 'TWD', 'NT$', 0, '', 'Taïwan', 'Taiwan, Province of China'),
(213, 0, 'TJ', 'TJK', 762, '992', 'Tajikistani somoni', 'TJS', '', 0, '', 'Tadjikistan', 'Tajikistan'),
(214, 0, 'TZ', 'TZA', 834, '255', 'Tanzanian shilling', 'TZS', '', 0, '', 'Tanzanie', 'Tanzania, United Republic of'),
(215, 0, 'TD', 'TCD', 148, '235', '', '', '', 0, '', 'Tchad', 'Chad'),
(216, 0, 'TF', '', 0, '', '', '', '', 0, '', 'Terres australes françaises', 'French Southern Territories'),
(217, 0, 'IO', '', 0, '', '', '', '', 0, '', 'Territoire britannique de l''Océan Indien', 'British Indian Ocean Territory'),
(218, 0, 'TH', 'THA', 764, '66', 'Thai baht', 'THB', '?', 0, '', 'Thaïlande', 'Thailand'),
(219, 0, 'TL', '', 0, '670', '', '', '', 0, '', 'Timor Oriental', 'Timor-Leste'),
(220, 0, 'TG', 'TGO', 768, '228', '', '', '', 0, '', 'Togo', 'Togo'),
(221, 0, 'TK', 'TKL', 772, '690', '', '', '', 0, '', 'Tokélaou', 'Tokelau'),
(222, 0, 'TO', 'TON', 776, '676', '', '', '', 0, '', 'Tonga', 'Tonga'),
(223, 0, 'TT', 'TTO', 780, '1868', 'Trinidad and Tobago dollar', 'TTD', 'TT$', 0, '', 'Trinité-et-Tobago', 'Trinidad and Tobago'),
(224, 30, 'TN', 'TUN', 788, '216', 'Tunisian dinar', 'TND', 'DT', 1, '3,''.'','' ''', 'Tunisie', 'Tunisia'),
(225, 0, 'TM', 'TKM', 795, '993', 'Turkmen manat', 'TMT', 'm', 0, '', 'Turkménistan', 'Turkmenistan'),
(226, 0, 'TR', 'TUR', 792, '90', 'Turkish new lira', 'TRY', 'YTL', 0, '', 'Turquie', 'Turkey'),
(227, 0, 'TV', 'TUV', 798, '688', '', '', '', 0, '', 'Tuvalu', 'Tuvalu'),
(228, 0, 'UA', 'UKR', 804, '380', 'Ukrainian hryvnia', 'UAH', '', 0, '', 'Ukraine', 'Ukraine'),
(229, 0, 'UY', 'URY', 858, '598', 'Uruguayan peso', 'UYU', '$U', 0, '', 'Uruguay', 'Uruguay'),
(230, 0, 'VU', 'VUT', 548, '678', 'Vanuatu vatu', 'VUV', 'VT', 0, '', 'Vanuatu', 'Vanuatu'),
(231, 0, 'VE', 'VEN', 862, '58', 'Venezuelan bolivar', 'VEB', 'Bs', 0, '', 'Venezuela', 'Venezuela'),
(232, 0, 'VN', 'VNM', 704, '84', 'Vietnamese dong', 'VND', '?', 0, '', 'Viêt Nam', 'Viet Nam'),
(233, 0, 'WF', 'WLF', 876, '681', '', '', '', 0, '', 'Wallis-et-Futuna', 'Wallis and Futuna'),
(234, 0, 'YE', 'YEM', 887, '967', 'Yemeni rial', 'YER', '', 0, '', 'Yémen', 'Yemen'),
(235, 0, 'YU', '', 0, '381', '', '', '', 0, '', 'Yougoslavie', 'Yugoslavia'),
(236, 0, 'ZM', 'ZMB', 894, '260', 'Zambian kwacha', 'ZMK', 'ZK', 0, '', 'Zambie', 'Zambia'),
(237, 0, 'ZW', 'ZWE', 716, '263', 'Zimbabwean dollar', 'ZWR', 'Z$', 0, '', 'Zimbabwe', 'Zimbabwe'),
(238, 0, 'MK', 'MKD', 807, '389', 'Macedonian denar', 'MKD', '', 0, '', 'ex-République yougoslave de Macédoine', 'Macedonia, the Former Yugoslav Republic of');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_extensions`
--

DROP TABLE IF EXISTS `m5jbw_extensions`;
CREATE TABLE IF NOT EXISTS `m5jbw_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10009 ;

--
-- Contenu de la table `m5jbw_extensions`
--

INSERT INTO `m5jbw_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(1, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_mailto","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MAILTO_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_wrapper","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_admin","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_ADMIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_banners","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_BANNERS_XML_DESCRIPTION","group":""}', '{"purchase_type":"3","track_impressions":"0","track_clicks":"0","metakey_prefix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cache","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CACHE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_categories","type":"component","creationDate":"December 2007","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_checkin","type":"component","creationDate":"Unknown","author":"Joomla! Project","copyright":"(C) 2005 - 2008 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CHECKIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_contact","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONTACT_XML_DESCRIPTION","group":""}', '{"show_contact_category":"hide","show_contact_list":"0","presentation_style":"sliders","show_name":"1","show_position":"1","show_email":"0","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"1","show_fax":"1","show_webpage":"1","show_misc":"1","show_image":"1","image":"","allow_vcard":"0","show_articles":"0","show_profile":"0","show_links":"0","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","contact_icons":"0","icon_address":"","icon_email":"","icon_telephone":"","icon_mobile":"","icon_fax":"","icon_misc":"","show_headings":"1","show_position_headings":"1","show_email_headings":"0","show_telephone_headings":"1","show_mobile_headings":"0","show_fax_headings":"0","allow_vcard_headings":"0","show_suburb_headings":"1","show_state_headings":"1","show_country_headings":"1","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"0","redirect":"","show_category_crumb":"0","metakey":"","metadesc":"","robots":"","author":"","rights":"","xreference":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cpanel","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CPANEL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_installer","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_INSTALLER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_languages","type":"component","creationDate":"2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_LANGUAGES_XML_DESCRIPTION","group":""}', '{"administrator":"fr-FR","site":"fr-FR"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_login","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_media","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MEDIA_XML_DESCRIPTION","group":""}', '{"upload_extensions":"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS","upload_maxsize":"10","file_path":"images","image_path":"images","restrict_uploads":"1","allowed_media_usergroup":"3","check_mime":"1","image_extensions":"bmp,gif,jpg,png","ignore_extensions":"","upload_mime":"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip","upload_mime_illegal":"text\\/html"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_menus","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MENUS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_messages","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MESSAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_modules","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MODULES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(17, 'com_newsfeeds', 'component', 'com_newsfeeds', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_newsfeeds","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"show_feed_image":"1","show_feed_description":"1","show_item_description":"1","feed_word_count":"0","show_headings":"1","show_name":"1","show_articles":"0","show_link":"1","show_description":"1","show_description_image":"1","display_num":"","show_pagination_limit":"1","show_pagination":"1","show_pagination_results":"1","show_cat_items":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_plugins","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_PLUGINS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(19, 'com_search', 'component', 'com_search', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_search","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_SEARCH_XML_DESCRIPTION","group":""}', '{"enabled":"0","show_date":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_templates","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_TEMPLATES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(21, 'com_weblinks', 'component', 'com_weblinks', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_weblinks","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_WEBLINKS_XML_DESCRIPTION","group":""}', '{"show_comp_description":"1","comp_description":"","show_link_hits":"1","show_link_description":"1","show_other_cats":"0","show_headings":"0","show_numbers":"0","show_report":"1","count_clicks":"1","target":"0","link_icons":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_content","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONTENT_XML_DESCRIPTION","group":""}', '{"article_layout":"_:default","show_title":"1","link_titles":"1","show_intro":"1","show_category":"1","link_category":"1","show_parent_category":"0","link_parent_category":"0","show_author":"1","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"1","show_item_navigation":"1","show_vote":"0","show_readmore":"1","show_readmore_title":"1","readmore_limit":"100","show_icons":"1","show_print_icon":"1","show_email_icon":"1","show_hits":"1","show_noauth":"0","show_publishing_options":"1","show_article_options":"1","show_urls_images_frontend":"0","show_urls_images_backend":"1","targeta":0,"targetb":0,"targetc":0,"float_intro":"left","float_fulltext":"left","category_layout":"_:blog","show_category_title":"0","show_description":"0","show_description_image":"0","maxLevel":"1","show_empty_categories":"0","show_no_articles":"1","show_subcat_desc":"1","show_cat_num_articles":"0","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"1","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"0","show_subcategory_content":"0","show_pagination_limit":"1","filter_field":"hide","show_headings":"1","list_show_date":"0","date_format":"","list_show_hits":"1","list_show_author":"1","orderby_pri":"order","orderby_sec":"rdate","order_date":"published","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1","feed_summary":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_config","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONFIG_XML_DESCRIPTION","group":""}', '{"filters":{"1":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"NONE","filter_tags":"","filter_attributes":""},"2":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"10":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"12":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"NONE","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_redirect","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_users","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_USERS_XML_DESCRIPTION","group":""}', '{"allowUserRegistration":"1","new_usertype":"2","guest_usergroup":"1","sendpassword":"0","useractivation":"0","mail_to_admin":"1","captcha":"","frontend_userparams":"1","site_language":"0","change_login_name":"0","reset_count":"10","reset_time":"1","mailSubjectPrefix":"","mailBodySuffix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(27, 'com_finder', 'component', 'com_finder', '', 1, 1, 0, 0, '{"legacy":false,"name":"com_finder","type":"component","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_FINDER_XML_DESCRIPTION","group":""}', '{"show_description":"1","description_length":255,"allow_empty_query":"0","show_url":"1","show_advanced":"1","expand_advanced":"0","show_date_filters":"0","highlight_terms":"1","opensearch_name":"","opensearch_description":"","batch_size":"50","memory_table_limit":30000,"title_multiplier":"1.7","text_multiplier":"0.7","meta_multiplier":"1.2","path_multiplier":"2.0","misc_multiplier":"0.3","stemmer":"snowball"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_joomlaupdate","type":"component","creationDate":"February 2012","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(100, 'PHPMailer', 'library', 'phpmailer', '', 0, 1, 1, 1, '{"legacy":false,"name":"PHPMailer","type":"library","creationDate":"2001","author":"PHPMailer","copyright":"(c) 2001-2003, Brent R. Matzelle, (c) 2004-2009, Andy Prevost. All Rights Reserved., (c) 2010-2011, Jim Jagielski. All Rights Reserved.","authorEmail":"jimjag@gmail.com","authorUrl":"https:\\/\\/code.google.com\\/a\\/apache-extras.org\\/p\\/phpmailer\\/","version":"5.2","description":"LIB_PHPMAILER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(101, 'SimplePie', 'library', 'simplepie', '', 0, 1, 1, 1, '{"legacy":false,"name":"SimplePie","type":"library","creationDate":"2004","author":"SimplePie","copyright":"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon","authorEmail":"","authorUrl":"http:\\/\\/simplepie.org\\/","version":"1.2","description":"LIB_SIMPLEPIE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 'phputf8', 'library', 'phputf8', '', 0, 1, 1, 1, '{"legacy":false,"name":"phputf8","type":"library","creationDate":"2006","author":"Harry Fuecks","copyright":"Copyright various authors","authorEmail":"hfuecks@gmail.com","authorUrl":"http:\\/\\/sourceforge.net\\/projects\\/phputf8","version":"0.5","description":"LIB_PHPUTF8_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 'Joomla! Platform', 'library', 'joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"Joomla! Platform","type":"library","creationDate":"2008","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"11.4","description":"LIB_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_archive","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters.\\n\\t\\tAll rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LATEST_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_popular","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_banners","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_BANNERS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_breadcrumbs","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_BREADCRUMBS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_footer","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FOOTER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_news","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_random_image","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_RANDOM_IMAGE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_related_items","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_RELATED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_search","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SEARCH_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_stats","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_syndicate","type":"module","creationDate":"May 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SYNDICATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_users_latest","type":"module","creationDate":"December 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_USERS_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(217, 'mod_weblinks', 'module', 'mod_weblinks', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_weblinks","type":"module","creationDate":"July 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WEBLINKS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_whosonline","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WHOSONLINE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_wrapper","type":"module","creationDate":"October 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_category","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_categories","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_languages","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LANGUAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '{"legacy":false,"name":"mod_finder","type":"module","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FINDER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_logged","type":"module","creationDate":"January 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGGED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"March 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_popular","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_quickicon","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_QUICKICON_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_status","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_STATUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_submenu","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SUBMENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_title","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_TITLE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_toolbar","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_TOOLBAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_multilangstatus","type":"module","creationDate":"September 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MULTILANGSTATUS_XML_DESCRIPTION","group":""}', '{"cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 'mod_version', 'module', 'mod_version', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_version","type":"module","creationDate":"January 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_VERSION_XML_DESCRIPTION","group":""}', '{"format":"short","product":"1","cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_gmail","type":"plugin","creationDate":"February 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_GMAIL_XML_DESCRIPTION","group":""}', '{"applysuffix":"0","suffix":"","verifypeer":"1","user_blacklist":""}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{"legacy":false,"name":"plg_authentication_joomla","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_AUTH_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_ldap","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LDAP_XML_DESCRIPTION","group":""}', '{"host":"","port":"389","use_ldapV3":"0","negotiate_tls":"0","no_referrals":"0","auth_method":"bind","base_dn":"","search_string":"","users_dn":"","username":"admin","password":"bobby7","ldap_fullname":"fullName","ldap_email":"mail","ldap_uid":"uid"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(404, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_emailcloak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION","group":""}', '{"mode":"1"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(405, 'plg_content_geshi', 'plugin', 'geshi', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_geshi","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"","authorUrl":"qbnz.com\\/highlighter","version":"2.5.0","description":"PLG_CONTENT_GESHI_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(406, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_loadmodule","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LOADMODULE_XML_DESCRIPTION","group":""}', '{"style":"xhtml"}', '', '', 0, '2011-09-18 15:22:50', 0, 0),
(407, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 1, '{"legacy":false,"name":"plg_content_pagebreak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION","group":""}', '{"title":"1","multipage_toc":"1","showall":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 1, 1, 1, '{"legacy":false,"name":"plg_content_pagenavigation","type":"plugin","creationDate":"January 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_PAGENAVIGATION_XML_DESCRIPTION","group":""}', '{"position":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 1, 1, 1, '{"legacy":false,"name":"plg_content_vote","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_VOTE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_codemirror","type":"plugin","creationDate":"28 March 2011","author":"Marijn Haverbeke","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"1.0","description":"PLG_CODEMIRROR_XML_DESCRIPTION","group":""}', '{"linenumbers":"0","tabmode":"indent"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_none","type":"plugin","creationDate":"August 2004","author":"Unknown","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"2.5.0","description":"PLG_NONE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_tinymce","type":"plugin","creationDate":"2005-2013","author":"Moxiecode Systems AB","copyright":"Moxiecode Systems AB","authorEmail":"N\\/A","authorUrl":"tinymce.moxiecode.com\\/","version":"3.5.4.1","description":"PLG_TINY_XML_DESCRIPTION","group":""}', '{"mode":"2","skin":"0","entity_encoding":"raw","lang_mode":"0","lang_code":"fr","text_direction":"ltr","content_css":"1","content_css_custom":"","relative_urls":"1","newlines":"0","invalid_elements":"script,applet,iframe","extended_elements":"","toolbar":"top","toolbar_align":"left","html_height":"550","html_width":"750","resizing":"true","resize_horizontal":"false","element_path":"1","fonts":"1","paste":"1","searchreplace":"1","insertdate":"1","format_date":"%d-%m-%Y","inserttime":"1","format_time":"%H:%M:%S","colors":"1","table":"1","smilies":"1","media":"1","hr":"1","directionality":"1","fullscreen":"1","style":"1","layer":"1","xhtmlxtras":"1","visualchars":"1","nonbreaking":"1","template":"1","blockquote":"1","wordcount":"1","advimage":"1","advlink":"1","advlist":"1","autosave":"1","contextmenu":"1","inlinepopups":"1","custom_plugin":"","custom_button":""}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors-xtd_article","type":"plugin","creationDate":"October 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_ARTICLE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_image","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_IMAGE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_pagebreak","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_readmore","type":"plugin","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_READMORE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(417, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_categories","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(418, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_contacts","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CONTACTS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_content","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CONTENT_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_newsfeeds","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(421, 'plg_search_weblinks', 'plugin', 'weblinks', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_weblinks","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_WEBLINKS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(422, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_languagefilter","type":"plugin","creationDate":"July 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(423, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_p3p","type":"plugin","creationDate":"September 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_P3P_XML_DESCRIPTION","group":""}', '{"headers":"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_cache","type":"plugin","creationDate":"February 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CACHE_XML_DESCRIPTION","group":""}', '{"browsercache":"0","cachetime":"15"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_debug","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_DEBUG_XML_DESCRIPTION","group":""}', '{"profile":"1","queries":"1","memory":"1","language_files":"1","language_strings":"1","strip-first":"1","strip-prefix":"","strip-suffix":""}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_log","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LOG_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0);
INSERT INTO `m5jbw_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(427, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_redirect","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(428, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_remember","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_REMEMBER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_sef","type":"plugin","creationDate":"December 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEF_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_logout","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 1, '{"legacy":false,"name":"plg_user_contactcreator","type":"plugin","creationDate":"August 2009","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTACTCREATOR_XML_DESCRIPTION","group":""}', '{"autowebpage":"","category":"34","autopublish":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{"legacy":false,"name":"plg_user_joomla","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2009 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_USER_JOOMLA_XML_DESCRIPTION","group":""}', '{"autoregister":"1"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 1, '{"legacy":false,"name":"plg_user_profile","type":"plugin","creationDate":"January 2008","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_USER_PROFILE_XML_DESCRIPTION","group":""}', '{"register-require_address1":"1","register-require_address2":"1","register-require_city":"1","register-require_region":"1","register-require_country":"1","register-require_postal_code":"1","register-require_phone":"1","register-require_website":"1","register-require_favoritebook":"1","register-require_aboutme":"1","register-require_tos":"1","register-require_dob":"1","profile-require_address1":"1","profile-require_address2":"1","profile-require_city":"1","profile-require_region":"1","profile-require_country":"1","profile-require_postal_code":"1","profile-require_phone":"1","profile-require_website":"1","profile-require_favoritebook":"1","profile-require_aboutme":"1","profile-require_tos":"1","profile-require_dob":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{"legacy":false,"name":"plg_extension_joomla","type":"plugin","creationDate":"May 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_joomla","type":"plugin","creationDate":"November 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{"legacy":false,"name":"plg_system_languagecode","type":"plugin","creationDate":"November 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_joomlaupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_extensionupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 0, 1, 0, '{"legacy":false,"name":"plg_captcha_recaptcha","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION","group":""}', '{"public_key":"","private_key":"","theme":"clean"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_highlight","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_finder","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_FINDER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_categories","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_CATEGORIES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_contacts","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_CONTACTS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_content","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_CONTENT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_newsfeeds","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(446, 'plg_finder_weblinks', 'plugin', 'weblinks', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_weblinks","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_WEBLINKS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(500, 'atomic', 'template', 'atomic', '', 0, 1, 1, 0, '{"legacy":false,"name":"atomic","type":"template","creationDate":"10\\/10\\/09","author":"Ron Severdia","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"contact@kontentdesign.com","authorUrl":"http:\\/\\/www.kontentdesign.com","version":"2.5.0","description":"TPL_ATOMIC_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(502, 'bluestork', 'template', 'bluestork', '', 1, 1, 1, 0, '{"legacy":false,"name":"bluestork","type":"template","creationDate":"07\\/02\\/09","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"TPL_BLUESTORK_XML_DESCRIPTION","group":""}', '{"useRoundedCorners":"1","showSiteName":"0","textBig":"0","highContrast":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(503, 'beez_20', 'template', 'beez_20', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez_20","type":"template","creationDate":"25 November 2009","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"2.5.0","description":"TPL_BEEZ2_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(504, 'hathor', 'template', 'hathor', '', 1, 1, 1, 0, '{"legacy":false,"name":"hathor","type":"template","creationDate":"May 2010","author":"Andrea Tarr","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"hathor@tarrconsulting.com","authorUrl":"http:\\/\\/www.tarrconsulting.com","version":"2.5.0","description":"TPL_HATHOR_XML_DESCRIPTION","group":""}', '{"showSiteName":"0","colourChoice":"0","boldText":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(505, 'beez5', 'template', 'beez5', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez5","type":"template","creationDate":"21 May 2010","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"2.5.0","description":"TPL_BEEZ5_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","html5":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 'English (United Kingdom)', 'language', 'en-GB', '', 0, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.10","description":"en-GB site language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 'English (United Kingdom)', 'language', 'en-GB', '', 1, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.10","description":"en-GB administrator language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(602, 'French Language Pack', 'package', 'pkg_fr-FR', '', 0, 1, 1, 1, '{"legacy":false,"name":"French Language Pack","type":"package","creationDate":"03 aug 2013","author":"French translation team : joomla.fr","copyright":"Copyright (C) 2005 - 2013 joomla.fr et Open Source Matters. Tous droits r\\u00e9serv\\u00e9s","authorEmail":"traduction@joomla.fr","authorUrl":"www.joomla.fr","version":"2.5.14","description":"\\n\\t\\t\\n\\t\\t<h3>Joomla! Full French (fr-FR) Language Package version 2.5.14<\\/h3>\\n\\t\\t<h3>Paquet de langue fran\\u00e7ais complet Joomla! fr-FR version 2.5.14<\\/h3>\\n\\t\\t<div>Installation inclue du pack de langue fr-FR de TinyMCE 3.5.4 pour Joomla 2.5.14<\\/div><br>\\n\\t\\t<div style=\\"font-weight: normal; padding-bottom:15px;\\">N''oubliez pas de s\\u00e9lectionner la langue FR dans les <a href=\\"index.php?option=com_plugins&amp;view=plugins&amp;filter_search=TinyMCE\\"><strong>param\\u00e8tres du plug-in ''\\u00c9diteur - TinyMCE''<\\/strong><\\/a> (param\\u00e8tre  ''Langue de l''\\u00e9diteur'' = fr).<br>\\n \\t\\tSi vous utilisez la <strong>d\\u00e9tection automatique<\\/strong>, veillez \\u00e0 ce que soient install\\u00e9s les diff\\u00e9rents packs de langue de TinyMCE correspondants aux packs de langue install\\u00e9s pour Joomla!<\\/div>\\n\\t\\t\\n\\t","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(603, 'French (fr-FR)', 'language', 'fr-FR', '', 1, 1, 0, 1, '{"legacy":false,"name":"French (fr-FR)","type":"language","creationDate":"3 aug 2013","author":"French translation team : joomla.fr","copyright":"Copyright (C) 2005 - 2013 Open Source Matters & Joomla.fr. All rights reserved.","authorEmail":"traduction@joomla.fr","authorUrl":"www.joomla.fr","version":"2.5.14","description":"French administrator language for Joomla 3.0","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(604, 'French (fr-FR)', 'language', 'fr-FR', '', 0, 1, 0, 1, '{"legacy":false,"name":"French (fr-FR)","type":"language","creationDate":"3 aug 2013","author":"French translation team : joomla.fr","copyright":"Copyright (C) 2005 - 2013 Open Source Matters & joomla.fr. All rights reserved.","authorEmail":"traduction@joomla.fr","authorUrl":"www.joomla.fr","version":"2.5.14","description":"French site language for Joomla 3.0","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(605, 'TinyMCE langue FR', 'file', 'TinyMCE_fr-FR', '', 0, 1, 0, 1, '{"legacy":false,"name":"TinyMCE langue FR","type":"file","creationDate":"4 feb 2013","author":"French translation team : joomla.fr","copyright":"(C) 2005-2013 French Translation Team","authorEmail":"traduction@joomla.fr","authorUrl":"www.joomla.fr","version":"3.5.4.1","description":"\\t\\t\\n\\t\\t<h3>Installation du pack de langue FR de TinyMCE 3.5.4.1 pour Joomla 2.5 effectu\\u00e9e avec succ\\u00e8s<\\/h3>\\n \\u00a0 \\u00a0 \\u00a0 \\u00a0<div style=\\"font-weight:normal\\">\\n \\t\\tN''oubliez pas de s\\u00e9lectionner la langue FR dans la \\n \\t\\t<a href=\\"index.php?option=com_plugins&view=plugins&filter_search=TinyMCE\\"><strong>gestion du plug-in TinyMCE<\\/strong><\\/a><br \\/>\\n \\t\\tSi vous utilisez la d\\u00e9tection automatique, veillez \\u00e0 ce que soient install\\u00e9s les diff\\u00e9rents packs de langue de TinyMCE correspondants \\n \\t\\t\\u00e0 ceux install\\u00e9s pour Joomla!<\\/div>\\t\\t\\n\\t\\t\\n\\t","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"files_joomla","type":"file","creationDate":"August 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.14","description":"FILES_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(800, 'PKG_JOOMLA', 'package', 'pkg_joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"PKG_JOOMLA","type":"package","creationDate":"2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"2.5.0","description":"PKG_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10000, 'com_mediamallfactory', 'component', 'com_mediamallfactory', '', 1, 1, 0, 0, '{"legacy":false,"name":"com_mediamallfactory","type":"component","creationDate":"August 2008","author":"The Factory","copyright":"SKEPSIS Consult SRL","authorEmail":"contact@thefactory.ro","authorUrl":"www.thefactory.ro","version":"3.3.5","description":"Media Mall Factory","group":""}', '{"invoices":{"invoice":{"template":"<table class=\\"no_border\\" style=\\"width: 100%;\\" border=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td class=\\"no_padding\\" style=\\"width: 250px; vertical-align: top;\\">\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td class=\\"billing_information\\" valign=\\"top\\">Seller Information<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td class=\\"header\\">Contact Details<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>%%seller_information%%<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<\\/td>\\r\\n<td style=\\"text-align: center;\\" valign=\\"bottom\\">\\r\\n<p><span style=\\"font-size: xx-large;\\"><strong>Invoice<\\/strong><\\/span><\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>Number: <strong>%%invoice_number%%<\\/strong><\\/p>\\r\\n<p>Date: <strong>%%invoice_date%%<\\/strong><\\/p>\\r\\n<\\/td>\\r\\n<td class=\\"no_padding\\" style=\\"width: 250px; vertical-align: top;\\">\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td class=\\"billing_information\\">Buyer Information<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td class=\\"header\\">Contact Details<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>%%buyer_information%%<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<p>\\u00a0<\\/p>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td class=\\"billing_information\\" colspan=\\"3\\">Billing Information<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td class=\\"header\\">Credits<\\/td>\\r\\n<td class=\\"header\\">\\u00a0<\\/td>\\r\\n<td class=\\"header\\" style=\\"width: 100px;\\">Price<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td style=\\"text-align: left;\\">%%item_title%%<\\/td>\\r\\n<td style=\\"text-align: right;\\">\\u00a0<\\/td>\\r\\n<td style=\\"text-align: left;\\">%%amount%%<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>\\u00a0<\\/td>\\r\\n<td style=\\"text-align: right;\\"><strong>VAT<\\/strong><\\/td>\\r\\n<td style=\\"text-align: left;\\">%%vat%%<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>\\u00a0<\\/td>\\r\\n<td style=\\"text-align: right;\\"><strong>TOTAL<\\/strong><\\/td>\\r\\n<td style=\\"text-align: left;\\">%%total%%<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<p style=\\"text-align: center;\\">\\u00a0<\\/p>\\r\\n<p style=\\"text-align: center;\\"><strong>www.yoursite.com<\\/strong><\\/p>\\r\\n<p style=\\"text-align: center;\\">Lorem ipsum dolor sit amet.Suspendisse potenti. Phasellus volutpat.<\\/p>"},"seller":{"template":"<p>Media Mall Factory<\\/p>"},"buyer":{"template":"<p>%%name%%,<\\/p>\\r\\n<p>%%address%%,<\\/p>\\r\\n<p>%%city%%, %%country%%<\\/p>"}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10001, 'mod_mediamallfactory', 'module', 'mod_mediamallfactory', '', 0, 1, 0, 0, '{"legacy":false,"name":"mod_mediamallfactory","type":"module","creationDate":"August 2008","author":"The Factory","copyright":"SKEPSIS Consult SRL","authorEmail":"contact@thefactory.ro","authorUrl":"www.thefactory.ro","version":"3.3.5","description":"Media Mall Factory Module","group":""}', '{"mode":"1","cost":"","limit":"5","cache":"1","cache_time":"900","cachemode":"static"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10002, 'plg_search_mediamallfactory', 'plugin', 'mediamallfactory', 'search', 0, 0, 1, 0, '{"legacy":false,"name":"plg_search_mediamallfactory","type":"plugin","creationDate":"August 2008","author":"The Factory","copyright":"SKEPSIS Consult SRL","authorEmail":"contact@thefactory.ro","authorUrl":"www.thefactory.ro","version":"3.3.5","description":"Media Mall Factory Search Plugin","group":""}', '{"limit":"10"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10003, 'plg_content_mediamallfactory', 'plugin', 'mediamallfactory', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_mediamallfactory","type":"plugin","creationDate":"August 2008","author":"The Factory","copyright":"SKEPSIS Consult SRL","authorEmail":"contact@thefactory.ro","authorUrl":"www.thefactory.ro","version":"3.3.5","description":"Media Mall Factory Content Plugin","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 'MediaMallFactorySuite', 'package', 'pkg_MediaMallFactorySuite', '', 0, 1, 1, 0, '{"legacy":false,"name":"Media Mall Factory","type":"package","creationDate":"August 2012","author":"The Factory","copyright":"SKEPSIS Consult SRL","authorEmail":"support@thefactory.ro","authorUrl":"http:\\/\\/www.thefactory.ro","version":"3.3.5","description":"Media Mall Factory Component and Modules","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10006, 'Kochk User', 'plugin', 'kochk_plg', 'user', 0, 1, 1, 0, '{"legacy":false,"name":"Kochk User","type":"plugin","creationDate":"Unknown","author":"Feki Hichem","copyright":"","authorEmail":"","authorUrl":"","version":"1.0.0","description":"Kochk Component user plugin","group":""}', '{"menu_id":"435"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(10007, 'ajaxdemo', 'component', 'com_ajaxdemo', '', 1, 1, 0, 0, '{"legacy":false,"name":"Ajaxdemo","type":"component","creationDate":"March 2010","author":"Persistent Objects Ltd","copyright":"Copyright Persistent Objects 2010-2012","authorEmail":"ahicks@p-o.co.uk","authorUrl":"http:\\/\\/p-o.co.uk","version":"1.1.0","description":"Joomla Component to demonstrate Ajax with Mootools to create a rich and efficient popup user interface.\\n\\t  Just add a menu item of type ''Ajaxdemo\\/Colour List Layout'' to see it in action\\n\\t","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10008, 'Kiosque', 'template', 'kiosque', '', 0, 1, 1, 0, '{"legacy":false,"name":"Kiosque","type":"template","creationDate":"08 Aout 2013","author":"Mehdi LOUATI","copyright":"Copyright (C) 2013 siscom s.a.r.l, All rights reserved.","authorEmail":"mehdi.louati@gmail.com","authorUrl":"http:\\/\\/www.siscom-inter.com","version":"1.0","description":"TPL_KIOSK_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_filters`
--

DROP TABLE IF EXISTS `m5jbw_finder_filters`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_finder_filters`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links`
--

DROP TABLE IF EXISTS `m5jbw_finder_links`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_finder_links`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms0`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms0`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms0`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms1`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms1`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms1`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms2`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms2`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms2`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms3`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms3`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms3`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms4`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms4`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms4`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms5`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms5`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms5`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms6`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms6`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms6`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms7`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms7`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms7`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms8`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms8`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms8`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_terms9`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_terms9`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_terms9`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_termsa`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_termsa`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_termsa`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_termsb`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_termsb`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_termsb`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_termsc`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_termsc`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_termsc`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_termsd`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_termsd`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_termsd`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_termse`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_termse`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_termse`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_links_termsf`
--

DROP TABLE IF EXISTS `m5jbw_finder_links_termsf`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_links_termsf`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_taxonomy`
--

DROP TABLE IF EXISTS `m5jbw_finder_taxonomy`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `m5jbw_finder_taxonomy`
--

INSERT INTO `m5jbw_finder_taxonomy` (`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES
(1, 0, 'ROOT', 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_taxonomy_map`
--

DROP TABLE IF EXISTS `m5jbw_finder_taxonomy_map`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_taxonomy_map`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_terms`
--

DROP TABLE IF EXISTS `m5jbw_finder_terms`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_finder_terms`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_terms_common`
--

DROP TABLE IF EXISTS `m5jbw_finder_terms_common`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_terms_common`
--

INSERT INTO `m5jbw_finder_terms_common` (`term`, `language`) VALUES
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('ani', 'en'),
('any', 'en'),
('are', 'en'),
('aren''t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn''t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('noth', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('onli', 'en'),
('only', 'en'),
('or', 'en'),
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('veri', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('whi', 'en'),
('which', 'en'),
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_tokens`
--

DROP TABLE IF EXISTS `m5jbw_finder_tokens`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_tokens`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_tokens_aggregate`
--

DROP TABLE IF EXISTS `m5jbw_finder_tokens_aggregate`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_finder_tokens_aggregate`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_finder_types`
--

DROP TABLE IF EXISTS `m5jbw_finder_types`;
CREATE TABLE IF NOT EXISTS `m5jbw_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_finder_types`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_languages`
--

DROP TABLE IF EXISTS `m5jbw_languages`;
CREATE TABLE IF NOT EXISTS `m5jbw_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `m5jbw_languages`
--

INSERT INTO `m5jbw_languages` (`lang_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES
(1, 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en', '', '', '', '', 1, 0, 1),
(2, 'fr-FR', 'Français (FR)', 'Français (FR)', 'fr', 'fr', '', '', '', '', 1, 0, 2);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_admin_messages`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_admin_messages`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_admin_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `message` mediumtext NOT NULL,
  `pending` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_admin_messages`
--

INSERT INTO `m5jbw_mediamallfactory_admin_messages` (`id`, `user_id`, `item_id`, `owner_id`, `type`, `is_admin`, `message`, `pending`, `created_at`) VALUES
(1, 342, 1, 342, 'media', 1, 'Message to user', 1, '2013-09-09 16:50:13');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_comments`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_comments`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `media_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `rating` tinyint(1) NOT NULL,
  `votes_up` int(11) NOT NULL,
  `votes_down` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `media_id` (`media_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_comments`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_comments_votes`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_comments_votes`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_comments_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `vote` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `comment_id` (`comment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_comments_votes`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_credits_bonuses`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_credits_bonuses`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_credits_bonuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credits` int(11) NOT NULL,
  `bonus` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_credits_bonuses`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_invoices`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_invoices`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `params` mediumtext NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `vat_rate` decimal(10,2) NOT NULL,
  `vat_value` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_invoices`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_log_balance`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_log_balance`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_log_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `media_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `pending` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `media_id` (`media_id`),
  KEY `purchase_id` (`purchase_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_log_balance`
--

INSERT INTO `m5jbw_mediamallfactory_log_balance` (`id`, `user_id`, `type`, `amount`, `sign`, `media_id`, `purchase_id`, `pending`, `created_at`) VALUES
(1, 342, 'media_sale_media', '0.40', 1, 1, 1, 1, '2013-09-09 16:59:33'),
(2, 342, 'media_sale_media', '0.40', 1, 1, 2, 1, '2013-09-09 19:09:05'),
(3, 342, 'media_sale_media', '0.40', 1, 1, 3, 1, '2013-09-09 19:46:17');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_log_credits`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_log_credits`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_log_credits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `credits` int(11) NOT NULL,
  `sign` tinyint(1) NOT NULL,
  `media_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `pending` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `media_id` (`media_id`),
  KEY `purchase_id` (`purchase_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=911 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_log_credits`
--

INSERT INTO `m5jbw_mediamallfactory_log_credits` (`id`, `user_id`, `type`, `credits`, `sign`, `media_id`, `purchase_id`, `pending`, `created_at`) VALUES
(1, 343, 'initial_credits', 5, 1, 0, 0, 0, '2013-09-08 17:39:02'),
(2, 342, 'initial_credits', 5, 1, 0, 0, 0, '2013-09-08 19:01:10'),
(3, 342, 'initial_credits', 5, 1, 0, 0, 0, '2013-09-08 19:18:31'),
(4, 342, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-08 19:20:19'),
(5, 342, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-08 19:22:08'),
(6, 342, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-08 19:24:22'),
(7, 342, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-08 19:24:57'),
(8, 342, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-08 19:28:32'),
(9, 344, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-09 16:59:01'),
(10, 344, 'media_purchased_media', 1, -1, 1, 1, 1, '2013-09-09 16:59:33'),
(11, 343, 'media_purchased_media', 1, -1, 1, 2, 1, '2013-09-09 19:09:05'),
(12, 344, 'media_purchased_media', 1, -1, 1, 3, 1, '2013-09-09 19:46:17'),
(13, 345, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 16:47:25'),
(14, 348, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 18:03:28'),
(15, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:14:41'),
(16, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:20:07'),
(17, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:47:53'),
(18, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:47:59'),
(19, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:48:34'),
(20, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:48:37'),
(21, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:48:42'),
(22, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:49:37'),
(23, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:52:09'),
(24, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:52:13'),
(25, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:52:14'),
(26, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:57:06'),
(27, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:57:09'),
(28, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 19:58:05'),
(29, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:01:16'),
(30, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:18:27'),
(31, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:19:26'),
(32, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:20:50'),
(33, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:20:54'),
(34, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:20:56'),
(35, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:30:08'),
(36, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:30:17'),
(37, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:30:24'),
(38, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:30:51'),
(39, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:30:55'),
(40, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:39:08'),
(41, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:39:11'),
(42, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:39:13'),
(43, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:39:21'),
(44, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:39:25'),
(45, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:39:28'),
(46, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:41:58'),
(47, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:42:01'),
(48, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:42:06'),
(49, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:42:09'),
(50, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:42:12'),
(51, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:42:43'),
(52, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:42:44'),
(53, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:43:37'),
(54, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:43:38'),
(55, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:43:40'),
(56, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:43:53'),
(57, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:43:56'),
(58, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:45:32'),
(59, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:45:34'),
(60, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:45:36'),
(61, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:45:38'),
(62, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:45:39'),
(63, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:47:25'),
(64, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:47:37'),
(65, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:47:40'),
(66, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:47:42'),
(67, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:47:43'),
(68, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:48:59'),
(69, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:49:00'),
(70, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:49:02'),
(71, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:49:05'),
(72, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:49:07'),
(73, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:49:09'),
(74, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-10 20:49:14'),
(75, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 15:59:07'),
(76, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:00:37'),
(77, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:01:37'),
(78, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:02:28'),
(79, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:05:28'),
(80, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:06:29'),
(81, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:14:17'),
(82, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:16:33'),
(83, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:16:52'),
(84, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:17:14'),
(85, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:30:39'),
(86, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:31:05'),
(87, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:31:32'),
(88, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:31:41'),
(89, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:32:28'),
(90, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:32:39'),
(91, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:33:07'),
(92, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:33:14'),
(93, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:33:26'),
(94, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:33:30'),
(95, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:34:04'),
(96, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:35:15'),
(97, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:35:52'),
(98, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:37:09'),
(99, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:38:47'),
(100, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:39:39'),
(101, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:41:09'),
(102, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:42:14'),
(103, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:44:15'),
(104, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:44:34'),
(105, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:47:06'),
(106, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:47:12'),
(107, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:48:15'),
(108, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:48:28'),
(109, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:52:15'),
(110, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:55:47'),
(111, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:55:55'),
(112, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:56:21'),
(113, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:56:25'),
(114, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:57:09'),
(115, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:57:31'),
(116, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:57:33'),
(117, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:58:29'),
(118, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:58:31'),
(119, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:58:38'),
(120, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:59:28'),
(121, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:59:31'),
(122, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:59:34'),
(123, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:59:37'),
(124, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:59:39'),
(125, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:59:42'),
(126, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 16:59:45'),
(127, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:00:38'),
(128, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:00:41'),
(129, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:00:44'),
(130, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:00:48'),
(131, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:00:52'),
(132, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:00:56'),
(133, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:02:45'),
(134, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:03:37'),
(135, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:03:41'),
(136, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:03:43'),
(137, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:03:45'),
(138, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:03:50'),
(139, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:04:55'),
(140, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:04:57'),
(141, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:05:01'),
(142, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:05:31'),
(143, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:05:33'),
(144, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 17:05:36'),
(145, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:25:26'),
(146, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:25:36'),
(147, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:25:43'),
(148, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:25:46'),
(149, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:25:50'),
(150, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:25:53'),
(151, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:26:50'),
(152, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:30:44'),
(153, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:30:48'),
(154, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:31:04'),
(155, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:31:07'),
(156, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:35:13'),
(157, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:37:31'),
(158, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:38:06'),
(159, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:38:11'),
(160, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:38:49'),
(161, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:38:50'),
(162, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:38:54'),
(163, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:38:58'),
(164, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:19'),
(165, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:22'),
(166, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:24'),
(167, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:26'),
(168, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:29'),
(169, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:31'),
(170, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:34'),
(171, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:36'),
(172, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:39'),
(173, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:40:41'),
(174, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:44'),
(175, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:46'),
(176, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:48'),
(177, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:50'),
(178, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:52'),
(179, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:54'),
(180, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:56'),
(181, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:41:58'),
(182, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:42:01'),
(183, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:42:04'),
(184, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:42:10'),
(185, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:42:15'),
(186, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:42:17'),
(187, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:42:20'),
(188, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:44:01'),
(189, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:44:27'),
(190, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:44:31'),
(191, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:44:35'),
(192, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:44:38'),
(193, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:44:55'),
(194, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:44:58'),
(195, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:45:02'),
(196, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:45:05'),
(197, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:45:07'),
(198, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:46:04'),
(199, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:46:06'),
(200, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:46:18'),
(201, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:48:20'),
(202, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:50:12'),
(203, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:50:45'),
(204, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:50:53'),
(205, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:25'),
(206, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:27'),
(207, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:30'),
(208, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:32'),
(209, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:34'),
(210, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:37'),
(211, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:39'),
(212, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:41'),
(213, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:43'),
(214, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:45'),
(215, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:49'),
(216, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:54'),
(217, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:56'),
(218, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:52:58'),
(219, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 19:53:02'),
(220, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:08:26'),
(221, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:10:41'),
(222, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:10:54'),
(223, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:11:05'),
(224, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:11:50'),
(225, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:11:57'),
(226, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:12:31'),
(227, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:13:14'),
(228, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:20:34'),
(229, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:24:50'),
(230, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:25:32'),
(231, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:26:06'),
(232, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:26:15'),
(233, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:26:25'),
(234, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:26:31'),
(235, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:26:56'),
(236, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:27:02'),
(237, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:27:10'),
(238, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:27:53'),
(239, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:28:03'),
(240, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:28:17'),
(241, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:28:34'),
(242, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:28:43'),
(243, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:28:50'),
(244, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:28:57'),
(245, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:29:07'),
(246, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:29:38'),
(247, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:29:43'),
(248, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:29:52'),
(249, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:30:08'),
(250, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:30:23'),
(251, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:30:30'),
(252, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:30:50'),
(253, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:30:57'),
(254, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:31:04'),
(255, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:32:51'),
(256, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:33:00'),
(257, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:33:04'),
(258, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:33:17'),
(259, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:33:28'),
(260, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:33:57'),
(261, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:34:04'),
(262, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:34:11'),
(263, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:34:41'),
(264, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:34:54'),
(265, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:35:18'),
(266, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:35:24'),
(267, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:35:32'),
(268, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:36:17'),
(269, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:36:27'),
(270, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:36:36'),
(271, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:36:44'),
(272, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:36:48'),
(273, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:37:08'),
(274, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:37:22'),
(275, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:38:58'),
(276, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:39:16'),
(277, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:39:23'),
(278, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:39:34'),
(279, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:39:51'),
(280, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:39:59'),
(281, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:41:08'),
(282, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:41:50'),
(283, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:45:32'),
(284, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:52:05'),
(285, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:53:07'),
(286, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:53:48'),
(287, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:54:03'),
(288, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:54:36'),
(289, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:27'),
(290, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:29'),
(291, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:31'),
(292, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:32'),
(293, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:34'),
(294, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:37'),
(295, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:42'),
(296, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:44'),
(297, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:46'),
(298, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:56:48'),
(299, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:57:03'),
(300, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:57:12'),
(301, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:58:14'),
(302, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:58:32'),
(303, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:24'),
(304, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:27'),
(305, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:29'),
(306, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:31'),
(307, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:32'),
(308, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:49'),
(309, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:51'),
(310, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:53'),
(311, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 20:59:55'),
(312, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:00:06'),
(313, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:19'),
(314, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:30'),
(315, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:45'),
(316, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:49'),
(317, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:52'),
(318, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:54'),
(319, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:56'),
(320, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:01:58'),
(321, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:05:39'),
(322, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:05:43'),
(323, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:05:47'),
(324, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:05:49'),
(325, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:05:57'),
(326, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:06:00'),
(327, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:06:03'),
(328, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:06:09'),
(329, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:06:22'),
(330, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:42:32'),
(331, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-11 21:48:52'),
(332, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 16:35:05'),
(333, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 16:35:19'),
(334, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 16:35:25'),
(335, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:06:08'),
(336, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:14:14'),
(337, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:14:17'),
(338, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:14:25'),
(339, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:24:07'),
(340, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:25:23'),
(341, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:29:23'),
(342, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:38:21'),
(343, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:38:24'),
(344, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:38:27'),
(345, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:39:22'),
(346, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:48:11'),
(347, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:48:36'),
(348, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 17:50:22'),
(349, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:39:22'),
(350, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:40:39'),
(351, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:40:48'),
(352, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:40:52'),
(353, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:40:55'),
(354, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:43:01'),
(355, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:43:06'),
(356, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:43:09'),
(357, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:43:15'),
(358, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:43:18'),
(359, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:43:21'),
(360, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:44:21'),
(361, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:44:26'),
(362, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:44:29'),
(363, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:44:33'),
(364, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:45:20'),
(365, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:48:07'),
(366, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:48:12'),
(367, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:51:26'),
(368, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:51:30'),
(369, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:51:34'),
(370, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:51:40'),
(371, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:57:30'),
(372, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:57:45'),
(373, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:57:48'),
(374, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:57:53'),
(375, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:57:59'),
(376, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:58:04'),
(377, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:58:12'),
(378, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 18:58:17'),
(379, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:00:44'),
(380, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:00:50'),
(381, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:00:53'),
(382, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:02:07'),
(383, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:02:17'),
(384, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:03:20'),
(385, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:03:28'),
(386, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:03:30'),
(387, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:03:32'),
(388, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:07:42'),
(389, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:07:52'),
(390, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:37:18'),
(391, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:37:29'),
(392, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:37:39'),
(393, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:37:48'),
(394, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:38:35'),
(395, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:39:45'),
(396, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:41:23'),
(397, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:41:49'),
(398, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:42:36'),
(399, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:52:02'),
(400, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:52:09'),
(401, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:53:13'),
(402, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:54:47'),
(403, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:54:58'),
(404, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:55:43'),
(405, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:56:03'),
(406, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:56:07'),
(407, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:56:27'),
(408, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:56:30'),
(409, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:57:57'),
(410, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:58:31'),
(411, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:58:34'),
(412, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 19:59:53'),
(413, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:00:16'),
(414, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:00:44'),
(415, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:02:14'),
(416, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:02:24'),
(417, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:02:28'),
(418, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:02:32'),
(419, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:02:34'),
(420, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:02:37'),
(421, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:03:36'),
(422, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:03:49'),
(423, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:03:59'),
(424, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:04:11'),
(425, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:04:19'),
(426, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:04:28'),
(427, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:04:45'),
(428, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:04:52'),
(429, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:04:59'),
(430, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:05:30'),
(431, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:05:36'),
(432, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:05:58'),
(433, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:06:39'),
(434, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:06:52'),
(435, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:06:55'),
(436, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:07:06'),
(437, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:09:50'),
(438, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:10:00'),
(439, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:10:19'),
(440, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:10:24'),
(441, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:10:59'),
(442, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:11:03'),
(443, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:11:39'),
(444, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:11:45'),
(445, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:11:47'),
(446, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:12:39'),
(447, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:13:10'),
(448, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:14:19'),
(449, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:14:22'),
(450, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:15:03'),
(451, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:15:06'),
(452, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:15:23'),
(453, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:15:27'),
(454, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:15:49'),
(455, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:15:54'),
(456, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:16:00'),
(457, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:16:02'),
(458, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:17:38'),
(459, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:18:32'),
(460, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:24:05'),
(461, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:24:15'),
(462, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:24:18'),
(463, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:24:20'),
(464, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:24:23'),
(465, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:24:25'),
(466, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:25:26'),
(467, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:25:28'),
(468, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:25:29'),
(469, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:25:31'),
(470, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:25:32'),
(471, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:25:35'),
(472, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:25:38'),
(473, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:26:58'),
(474, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:27:00'),
(475, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:27:02'),
(476, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:27:03'),
(477, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:27:39'),
(478, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:27:43'),
(479, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:27:47'),
(480, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:27:56'),
(481, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:28:01'),
(482, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:28:09'),
(483, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:28:16'),
(484, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:30:53'),
(485, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:30:55'),
(486, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:30:57'),
(487, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:32:28'),
(488, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:32:30'),
(489, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:32:33'),
(490, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:33:01'),
(491, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:34:15'),
(492, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:34:29'),
(493, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:34:33'),
(494, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:34:38'),
(495, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:34:50'),
(496, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:36:01'),
(497, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:36:47'),
(498, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:37:19'),
(499, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:37:54'),
(500, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:38:03'),
(501, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:38:07'),
(502, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:38:16'),
(503, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:38:19'),
(504, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:38:30'),
(505, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:40:13'),
(506, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:40:16'),
(507, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:42:45'),
(508, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:45:44'),
(509, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:48:17'),
(510, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:48:38'),
(511, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:53:57'),
(512, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:54:45'),
(513, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:55:17'),
(514, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:56:29'),
(515, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:57:00'),
(516, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:57:53'),
(517, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 20:58:38'),
(518, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:00:11'),
(519, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:00:59'),
(520, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:01:17'),
(521, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:01:44'),
(522, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:02:01'),
(523, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:02:21'),
(524, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:02:42'),
(525, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:02:54'),
(526, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:03:57'),
(527, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-12 21:04:04'),
(528, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:02:54'),
(529, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:13:31'),
(530, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:14:36'),
(531, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:18:58'),
(532, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:21:28'),
(533, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:22:36'),
(534, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:23:52'),
(535, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:24:34'),
(536, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:25:37'),
(537, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:26:06'),
(538, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:26:50'),
(539, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:28:20'),
(540, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:29:09'),
(541, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:29:31'),
(542, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:31:32'),
(543, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:32:01'),
(544, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:34:23'),
(545, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:34:26'),
(546, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:37:59'),
(547, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:38:42'),
(548, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:39:53'),
(549, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:40:33'),
(550, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:41:02'),
(551, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-13 18:44:43'),
(552, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 15:19:23'),
(553, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 15:57:57'),
(554, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 15:58:37'),
(555, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:04:39'),
(556, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:07:05'),
(557, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:09:10'),
(558, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:09:44'),
(559, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:10:02'),
(560, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:21:48'),
(561, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:23:33'),
(562, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:23:57'),
(563, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:24:47'),
(564, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:26:46'),
(565, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:28:22'),
(566, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:29:11'),
(567, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:36:30'),
(568, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:40:19'),
(569, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:42:21'),
(570, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:48:13'),
(571, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:48:22'),
(572, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:48:28'),
(573, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:50:42'),
(574, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:52:21'),
(575, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:52:25'),
(576, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:53:11'),
(577, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:53:29'),
(578, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:53:31'),
(579, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:54:52'),
(580, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:57:49'),
(581, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:58:54'),
(582, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:58:56'),
(583, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:59:07'),
(584, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:59:41'),
(585, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 16:59:58'),
(586, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:00:00'),
(587, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:00:15'),
(588, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:01:40'),
(589, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:11:16'),
(590, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:11:32'),
(591, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:11:35'),
(592, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:11:39'),
(593, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:11:41'),
(594, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:12:39'),
(595, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:12:56'),
(596, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:16:55'),
(597, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:17:03'),
(598, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:17:05'),
(599, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:17:57'),
(600, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:18:58'),
(601, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:20:31'),
(602, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:24:37'),
(603, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:28:37'),
(604, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:57:16'),
(605, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:57:21'),
(606, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:57:27'),
(607, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:57:31'),
(608, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:57:37'),
(609, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:57:44'),
(610, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:58:07'),
(611, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:58:53'),
(612, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:58:56'),
(613, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:59:03'),
(614, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 17:59:19'),
(615, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:03:19'),
(616, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:03:23'),
(617, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:04:24'),
(618, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:04:27'),
(619, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:04:30'),
(620, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:09:07'),
(621, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:09:09'),
(622, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:09:27'),
(623, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:09:30'),
(624, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:11:05'),
(625, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:11:18'),
(626, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:11:58'),
(627, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:12:00'),
(628, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:02'),
(629, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:05'),
(630, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:12'),
(631, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:18'),
(632, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:22'),
(633, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:46'),
(634, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:53'),
(635, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:17:57'),
(636, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:18:01'),
(637, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:18:29'),
(638, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:18:37'),
(639, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:18:42'),
(640, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:18:46'),
(641, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:21:46'),
(642, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:21:53'),
(643, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:22:07'),
(644, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:22:12'),
(645, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:22:16'),
(646, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:23:31'),
(647, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:23:35'),
(648, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:24:09'),
(649, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:24:13'),
(650, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:24:41'),
(651, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:26:00'),
(652, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:26:06'),
(653, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:29:18'),
(654, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:29:35'),
(655, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:35:00'),
(656, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:37:50'),
(657, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:38:30'),
(658, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:40:27'),
(659, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:41:26'),
(660, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:44:26'),
(661, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:44:34'),
(662, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:44:38'),
(663, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:47:00'),
(664, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:47:16'),
(665, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:47:38'),
(666, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:48:14'),
(667, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:48:32'),
(668, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:48:50'),
(669, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:49:04'),
(670, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:49:08'),
(671, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:49:10'),
(672, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:49:40'),
(673, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:50:10'),
(674, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:50:26'),
(675, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:51:01'),
(676, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:51:24'),
(677, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:51:27'),
(678, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:51:31'),
(679, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:51:49'),
(680, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:52:05'),
(681, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:52:18'),
(682, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:53:28'),
(683, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:53:50'),
(684, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:54:57'),
(685, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:55:30'),
(686, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:56:53'),
(687, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 18:57:59'),
(688, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:00:47'),
(689, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:01:07'),
(690, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:01:32'),
(691, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:01:42'),
(692, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:01:47'),
(693, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:01:53'),
(694, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:02:00'),
(695, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:02:46'),
(696, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:02:50'),
(697, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:02:59'),
(698, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:20'),
(699, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:22'),
(700, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:25'),
(701, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:26'),
(702, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:28'),
(703, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:29'),
(704, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:29'),
(705, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:30'),
(706, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:30'),
(707, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:30'),
(708, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:03:30'),
(709, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:13'),
(710, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:16'),
(711, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:20'),
(712, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:21'),
(713, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:21'),
(714, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:22'),
(715, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:23'),
(716, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:23'),
(717, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:23'),
(718, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:23'),
(719, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:25'),
(720, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:28'),
(721, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:30'),
(722, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:32'),
(723, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:33'),
(724, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:35'),
(725, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:35'),
(726, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:35'),
(727, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:36'),
(728, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:38'),
(729, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:04:39'),
(730, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:46'),
(731, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:48'),
(732, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:50'),
(733, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:52'),
(734, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:53'),
(735, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:54'),
(736, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:55'),
(737, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:55'),
(738, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:57'),
(739, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:57'),
(740, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:05:59'),
(741, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:06:46'),
(742, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:06:59'),
(743, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:07:14'),
(744, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:08:43'),
(745, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:08:47'),
(746, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:09:51'),
(747, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:09:54'),
(748, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:10:02'),
(749, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:11:05'),
(750, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:11:09'),
(751, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:00'),
(752, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:02'),
(753, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:04'),
(754, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:06'),
(755, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:06'),
(756, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:06'),
(757, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:07'),
(758, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:07'),
(759, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:07'),
(760, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:07'),
(761, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:09'),
(762, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:10'),
(763, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:14'),
(764, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:15'),
(765, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:16'),
(766, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:17'),
(767, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:20');
INSERT INTO `m5jbw_mediamallfactory_log_credits` (`id`, `user_id`, `type`, `credits`, `sign`, `media_id`, `purchase_id`, `pending`, `created_at`) VALUES
(768, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:20'),
(769, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:20'),
(770, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:21'),
(771, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:31'),
(772, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:33'),
(773, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:35'),
(774, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:37'),
(775, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:39'),
(776, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:42'),
(777, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:43'),
(778, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:44'),
(779, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:46'),
(780, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:47'),
(781, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:48'),
(782, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:49'),
(783, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:50'),
(784, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:52'),
(785, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:53'),
(786, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:54'),
(787, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:55'),
(788, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:14:57'),
(789, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:39'),
(790, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:43'),
(791, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:46'),
(792, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:47'),
(793, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:49'),
(794, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:50'),
(795, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:52'),
(796, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:55'),
(797, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:56'),
(798, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:15:57'),
(799, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:16:01'),
(800, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:16:03'),
(801, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:16:05'),
(802, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:16:07'),
(803, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:16:25'),
(804, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:16:41'),
(805, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:17:01'),
(806, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:17:37'),
(807, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:17:42'),
(808, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:17:48'),
(809, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:17:54'),
(810, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:17:58'),
(811, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:18:00'),
(812, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:18:02'),
(813, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:18:05'),
(814, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:20:48'),
(815, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:20:58'),
(816, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:21:04'),
(817, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:21:06'),
(818, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:21:07'),
(819, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:21:09'),
(820, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:21:09'),
(821, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:21:11'),
(822, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:21:13'),
(823, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:25:29'),
(824, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:25:34'),
(825, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:26:46'),
(826, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:05'),
(827, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:07'),
(828, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:07'),
(829, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:07'),
(830, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:07'),
(831, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:08'),
(832, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:08'),
(833, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:10'),
(834, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:27:11'),
(835, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:29:36'),
(836, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:29:40'),
(837, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:29:43'),
(838, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:29:44'),
(839, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:29:50'),
(840, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:29:52'),
(841, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:29:53'),
(842, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:31:30'),
(843, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:31:33'),
(844, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:31:35'),
(845, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:31:36'),
(846, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:31:59'),
(847, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:32:04'),
(848, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:42:55'),
(849, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:43:00'),
(850, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:43:04'),
(851, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:49:00'),
(852, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:49:07'),
(853, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:49:14'),
(854, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:32'),
(855, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:34'),
(856, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:39'),
(857, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:41'),
(858, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:43'),
(859, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:44'),
(860, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:46'),
(861, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 19:52:53'),
(862, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:03:50'),
(863, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:10:52'),
(864, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:10:53'),
(865, 349, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:29:06'),
(866, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:31:28'),
(867, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:34:43'),
(868, 351, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:35:13'),
(869, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:38:56'),
(870, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:38:58'),
(871, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:39:05'),
(872, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:39:06'),
(873, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:39:08'),
(874, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:39:10'),
(875, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:39:12'),
(876, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:39:13'),
(877, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:00'),
(878, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:02'),
(879, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:04'),
(880, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:06'),
(881, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:07'),
(882, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:09'),
(883, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:13'),
(884, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:40:15'),
(885, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:10'),
(886, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:13'),
(887, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:15'),
(888, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:17'),
(889, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:19'),
(890, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:21'),
(891, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:23'),
(892, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:25'),
(893, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:26'),
(894, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:29'),
(895, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:55'),
(896, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:55'),
(897, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:41:57'),
(898, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:00'),
(899, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:25'),
(900, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:26'),
(901, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:28'),
(902, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:29'),
(903, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:38'),
(904, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:40'),
(905, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:42'),
(906, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:46'),
(907, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:42:48'),
(908, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:56:24'),
(909, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:59:28'),
(910, 0, 'initial_credits', 5, 1, 0, 0, 1, '2013-09-14 20:59:31');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_media`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_media`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `rating` decimal(2,1) NOT NULL,
  `votes` int(11) NOT NULL,
  `cost_media` int(11) NOT NULL,
  `cost_archive` int(11) NOT NULL,
  `details_media` mediumtext NOT NULL,
  `details_archive` mediumtext NOT NULL,
  `filename_media` varchar(255) NOT NULL,
  `filename_archive` varchar(255) NOT NULL,
  `filename_thumbnail` varchar(255) NOT NULL,
  `has_media` tinyint(1) NOT NULL,
  `has_archive` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `downloads` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_media`
--

INSERT INTO `m5jbw_mediamallfactory_media` (`id`, `title`, `description`, `rating`, `votes`, `cost_media`, `cost_archive`, `details_media`, `details_archive`, `filename_media`, `filename_archive`, `filename_thumbnail`, `has_media`, `has_archive`, `user_id`, `category_id`, `type_id`, `downloads`, `published`, `created_at`, `updated_at`) VALUES
(1, 'Media 1', 'Description de Media 1', '0.0', 0, 1, 0, 'Details Media 1', '', '121511P01.pdf', '', '1236382-504128889681396-692446141-n-1.jpg', 1, 0, 342, 78, 1, 1, 1, '2013-09-09 16:50:13', '2013-09-09 16:59:46');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_media_log`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_media_log`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_media_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `media_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `media_id` (`media_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_media_log`
--

INSERT INTO `m5jbw_mediamallfactory_media_log` (`id`, `media_id`, `user_id`, `type`, `created_at`) VALUES
(1, 1, 344, 'media', '2013-09-09 16:59:46');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_notifications`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_notifications`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` mediumtext NOT NULL,
  `lang_code` varchar(10) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_notifications`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_orders`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_orders`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `gateway` varchar(20) NOT NULL,
  `params` mediumtext NOT NULL,
  `paid` tinyint(1) NOT NULL,
  `payment_id` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_orders`
--

INSERT INTO `m5jbw_mediamallfactory_orders` (`id`, `title`, `user_id`, `amount`, `currency`, `gateway`, `params`, `paid`, `payment_id`, `status`, `created_at`) VALUES
(1, '10 credits', 343, '5.00', 'EUR', 'paypal', '{"credits":"10","bonus":0}', 0, 0, 10, '2013-09-08 17:43:03'),
(2, '10 credits', 343, '5.00', 'EUR', 'paypal', '{"credits":"10","bonus":0}', 0, 0, 10, '2013-09-08 17:44:38');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_pack`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_pack`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_pack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `rating` decimal(2,1) NOT NULL,
  `votes` int(11) NOT NULL,
  `cost_media` int(11) NOT NULL,
  `cost_archive` int(11) NOT NULL,
  `details_media` mediumtext NOT NULL,
  `details_archive` mediumtext NOT NULL,
  `filename_media` varchar(255) NOT NULL,
  `filename_archive` varchar(255) NOT NULL,
  `filename_thumbnail` varchar(255) NOT NULL,
  `has_media` tinyint(1) NOT NULL,
  `has_archive` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `downloads` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_pack`
--

INSERT INTO `m5jbw_mediamallfactory_pack` (`id`, `title`, `description`, `rating`, `votes`, `cost_media`, `cost_archive`, `details_media`, `details_archive`, `filename_media`, `filename_archive`, `filename_thumbnail`, `has_media`, `has_archive`, `user_id`, `category_id`, `type_id`, `downloads`, `published`, `created_at`, `updated_at`) VALUES
(1, 'Pack1', 'Description de Media 1', '0.0', 0, 1, 0, 'Details Media 1', '', '121511P01.pdf', '', '1236382-504128889681396-692446141-n-1.jpg', 1, 0, 342, 78, 1, 1, 1, '2013-09-09 16:50:13', '2013-09-09 16:59:46'),
(2, 'Pack2', '', '0.0', 0, 0, 0, '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_payments`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_payments`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `gateway` varchar(20) NOT NULL,
  `refnumber` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `request` mediumtext NOT NULL,
  `errors` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_payments`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_payment_gateways`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_payment_gateways`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `element` varchar(50) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `purchase_logo` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL,
  `params` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_payment_gateways`
--

INSERT INTO `m5jbw_mediamallfactory_payment_gateways` (`id`, `title`, `element`, `logo`, `purchase_logo`, `ordering`, `params`, `published`) VALUES
(1, 'authorizenet', 'authorizenet', '', '', 0, '', 0),
(2, 'moneybookers', 'moneybookers', '', '', 0, '', 1),
(3, 'paypal', 'paypal', '', '', 0, '{"email":"hichem@eyasoft.net","action":"https:\\/\\/www.paypal.com\\/cgi-bin\\/webscr","action_sandbox":"https:\\/\\/www.sandbox.paypal.com\\/cgi-bin\\/webscr","sandbox":"1"}', 1),
(4, 'sagepay', 'sagepay', '', '', 0, '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_payment_requests`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_payment_requests`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_payment_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `resolved_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_payment_requests`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_profiles`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_profiles`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_profiles` (
  `user_id` int(11) NOT NULL,
  `credits` int(11) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `balance_available` decimal(10,2) NOT NULL,
  `revenue` decimal(10,2) NOT NULL,
  `review_id` tinyint(1) NOT NULL,
  `allow_contact` tinyint(1) NOT NULL,
  `list_limit` tinyint(1) NOT NULL,
  `media_list_limit` tinyint(1) NOT NULL,
  `params` mediumtext NOT NULL,
  `profiled` tinyint(4) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_mediamallfactory_profiles`
--

INSERT INTO `m5jbw_mediamallfactory_profiles` (`user_id`, `credits`, `balance`, `balance_available`, `revenue`, `review_id`, `allow_contact`, `list_limit`, `media_list_limit`, `params`, `profiled`) VALUES
(343, 4, '0.00', '0.00', '0.00', 1, 0, 10, 10, '{"first_name":"Hichem","last_name":"Feki","address":"Sfax","city":"Sfax","country":"TUN","notifications":{"user_invoice_issued":"0"}}', 1),
(344, 0, '0.00', '0.00', '0.00', 0, 0, 10, 10, '{"first_name":"Eya","last_name":"Feki","address":"Sfax","city":"Sfax","country":"TUN","notifications":{"user_invoice_issued":"0"}}', 1),
(342, 5, '1.20', '1.20', '1.20', 0, 0, 10, 10, '{"first_name":"Behappy","last_name":"Feki","address":"Sfax","city":"Sfax","country":"TUN","notifications":{"user_invoice_issued":"1"}}', 1),
(348, 5, '0.00', '0.00', '0.00', 0, 0, 10, 10, '', 0),
(349, 5, '0.00', '0.00', '0.00', 0, 0, 10, 10, '', 0),
(351, 5, '0.00', '0.00', '0.00', 0, 0, 10, 10, '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_purchases`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_purchases`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `media_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `views_bought` int(11) NOT NULL,
  `views_seen` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `credits` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `pending_seller` tinyint(1) NOT NULL,
  `pending_buyer` tinyint(1) NOT NULL,
  `last_viewed_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `media_id` (`media_id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_purchases`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_registrations`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_registrations`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_registrations` (
  `user_id` int(11) NOT NULL,
  `credits` int(11) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `balance_available` decimal(10,2) NOT NULL,
  `revenue` decimal(10,2) NOT NULL,
  `review_id` tinyint(1) NOT NULL,
  `allow_contact` tinyint(1) NOT NULL,
  `list_limit` tinyint(1) NOT NULL,
  `media_list_limit` tinyint(1) NOT NULL,
  `params` mediumtext NOT NULL,
  `profiled` tinyint(4) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_mediamallfactory_registrations`
--

INSERT INTO `m5jbw_mediamallfactory_registrations` (`user_id`, `credits`, `balance`, `balance_available`, `revenue`, `review_id`, `allow_contact`, `list_limit`, `media_list_limit`, `params`, `profiled`) VALUES
(343, 4, '0.00', '0.00', '0.00', 1, 0, 10, 10, '{"first_name":"Hichem","last_name":"Feki","address":"Sfax","city":"Sfax","country":"TUN","notifications":{"user_invoice_issued":"0"}}', 1),
(344, 0, '0.00', '0.00', '0.00', 0, 0, 10, 10, '{"first_name":"Eya","last_name":"Feki","address":"Sfax","city":"Sfax","country":"TUN","notifications":{"user_invoice_issued":"0"}}', 1),
(342, 5, '1.20', '1.20', '1.20', 0, 0, 10, 10, '{"first_name":"Behappy","last_name":"Feki","address":"Sfax","city":"Sfax","country":"TUN","notifications":{"user_invoice_issued":"1"}}', 1),
(348, 5, '0.00', '0.00', '0.00', 0, 0, 10, 10, '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_mediamallfactory_types`
--

DROP TABLE IF EXISTS `m5jbw_mediamallfactory_types`;
CREATE TABLE IF NOT EXISTS `m5jbw_mediamallfactory_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `player` varchar(20) NOT NULL,
  `views` int(11) NOT NULL,
  `cost_media` int(11) NOT NULL,
  `cost_archive` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `m5jbw_mediamallfactory_types`
--

INSERT INTO `m5jbw_mediamallfactory_types` (`id`, `title`, `player`, `views`, `cost_media`, `cost_archive`, `published`) VALUES
(1, 'Media Type1', 'download', 5, 1, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_menu`
--

DROP TABLE IF EXISTS `m5jbw_menu`;
CREATE TABLE IF NOT EXISTS `m5jbw_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `ordering` int(11) NOT NULL DEFAULT '0' COMMENT 'The relative ordering of the menu item in the tree.',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(333)),
  KEY `idx_language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=484 ;

--
-- Contenu de la table `m5jbw_menu`
--

INSERT INTO `m5jbw_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `ordering`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 319, 0, '*', 0),
(2, 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 0, 1, 1, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 13, 22, 0, '*', 1),
(3, 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 0, 2, 2, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 14, 15, 0, '*', 1),
(4, 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 0, 2, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 16, 17, 0, '*', 1),
(5, 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 0, 2, 2, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 18, 19, 0, '*', 1),
(6, 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 0, 2, 2, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 20, 21, 0, '*', 1),
(7, 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 0, 1, 1, 8, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 23, 28, 0, '*', 1),
(8, 'menu', 'com_contact', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 0, 7, 2, 8, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 24, 25, 0, '*', 1),
(9, 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 0, 7, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 26, 27, 0, '*', 1),
(10, 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 0, 1, 1, 15, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 29, 34, 0, '*', 1),
(11, 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 0, 10, 2, 15, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 30, 31, 0, '*', 1),
(12, 'menu', 'com_messages_read', 'Read Private Message', '', 'Messaging/Read Private Message', 'index.php?option=com_messages', 'component', 0, 10, 2, 15, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-read', 0, '', 32, 33, 0, '*', 1),
(13, 'menu', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 1, 1, 17, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 35, 40, 0, '*', 1),
(14, 'menu', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 13, 2, 17, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 36, 37, 0, '*', 1),
(15, 'menu', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', 0, 13, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds-cat', 0, '', 38, 39, 0, '*', 1),
(16, 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 0, 1, 1, 24, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 55, 56, 0, '*', 1),
(17, 'menu', 'com_search', 'Basic Search', '', 'Basic Search', 'index.php?option=com_search', 'component', 0, 1, 1, 19, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:search', 0, '', 45, 46, 0, '*', 1),
(18, 'menu', 'com_weblinks', 'Weblinks', '', 'Weblinks', 'index.php?option=com_weblinks', 'component', 0, 1, 1, 21, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 49, 54, 0, '*', 1),
(19, 'menu', 'com_weblinks_links', 'Links', '', 'Weblinks/Links', 'index.php?option=com_weblinks', 'component', 0, 18, 2, 21, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 50, 51, 0, '*', 1),
(20, 'menu', 'com_weblinks_categories', 'Categories', '', 'Weblinks/Categories', 'index.php?option=com_categories&extension=com_weblinks', 'component', 0, 18, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks-cat', 0, '', 52, 53, 0, '*', 1),
(21, 'menu', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', 0, 1, 1, 27, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:finder', 0, '', 41, 42, 0, '*', 1),
(22, 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 0, 1, 1, 28, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 43, 44, 0, '*', 1),
(201, 'menumembre', 'Votre profil', 'votre-profil', '', 'votre-profil', 'index.php?option=com_users&view=profile', 'component', 0, 1, 1, 25, 0, 0, '0000-00-00 00:00:00', 0, 2, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 239, 240, 0, '*', 0),
(207, 'menuhaut', 'Joomla.org', 'joomlaorg', '', 'joomlaorg', 'http://joomla.org', 'url', 1, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 1, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":""}', 237, 238, 0, '*', 0),
(227, 'menujoomla', 'Catégories de liens web', 'categories-liens-web', '', 'utiliser-joomla/utiliser-extensions/composants/composant-liens-web/categories-liens-web', 'index.php?option=com_weblinks&view=categories&id=18', 'component', 0, 265, 5, 21, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_base_description":"","categories_description":"","maxLevelcat":"-1","show_empty_categories_cat":"","show_subcat_desc_cat":"","show_cat_num_links_cat":"","show_category_title":"","show_description":"","show_description_image":"","maxLevel":"-1","show_empty_categories":"","show_subcat_desc":"","show_cat_num_links":"","show_pagination_limit":"","show_headings":"","show_link_description":"","show_link_hits":"","show_pagination":"","show_pagination_results":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 91, 92, 0, '*', 0),
(229, 'menujoomla', 'Fiche de Contact', 'fiche-contact', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contact/fiche-contact', 'index.php?option=com_contact&view=contact&id=1', 'component', 0, 270, 5, 8, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_category_crumb":"","presentation_style":"","show_contact_category":"","show_contact_list":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 81, 82, 0, '*', 0),
(233, 'menumembre', 'Identification', 'login', '', 'login', 'index.php?option=com_users&view=login', 'component', 1, 1, 1, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"login_redirect_url":"","logindescription_show":"1","login_description":"","login_image":"","logout_redirect_url":"","logoutdescription_show":"1","logout_description":"","logout_image":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 1, 2, 0, '*', 0),
(234, 'menuparcs', 'Blog du site des Parcs', 'park-blog', '', 'park-blog', 'index.php?option=com_content&view=category&layout=blog&id=27', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 114, '{"maxLevel":"","show_empty_categories":"","show_description":"1","show_description_image":"1","show_category_title":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"1","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"2","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 243, 244, 0, 'fr-FR', 0),
(238, 'mainmenu', 'Sites exemples', 'sample-sites', '', 'sample-sites', 'index.php?option=com_content&view=article&id=38', 'component', 0, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"0","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 267, 272, 0, '*', 0),
(242, 'menuparcs', 'Ajouter un message au Blog', 'write-a-blog-post', '', 'write-a-blog-post', 'index.php?option=com_content&view=form&layout=edit', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 3, '', 114, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 245, 246, 0, 'fr-FR', 0),
(243, 'menuparcs', 'Accueil des Parcs', 'parks-home', '', 'parks-home', 'index.php?option=com_content&view=article&id=6', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 114, '{"show_noauth":"","show_title":"0","link_titles":"","show_intro":"","show_category":"0","link_category":"0","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"","show_print_icon":"0","show_email_icon":"0","show_hits":"0","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 241, 242, 0, 'fr-FR', 0),
(244, 'menuparcs', 'Galerie Photo', 'image-gallery', '', 'image-gallery', 'index.php?option=com_content&view=categories&id=28', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 114, '{"show_base_description":"1","categories_description":"","maxLevelcat":"","show_empty_categories_cat":"","show_subcat_desc_cat":"","show_cat_num_articles_cat":"","drill_down_layout":"1","show_category_title":"","show_description":"1","show_description_image":"1","maxLevel":"-1","show_empty_categories":"","show_subcat_desc":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_results":"","show_pagination_limit":"","filter_field":"","show_headings":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 247, 252, 0, 'fr-FR', 0),
(249, 'menujoomla', 'Proposer un lien web', 'proposer-lien-web', '', 'utiliser-joomla/utiliser-extensions/composants/composant-liens-web/proposer-lien-web', 'index.php?option=com_weblinks&view=form&layout=edit', 'component', 0, 265, 5, 21, 0, 0, '0000-00-00 00:00:00', 0, 3, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 87, 88, 0, '*', 0),
(251, 'menujoomla', 'Catégories de contacts', 'categories-contacts', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contact/categories-contacts', 'index.php?option=com_contact&view=categories&id=16', 'component', 0, 270, 5, 8, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_base_description":"","categories_description":"","maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","filter_field":"","show_pagination":"","show_noauth":"","presentation_style":"sliders","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"1","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 77, 78, 0, '*', 0),
(252, 'menujoomla', 'Catégories de fils d''actualité', 'categories-fils-actualites', '', 'utiliser-joomla/utiliser-extensions/composants/composant-actualite-rss/categories-fils-actualites', 'index.php?option=com_newsfeeds&view=categories&id=0', 'component', 0, 267, 5, 17, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_base_description":"1","categories_description":"Because this links to the root category the "uncategorised" category is displayed. ","maxLevel":"-1","show_empty_categories":"1","show_description":"1","show_description_image":"1","show_cat_num_articles":"1","display_num":"","show_headings":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_feed_image":"","show_feed_description":"","show_item_description":"","feed_character_count":"0","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 95, 96, 0, '*', 0),
(253, 'menujoomla', 'Une catégorie de fils d''actualité', 'categorie-fils-actualite', '', 'utiliser-joomla/utiliser-extensions/composants/composant-actualite-rss/categorie-fils-actualite', 'index.php?option=com_newsfeeds&view=category&id=17', 'component', 0, 267, 5, 17, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_feed_image":"","show_feed_description":"","show_item_description":"","feed_character_count":"0","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 99, 100, 0, '*', 0),
(254, 'menujoomla', 'Un fil d''actualité', 'un-fil-actualite', '', 'utiliser-joomla/utiliser-extensions/composants/composant-actualite-rss/un-fil-actualite', 'index.php?option=com_newsfeeds&view=newsfeed&id=4', 'component', 0, 267, 5, 17, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_feed_image":"","show_feed_description":"","show_item_description":"","feed_character_count":"0","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 97, 98, 0, '*', 0),
(255, 'menujoomla', 'Recherche et résultats', 'recherche-resultats', '', 'utiliser-joomla/utiliser-extensions/composants/composant-recherche/recherche-resultats', 'index.php?option=com_search&view=search', 'component', 0, 276, 5, 19, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"search_areas":"1","show_date":"1","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 117, 118, 0, '*', 0),
(256, 'menujoomla', 'Articles archivés', 'articles-archives', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu/articles-archives', 'index.php?option=com_content&view=archive', 'component', 0, 266, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"orderby_sec":"","order_date":"","display_num":"","filter_field":"","show_category":"1","link_category":"1","show_title":"1","link_titles":"1","show_intro":"1","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_hits":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 71, 72, 0, '*', 0),
(257, 'menujoomla', 'Un article', 'article', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu/article', 'index.php?option=com_content&view=article&id=6', 'component', 0, 266, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 61, 62, 0, '*', 0),
(259, 'menujoomla', 'Articles d''une catégorie en blog', 'articles-categorie-blog', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu/articles-categorie-blog', 'index.php?option=com_content&view=category&layout=blog&id=27', 'component', 0, 266, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"0","show_description_image":"0","show_category_title":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"2","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 65, 66, 0, '*', 0),
(260, 'menujoomla', 'Articles d''une catégorie en liste', 'articles-categorie-liste', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu/articles-categorie-liste', 'index.php?option=com_content&view=category&id=19', 'component', 0, 266, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_category_title":"","show_description":"","show_description_image":"","maxLevel":"","show_empty_categories":"","show_no_articles":"","show_subcat_desc":"","show_cat_num_articles":"","page_subheading":"","show_pagination_limit":"","filter_field":"","show_headings":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","orderby_pri":"","orderby_sec":"alpha","order_date":"","show_pagination":"","show_pagination_results":"","display_num":"10","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 67, 68, 0, '*', 0),
(262, 'menujoomla', 'Articles en vedette', 'articles-vedette', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu/articles-vedette', 'index.php?option=com_content&view=featured', 'component', 0, 266, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"1","orderby_pri":"","orderby_sec":"front","order_date":"","show_pagination":"2","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 69, 70, 0, '*', 0),
(263, 'menujoomla', 'Proposer un article', 'proposer-article', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu/proposer-article', 'index.php?option=com_content&view=form&layout=edit', 'component', 0, 266, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 3, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 73, 74, 0, '*', 0),
(265, 'menujoomla', 'Composant Liens web', 'composant-liens-web', '', 'utiliser-joomla/utiliser-extensions/composants/composant-liens-web', 'index.php?option=com_content&view=article&id=54', 'component', 0, 268, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 86, 93, 0, '*', 0),
(266, 'menujoomla', 'Composant Contenu', 'composant-contenu', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu', 'index.php?option=com_content&view=article&id=10', 'component', 0, 268, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"article-allow_ratings":"","article-allow_comments":"","show_category":"","link_category":"","show_title":"","link_titles":"","show_intro":"","show_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 60, 75, 0, '*', 0),
(267, 'menujoomla', 'Composant Fils d''actualité', 'composant-actualite-rss', '', 'utiliser-joomla/utiliser-extensions/composants/composant-actualite-rss', 'index.php?option=com_content&view=article&id=60', 'component', 0, 268, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":1,"page_title":"Composant Fils d''actualité ","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 94, 101, 0, '*', 0),
(268, 'menujoomla', 'Composants', 'composants', '', 'utiliser-joomla/utiliser-extensions/composants', 'index.php?option=com_content&view=category&layout=blog&id=21', 'component', 0, 277, 3, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_category_title":"","show_description":"1","show_description_image":"","maxLevel":"","show_empty_categories":"","show_subcat_desc":"","show_cat_num_articles":"","page_subheading":"","num_leading_articles":"0","num_intro_articles":"7","num_columns":"1","num_links":"0","multi_column_order":"","orderby_pri":"","orderby_sec":"order","order_date":"","show_pagination":"0","show_pagination_results":"","show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_readmore":"","show_icons":"0","show_print_icon":"0","show_email_icon":"0","show_hits":"0","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 59, 124, 0, '*', 0),
(270, 'menujoomla', 'Composant Contact', 'composant-contact', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contact', 'index.php?option=com_content&view=article&id=9', 'component', 0, 268, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 76, 85, 0, '*', 0),
(271, 'menujoomla', 'Composant Utilisateurs', 'composant-utilisateurs', '', 'utiliser-joomla/utiliser-extensions/composants/composant-utilisateurs', 'index.php?option=com_content&view=article&id=52', 'component', 0, 268, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 102, 115, 0, '*', 0),
(272, 'menujoomla', 'Liste de catégories', 'liste-categories', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contenu/liste-categories', 'index.php?option=com_content&view=categories&id=14', 'component', 0, 266, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_base_description":"","categories_description":"","maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","category_layout":"","show_headings":"","show_date":"","date_format":"","filter_field":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 63, 64, 0, '*', 0),
(273, 'menujoomla', 'Composants Administration', 'composants-administration', '', 'utiliser-joomla/utiliser-extensions/composants/composants-administration', 'index.php?option=com_content&view=article&id=1', 'component', 0, 268, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 122, 123, 0, '*', 0),
(274, 'menujoomla', 'Liens web d''une catégorie', 'liens-web-categorie', '', 'utiliser-joomla/utiliser-extensions/composants/composant-liens-web/liens-web-categorie', 'index.php?option=com_weblinks&view=category&id=32', 'component', 0, 265, 5, 21, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","orderby_pri":"","show_pagination":"","show_noauth":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 89, 90, 0, '*', 0),
(275, 'menujoomla', 'Contacts d''une catégorie', 'contacts-categorie', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contact/contacts-categorie', 'index.php?option=com_contact&view=category&catid=26&id=36', 'component', 0, 270, 5, 8, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"20","show_headings":"","filter_field":"","show_pagination":"","show_noauth":"","presentation_style":"sliders","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"1","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 79, 80, 0, '*', 0),
(276, 'menujoomla', 'Composant Recherche', 'composant-recherche', '', 'utiliser-joomla/utiliser-extensions/composants/composant-recherche', 'index.php?option=com_content&view=article&id=39', 'component', 0, 268, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 116, 121, 0, '*', 0),
(277, 'menujoomla', 'Utiliser les extensions', 'utiliser-extensions', '', 'utiliser-joomla/utiliser-extensions', 'index.php?option=com_content&view=categories&id=20', 'component', 0, 280, 2, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_base_description":"1","categories_description":"","maxLevelcat":"1","show_empty_categories_cat":"1","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"0","drill_down_layout":"0","show_category_title":"","show_description":"1","show_description_image":"1","maxLevel":"1","show_empty_categories":"1","show_subcat_desc":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_results":"","show_pagination_limit":"","filter_field":"","show_headings":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 58, 223, 0, '*', 0),
(278, 'menujoomla', 'Le "Projet Joomla!"', 'projet-joomla', '', 'projet-joomla', 'index.php?option=com_content&view=article&id=48', 'component', 0, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"1","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"1","show_print_icon":"","show_email_icon":"","show_hits":"0","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 231, 232, 0, '*', 0),
(279, 'menujoomla', 'La communauté Joomla!', 'communaute-joomla', '', 'communaute-joomla', 'index.php?option=com_content&view=article&id=47', 'component', 0, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"0","show_intro":"","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"0","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 233, 234, 0, '*', 0),
(280, 'menujoomla', 'Utiliser Joomla!', 'utiliser-joomla', '', 'utiliser-joomla', 'index.php?option=com_content&view=article&id=53', 'component', 0, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"1","link_titles":"0","show_intro":"1","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"0","show_noauth":"0","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 57, 228, 0, '*', 0),
(281, 'menujoomla', 'Modules', 'modules', '', 'utiliser-joomla/utiliser-extensions/modules', 'index.php?option=com_content&view=category&id=22', 'component', 0, 277, 3, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_category_title":"","show_description":"1","show_description_image":"1","maxLevel":"1","show_empty_categories":"1","show_no_articles":"0","show_subcat_desc":"1","show_cat_num_articles":"","page_subheading":"","show_pagination_limit":"","filter_field":"","show_headings":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","show_pagination":"","show_pagination_results":"","show_title":"1","link_titles":"","show_intro":"","show_category":"0","link_category":"0","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_vote":"","show_readmore":"0","show_icons":"0","show_print_icon":"0","show_email_icon":"0","show_hits":"0","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 125, 184, 0, '*', 0),
(282, 'menujoomla', 'Templates', 'templates', '', 'utiliser-joomla/utiliser-extensions/templates', 'index.php?option=com_content&view=category&id=23', 'component', 0, 277, 3, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_category_title":"","show_description":"1","show_description_image":"","maxLevel":"2","show_empty_categories":"1","show_no_articles":"0","show_subcat_desc":"1","show_cat_num_articles":"","page_subheading":"","show_pagination_limit":"0","filter_field":"hide","show_headings":"0","list_show_date":"0","date_format":"","list_show_hits":"0","list_show_author":"0","show_pagination":"0","show_pagination_results":"","show_title":"1","link_titles":"1","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"Templates","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 185, 204, 0, '*', 0),
(283, 'menujoomla', 'Langues', 'langues', '', 'utiliser-joomla/utiliser-extensions/langues', 'index.php?option=com_content&view=category&layout=blog&id=24', 'component', 0, 277, 3, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"1","show_description_image":"1","show_category_title":"1","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 205, 206, 0, '*', 0),
(284, 'menujoomla', 'Plug-ins', 'plugins', '', 'utiliser-joomla/utiliser-extensions/plugins', 'index.php?option=com_content&view=category&layout=blog&id=25', 'component', 0, 277, 3, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"1","show_description_image":"","show_category_title":"1","show_cat_num_articles":"","num_leading_articles":"0","num_intro_articles":"7","num_columns":"1","num_links":"0","multi_column_order":"","orderby_pri":"","orderby_sec":"order","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"0","show_parent_category":"0","link_parent_category":"0","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"","show_readmore":"","show_icons":"0","show_print_icon":"0","show_email_icon":"0","show_hits":"0","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 207, 222, 0, '*', 0),
(285, 'menujoomla', 'Typographie Atomic', 'typographie-atomic', '', 'utiliser-joomla/utiliser-extensions/templates/atomic/typographie-atomic', 'index.php?option=com_content&view=article&id=49', 'component', 0, 422, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 3, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 199, 200, 0, '*', 0),
(290, 'mainmenu', 'Articles', 'articles', '', 'site-map/articles', 'index.php?option=com_content&view=categories&id=0', 'component', 0, 294, 2, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"categories_description":"","maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","category_layout":"","show_headings":"","show_date":"","date_format":"","filter_field":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","article-allow_ratings":"","article-allow_comments":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 6, 7, 0, '*', 0),
(294, 'mainmenu', 'Plan du Site', 'site-map', '', 'site-map', 'index.php?option=com_content&view=article&id=42', 'component', 0, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"0","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 5, 12, 0, '*', 0),
(296, 'menuparcs', 'Liens des Parcs', 'park-links', '', 'park-links', 'index.php?option=com_weblinks&view=category&id=31', 'component', 1, 1, 1, 21, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 114, '{"maxLevel":"-1","show_empty_categories":"","show_description":"1","show_description_image":"1","show_cat_num_articles":"","display_num":"","show_headings":"0","orderby_pri":"","show_pagination":"","show_noauth":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 253, 254, 0, 'fr-FR', 0),
(300, 'menujoomla', 'Derniers Inscrits', 'derniers-inscrits', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilisateur/derniers-inscrits', 'index.php?option=com_content&view=article&id=66', 'component', 0, 412, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 149, 150, 0, '*', 0),
(301, 'menujoomla', 'Qui est en ligne ?', 'qui-est-en-ligne', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilisateur/qui-est-en-ligne', 'index.php?option=com_content&view=article&id=56', 'component', 0, 412, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 151, 152, 0, '*', 0);
INSERT INTO `m5jbw_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `ordering`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(302, 'menujoomla', 'Articles les plus consultés', 'articles-plus-consultes', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu/articles-plus-consultes', 'index.php?option=com_content&view=article&id=30', 'component', 0, 411, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 133, 134, 0, '*', 0),
(303, 'menujoomla', 'Menus', 'menu', '', 'utiliser-joomla/utiliser-extensions/modules/modules-navigation/menu', 'index.php?option=com_content&view=article&id=29', 'component', 0, 415, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 127, 128, 0, '*', 0),
(304, 'menujoomla', 'Statistiques', 'statistiques', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilitaires/statistiques', 'index.php?option=com_content&view=article&id=44', 'component', 0, 414, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 173, 174, 0, '*', 0),
(305, 'menujoomla', 'Bannières', 'bannieres', '', 'utiliser-joomla/utiliser-extensions/modules/modules-affichage/bannieres', 'index.php?option=com_content&view=article&id=7', 'component', 0, 413, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 159, 160, 0, '*', 0),
(306, 'menujoomla', 'Recherche', 'recherche', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilitaires/recherche', 'index.php?option=com_content&view=article&id=40', 'component', 0, 414, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 175, 176, 0, '*', 0),
(307, 'menujoomla', 'Image aléatoire', 'image-aleatoire', '', 'utiliser-joomla/utiliser-extensions/modules/modules-affichage/image-aleatoire', 'index.php?option=com_content&view=article&id=36', 'component', 0, 413, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 157, 158, 0, '*', 0),
(309, 'menujoomla', 'Flash info', 'flash-info', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu/flash-info', 'index.php?option=com_content&view=article&id=31', 'component', 0, 411, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 135, 136, 0, '*', 0),
(310, 'menujoomla', 'Derniers articles', 'derniers-articles', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu/derniers-articles', 'index.php?option=com_content&view=article&id=27', 'component', 0, 411, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 137, 138, 0, '*', 0),
(311, 'menujoomla', 'Flux RSS/ATOM', 'flux-rss-atom', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilitaires/flux-rss-atom', 'index.php?option=com_content&view=article&id=45', 'component', 0, 414, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 171, 172, 0, '*', 0),
(312, 'menujoomla', 'Identification', 'identification', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilisateur/identification', 'index.php?option=com_content&view=article&id=28', 'component', 0, 412, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 153, 154, 0, '*', 0),
(313, 'menujoomla', 'Fenêtre intégrée', 'fenetre-integree', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilitaires/fenetre-integree', 'index.php?option=com_content&view=article&id=59', 'component', 0, 414, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 179, 180, 0, '*', 0),
(316, 'menujoomla', 'Page d''accueil Atomic', 'page-accueil-atomic', '', 'utiliser-joomla/utiliser-extensions/templates/atomic/page-accueil-atomic', 'index.php?option=com_content&view=featured', 'component', 0, 422, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 3, '{"maxLevel":"","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"3","num_columns":"3","num_links":"0","multi_column_order":"1","orderby_pri":"","orderby_sec":"front","order_date":"","show_pagination":"2","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 201, 202, 0, '*', 0),
(317, 'menujoomla', 'Plug-ins Système', 'systeme', '', 'utiliser-joomla/utiliser-extensions/plugins/systeme', 'index.php?option=com_content&view=article&id=46', 'component', 0, 284, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 220, 221, 0, '*', 0),
(318, 'menujoomla', 'Plug-ins Authentification', 'authentification', '', 'utiliser-joomla/utiliser-extensions/plugins/authentification', 'index.php?option=com_content&view=article&id=5', 'component', 0, 284, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 208, 209, 0, '*', 0),
(319, 'menujoomla', 'Plug-ins Contenu', 'contenu', '', 'utiliser-joomla/utiliser-extensions/plugins/contenu', 'index.php?option=com_content&view=article&id=62', 'component', 0, 284, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 210, 211, 0, '*', 0),
(320, 'menujoomla', 'Plug-ins Éditeurs de contenu', 'editeurs-contenu', '', 'utiliser-joomla/utiliser-extensions/plugins/editeurs-contenu', 'index.php?option=com_content&view=article&id=14', 'component', 0, 284, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 212, 213, 0, '*', 0),
(321, 'menujoomla', 'Plug-ins Boutons éditeur', 'boutons-editeur', '', 'utiliser-joomla/utiliser-extensions/plugins/boutons-editeur', 'index.php?option=com_content&view=article&id=15', 'component', 0, 284, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 214, 215, 0, '*', 0),
(322, 'menujoomla', 'Plug-ins Recherche', 'recherche', '', 'utiliser-joomla/utiliser-extensions/plugins/recherche', 'index.php?option=com_content&view=article&id=41', 'component', 0, 284, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 216, 217, 0, '*', 0),
(323, 'menujoomla', 'Plug-ins Utilisateurs', 'utilisateurs', '', 'utiliser-joomla/utiliser-extensions/plugins/utilisateurs', 'index.php?option=com_content&view=article&id=51', 'component', 0, 284, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 218, 219, 0, '*', 0),
(324, 'menujoomla', 'Pied de page', 'pied-de-page', '', 'utiliser-joomla/utiliser-extensions/modules/modules-affichage/pied-de-page', 'index.php?option=com_content&view=article&id=19', 'component', 0, 413, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 163, 164, 0, '*', 0),
(325, 'menujoomla', 'Articles archivés', 'articles-archives', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu/articles-archives', 'index.php?option=com_content&view=article&id=2', 'component', 0, 411, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 139, 140, 0, '*', 0),
(326, 'menujoomla', 'Articles en relation', 'articles-relation', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu/articles-relation', 'index.php?option=com_content&view=article&id=37', 'component', 0, 411, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 141, 142, 0, '*', 0),
(399, 'menuparcs', 'Animaux', 'animals', '', 'image-gallery/animals', 'index.php?option=com_content&view=category&layout=blog&id=72', 'component', 1, 244, 2, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 114, '{"maxLevel":"","show_empty_categories":"","show_description":"1","show_description_image":"0","show_category_title":"","show_cat_num_articles":"","num_leading_articles":"0","num_intro_articles":"6","num_columns":"2","num_links":"4","multi_column_order":"1","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"2","show_noauth":"","show_title":"","link_titles":"","show_intro":"0","show_category":"1","link_category":"1","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"1","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 248, 249, 0, 'fr-FR', 0),
(400, 'menuparcs', 'Paysages', 'scenery', '', 'image-gallery/scenery', 'index.php?option=com_content&view=category&layout=blog&id=73', 'component', 1, 244, 2, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 114, '{"maxLevel":"","show_empty_categories":"","show_description":"0","show_description_image":"0","show_category_title":"","show_cat_num_articles":"","num_leading_articles":"0","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"1","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"2","show_noauth":"","show_title":"","link_titles":"","show_intro":"0","show_category":"1","link_category":"","show_parent_category":"0","link_parent_category":"0","show_author":"0","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"1","show_readmore":"1","show_icons":"0","show_print_icon":"0","show_email_icon":"0","show_hits":"0","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 250, 251, 0, 'fr-FR', 0),
(402, 'menujoomla', 'Formulaire d''identification', 'formulaire-identification', '', 'utiliser-joomla/utiliser-extensions/composants/composant-utilisateurs/formulaire-identification', 'index.php?option=com_users&view=login', 'component', 0, 271, 5, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"login_redirect_url":"","logindescription_show":"1","login_description":"","login_image":"","logout_redirect_url":"","logoutdescription_show":"1","logout_description":"","logout_image":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 103, 104, 0, '*', 0),
(403, 'menujoomla', 'Profil utilisateur', 'profil-utilisateur', '', 'utiliser-joomla/utiliser-extensions/composants/composant-utilisateurs/profil-utilisateur', 'index.php?option=com_users&view=profile', 'component', 0, 271, 5, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 105, 106, 0, '*', 0),
(404, 'menujoomla', 'Modifier le Profil', 'modifier-profil', '', 'utiliser-joomla/utiliser-extensions/composants/composant-utilisateurs/modifier-profil', 'index.php?option=com_users&view=profile&layout=edit', 'component', 0, 271, 5, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 107, 108, 0, '*', 0),
(405, 'menujoomla', 'Formulaire Création de compte', 'formulaire-creation-compte', '', 'utiliser-joomla/utiliser-extensions/composants/composant-utilisateurs/formulaire-creation-compte', 'index.php?option=com_users&view=registration', 'component', 0, 271, 5, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 109, 110, 0, '*', 0),
(406, 'menujoomla', 'Rappel de l''identifiant', 'rappel-identifiant', '', 'utiliser-joomla/utiliser-extensions/composants/composant-utilisateurs/rappel-identifiant', 'index.php?option=com_users&view=remind', 'component', 0, 271, 5, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 111, 112, 0, '*', 0),
(409, 'menujoomla', 'Réinitialisation du mot de passe', 'reinitialisation-mot-de-passe', '', 'utiliser-joomla/utiliser-extensions/composants/composant-utilisateurs/reinitialisation-mot-de-passe', 'index.php?option=com_users&view=reset', 'component', 0, 271, 5, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 113, 114, 0, '*', 0),
(410, 'menujoomla', 'Fil d''actualité', 'flux-rss', '', 'utiliser-joomla/utiliser-extensions/modules/modules-affichage/flux-rss', 'index.php?option=com_content&view=article&id=16', 'component', 0, 413, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 161, 162, 0, '*', 0),
(411, 'menujoomla', 'Modules Contenu', 'modules-contenu', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu', 'index.php?option=com_content&view=category&id=64', 'component', 0, 281, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"0","show_category_title":"1","page_subheading":"","show_empty_categories":"1","show_description":"1","show_description_image":"","show_cat_num_articles":"","display_num":"0","show_headings":"0","list_show_title":"1","list_show_date":"0","date_format":"","list_show_hits":"0","list_show_author":"0","filter_field":"hide","orderby_pri":"","orderby_sec":"order","order_date":"","show_pagination":"","show_pagination_limit":"0","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"1","link_category":"1","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 132, 147, 0, '*', 0),
(412, 'menujoomla', 'Modules Utilisateur', 'modules-utilisateur', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilisateur', 'index.php?option=com_content&view=category&id=65', 'component', 0, 281, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"0","show_category_title":"1","page_subheading":"","show_empty_categories":"","show_description":"1","show_description_image":"","show_cat_num_articles":"","display_num":"0","show_headings":"0","list_show_title":"1","list_show_date":"","date_format":"","list_show_hits":"0","list_show_author":"0","filter_field":"hide","orderby_pri":"","orderby_sec":"order","order_date":"","show_pagination":"","show_pagination_limit":"0","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"1","link_category":"1","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 148, 155, 0, '*', 0),
(413, 'menujoomla', 'Modules Affichage', 'modules-affichage', '', 'utiliser-joomla/utiliser-extensions/modules/modules-affichage', 'index.php?option=com_content&view=category&id=66', 'component', 0, 281, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"0","show_category_title":"1","page_subheading":"","show_empty_categories":"","show_description":"1","show_description_image":"1","show_cat_num_articles":"","display_num":"0","show_headings":"0","list_show_title":"1","list_show_date":"","date_format":"","list_show_hits":"0","list_show_author":"0","filter_field":"hide","orderby_pri":"","orderby_sec":"order","order_date":"","show_pagination":"","show_pagination_limit":"0","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"1","link_category":"1","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 156, 169, 0, '*', 0),
(414, 'menujoomla', 'Modules Utilitaire', 'modules-utilitaires', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilitaires', 'index.php?option=com_content&view=category&id=67', 'component', 0, 281, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"0","show_category_title":"1","page_subheading":"","show_empty_categories":"","show_description":"1","show_description_image":"1","show_cat_num_articles":"","display_num":"0","show_headings":"0","list_show_title":"0","list_show_date":"0","date_format":"","list_show_hits":"0","list_show_author":"0","filter_field":"","orderby_pri":"","orderby_sec":"order","order_date":"","show_pagination":"","show_pagination_limit":"0","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"1","link_category":"1","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 170, 183, 0, '*', 0),
(415, 'menujoomla', 'Modules Navigation ', 'modules-navigation', '', 'utiliser-joomla/utiliser-extensions/modules/modules-navigation', 'index.php?option=com_content&view=category&id=75', 'component', 0, 281, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_category_title":"","page_subheading":"","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","list_show_title":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","filter_field":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_limit":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 126, 131, 0, '*', 0),
(416, 'menujoomla', 'Fil de navigation', 'fil-navigation', '', 'utiliser-joomla/utiliser-extensions/modules/modules-navigation/fil-navigation', 'index.php?option=com_content&view=article&id=61', 'component', 0, 415, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 129, 130, 0, '*', 0),
(417, 'menujoomla', 'Liens web', 'liens-web', '', 'utiliser-joomla/utiliser-extensions/modules/modules-affichage/liens-web', 'index.php?option=com_content&view=article&id=55', 'component', 0, 413, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 165, 166, 0, '*', 0),
(418, 'menujoomla', 'HTML personnalisé', 'html-personnalise', '', 'utiliser-joomla/utiliser-extensions/modules/modules-affichage/html-personnalise', 'index.php?option=com_content&view=article&id=12', 'component', 0, 413, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 167, 168, 0, '*', 0),
(419, 'menujoomla', 'Beez 2', 'beez-2', '', 'utiliser-joomla/utiliser-extensions/templates/beez-2', 'index.php?option=com_content&view=category&layout=blog&id=69', 'component', 0, 282, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"1","show_description_image":"","show_category_title":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 186, 191, 0, '*', 0),
(422, 'menujoomla', 'Atomic', 'atomic', '', 'utiliser-joomla/utiliser-extensions/templates/atomic', 'index.php?option=com_content&view=category&layout=blog&id=68', 'component', 0, 282, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"1","show_description_image":"","show_category_title":"","show_cat_num_articles":"","num_leading_articles":"2","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 198, 203, 0, '*', 0),
(423, 'menujoomla', 'Typographie Beez 2', 'typographie-beez-2', '', 'utiliser-joomla/utiliser-extensions/templates/beez-2/typographie-beez-2', 'index.php?option=com_content&view=article&id=49', 'component', 0, 419, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 4, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 187, 188, 0, '*', 0),
(424, 'menujoomla', 'Page d''accueil Beez 2', 'page-accueil-beez-2', '', 'utiliser-joomla/utiliser-extensions/templates/beez-2/page-accueil-beez-2', 'index.php?option=com_content&view=featured', 'component', 0, 419, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 4, '{"maxLevel":"","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"3","num_columns":"3","num_links":"0","multi_column_order":"1","orderby_pri":"","orderby_sec":"front","order_date":"","show_pagination":"2","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 189, 190, 0, '*', 0),
(427, 'menuboutique', 'Encyclopédie des fruits', 'encyclopedie-fruits', '', 'encyclopedie-fruits', 'index.php?option=com_contact&view=categories&id=37', 'component', 1, 1, 1, 8, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"show_base_description":"1","categories_description":"","maxLevelcat":"","show_empty_categories_cat":"","show_subcat_desc_cat":"","show_cat_items_cat":"","show_category_title":"","show_description":"1","show_description_image":"1","maxLevel":"-1","show_empty_categories":"1","show_subcat_desc":"","show_cat_items":"","show_pagination_limit":"","show_headings":"0","show_position_headings":"","show_email_headings":"0","show_telephone_headings":"0","show_mobile_headings":"0","show_fax_headings":"0","show_suburb_headings":"0","show_state_headings":"","show_country_headings":"","show_pagination":"","show_pagination_results":"","presentation_style":"","show_contact_category":"","show_contact_list":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"1","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","show_feed_link":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":" categories-listalphabet","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 257, 258, 0, '*', 0),
(429, 'menuboutique', 'Bienvenue', 'bienvenue-boutique', 'Page d''accueil de la boutique', 'bienvenue-boutique', 'index.php?option=com_content&view=article&id=20', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"show_noauth":"","show_title":"0","link_titles":"0","show_intro":"1","show_category":"0","link_category":"0","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"0","show_print_icon":"0","show_email_icon":"0","show_hits":"0","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 255, 256, 0, '*', 0),
(430, 'menuboutique', 'Contactez-nous', 'contactez-nous', '', 'contactez-nous', 'index.php?option=com_contact&view=category&catid=47&id=36', 'component', 1, 1, 1, 8, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"20","show_headings":"0","filter_field":"hide","show_pagination":"","show_noauth":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"1","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 261, 262, 0, '*', 0),
(431, 'menuboutique', 'Producteurs', 'producteurs', '', 'producteurs', 'index.php?option=com_content&view=category&layout=blog&id=30', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"maxLevel":"0","show_empty_categories":"","show_description":"1","show_description_image":"","show_category_title":"1","show_cat_num_articles":"","num_leading_articles":"5","num_intro_articles":"0","num_columns":"1","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"alpha","order_date":"","show_pagination":"","show_noauth":"","show_title":"1","link_titles":"1","show_intro":"1","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"0","show_author":"0","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"0","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"0","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 259, 260, 0, '*', 0),
(432, 'menuboutique', 'Identification', 'identification-boutique', '', 'identification-boutique', 'index.php?option=com_users&view=login', 'component', 1, 1, 1, 25, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"login_redirect_url":"","logindescription_show":"1","login_description":"","login_image":"","logout_redirect_url":"","logoutdescription_show":"1","logout_description":"","logout_image":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 263, 264, 0, '*', 0),
(433, 'menuboutique', 'Venir à la boutique', 'venir-boutique', '', 'venir-boutique', 'index.php?option=com_content&view=article&id=13', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 265, 266, 0, '*', 0),
(435, 'mainmenu', 'Accueil', 'homepage', '', 'homepage', 'index.php?option=com_content&view=featured', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"featured_categories":[""],"num_leading_articles":"1","num_intro_articles":"3","num_columns":"3","num_links":"0","multi_column_order":"1","orderby_pri":"","orderby_sec":"front","order_date":"","show_pagination":"2","show_pagination_results":"","show_title":"1","link_titles":"","show_intro":"","show_category":"0","link_category":"0","show_parent_category":"0","link_parent_category":"0","show_author":"0","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_vote":"","show_readmore":"1","show_readmore_title":"","show_icons":"0","show_print_icon":"0","show_email_icon":"0","show_hits":"0","show_noauth":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 3, 4, 1, '*', 0),
(436, 'menujoomla', 'Obtenir de l''aide', 'obtenir-aide', '', 'utiliser-joomla/obtenir-aide', 'index.php?option=com_content&view=article&id=21', 'component', 0, 280, 2, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"0","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 226, 227, 0, '*', 0),
(437, 'menujoomla', 'Comment démarrer ?', 'comment-demarrer', '', 'comment-demarrer', 'index.php?option=com_content&view=article&id=22', 'component', 0, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"1","link_titles":"0","show_intro":"","show_category":"0","link_category":"","show_parent_category":"0","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"0","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"0","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 47, 48, 0, '*', 0),
(438, 'mainmenu', 'Liens Web', 'weblinks', '', 'site-map/weblinks', 'index.php?option=com_weblinks&view=categories&id=0', 'component', 0, 294, 2, 21, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"categories_description":"","maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","orderby_pri":"","show_pagination":"","show_noauth":"","article-allow_ratings":"","article-allow_comments":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 8, 9, 0, '*', 0);
INSERT INTO `m5jbw_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `ordering`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(439, 'mainmenu', 'Contacts', 'contacts', '', 'site-map/contacts', 'index.php?option=com_contact&view=categories&id=0', 'component', 0, 294, 2, 8, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"categories_description":"","maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","filter_field":"","show_pagination":"","show_noauth":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"1","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","article-allow_ratings":"","article-allow_comments":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 10, 11, 0, '*', 0),
(443, 'menujoomla', 'Liste de catégories', 'liste-categories', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu/liste-categories', 'index.php?option=com_content&view=article&id=3', 'component', 0, 411, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 143, 144, 0, '*', 0),
(444, 'menuhaut', 'Sites exemples', 'sites-exemples', '', 'sites-exemples', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"238","menu-anchor_title":"","menu-anchor_css":"","menu_image":""}', 235, 236, 0, '*', 0),
(445, 'mainmenu', 'Parcs', 'parks', '', 'sample-sites/parks', 'index.php?Itemid=', 'alias', 0, 238, 2, 0, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"243","menu-anchor_title":"","menu-anchor_css":"","menu_image":""}', 268, 269, 0, '*', 0),
(446, 'mainmenu', 'Boutique', 'shop', '', 'sample-sites/shop', 'index.php?Itemid=', 'alias', 0, 238, 2, 0, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"429","menu-anchor_title":"","menu-anchor_css":"","menu_image":""}', 270, 271, 0, '*', 0),
(447, 'menujoomla', 'Sélecteur de langue', 'selecteur-langue', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilitaires/selecteur-langue', 'index.php?option=com_content&view=article&id=26', 'component', 0, 414, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 177, 178, 0, '*', 0),
(448, 'mainmenu', 'Administration du site', 'site-administrator', '', 'site-administrator', 'administrator', 'url', 1, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 1, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":""}', 273, 274, 0, '*', 0),
(449, 'menumembre', 'Proposer un article', 'proposer-article', '', 'proposer-article', 'index.php?option=com_content&view=form&layout=edit', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 3, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 275, 276, 0, '*', 0),
(450, 'menumembre', 'Proposer un lien web', 'proposer-lien-web', '', 'proposer-lien-web', 'index.php?option=com_weblinks&view=form&layout=edit', 'component', 1, 1, 1, 21, 0, 0, '0000-00-00 00:00:00', 0, 3, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 277, 278, 0, '*', 0),
(452, 'menujoomla', 'Contacts préférés', 'contacts-preferes', '', 'utiliser-joomla/utiliser-extensions/composants/composant-contact/contacts-preferes', 'index.php?option=com_contact&view=featured&id=16', 'component', 0, 270, 5, 8, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"-1","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","filter_field":"","show_pagination":"","show_noauth":"","presentation_style":"sliders","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"1","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":1,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 83, 84, 0, '*', 0),
(453, 'menujoomla', 'Paramètres', 'parametres', '', 'utiliser-joomla/parametres', 'index.php?option=com_content&view=article&id=32', 'component', 0, 280, 2, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"1","show_title":"1","link_titles":"1","show_intro":"1","show_category":"1","link_category":"1","show_parent_category":"1","link_parent_category":"1","show_author":"1","link_author":"1","show_create_date":"1","show_modify_date":"1","show_publish_date":"1","show_item_navigation":"1","show_icons":"1","show_print_icon":"1","show_email_icon":"1","show_hits":"1","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 224, 225, 0, '*', 0),
(455, 'mainmenu', 'Page exemple', 'exemple-page', '', 'exemple-page', 'index.php?Itemid=', 'alias', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"268","menu-anchor_title":"","menu-anchor_css":"","menu_image":""}', 279, 280, 0, '*', 0),
(456, 'menujoomla', 'Beez 5', 'beez5', '', 'utiliser-joomla/utiliser-extensions/templates/beez5', 'index.php?option=com_content&view=category&layout=blog&id=70', 'component', 0, 282, 4, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"1","show_description_image":"","show_category_title":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":1,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 192, 197, 0, '*', 0),
(457, 'menujoomla', 'Typographie Beez 5', 'typographie-beez5', '', 'utiliser-joomla/utiliser-extensions/templates/beez5/typographie-beez5', 'index.php?option=com_content&view=article&id=49', 'component', 0, 456, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":1,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 193, 194, 0, '*', 0),
(458, 'menujoomla', 'Page d''accueil Beez-5', 'page-accueil-beez5', '', 'utiliser-joomla/utiliser-extensions/templates/beez5/page-accueil-beez5', 'index.php?option=com_content&view=featured', 'component', 0, 456, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"maxLevel":"","show_empty_categories":"","show_description":"","show_description_image":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"3","num_columns":"3","num_links":"0","multi_column_order":"","orderby_pri":"","orderby_sec":"front","order_date":"","show_pagination":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":1,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 195, 196, 0, '*', 0),
(459, 'menujoomla', 'Articles d''une catégorie', 'articles-categorie', '', 'utiliser-joomla/utiliser-extensions/modules/modules-contenu/articles-categorie', 'index.php?option=com_content&view=article&id=4', 'component', 0, 411, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","robots":"","rights":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":1,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","secure":0}', 145, 146, 0, '*', 0),
(462, 'menuboutique', 'Proposer une recette', 'proposer-recette', '', 'proposer-recette', 'index.php?option=com_content&view=form&layout=edit', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 4, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":1,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 281, 282, 0, '*', 0),
(463, 'menuboutique', 'Recettes', 'recettes', '', 'recettes', 'index.php?option=com_content&view=category&id=76', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 6, '{"maxLevel":"0","show_category_title":"1","page_subheading":"","show_empty_categories":"0","show_description":"1","show_description_image":"","show_cat_num_articles":"","display_num":"","show_headings":"","list_show_title":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","filter_field":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_limit":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_readmore":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","show_page_heading":0,"page_title":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 283, 284, 0, '*', 0),
(464, 'menuhaut', 'Accueil', 'accueil', '', 'accueil', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"435","menu-anchor_title":"","menu-anchor_css":"","menu_image":""}', 229, 230, 0, '*', 0),
(465, 'menuhaut', 'Joomla.fr', 'joomla-fr', '', 'joomla-fr', 'http://www.joomla.fr', 'url', 1, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 1, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 285, 286, 0, '*', 0),
(466, 'menujoomla', 'Recherche avancée', 'recherche-avance', '', 'utiliser-joomla/utiliser-extensions/composants/composant-recherche/recherche-avance', 'index.php?option=com_finder&view=search&q=&f=', 'component', 0, 276, 5, 27, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_date_filters":"","show_advanced":"","expand_advanced":"","show_description":"","description_length":255,"show_url":"","show_pagination_limit":"","show_pagination":"","show_pagination_results":"","allow_empty_query":"0","search_order":"","show_feed":"0","show_feed_text":"0","show_feed_link":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 119, 120, 0, '*', 0),
(467, 'menujoomla', 'Recherche avancée', 'recherche-avance', '', 'utiliser-joomla/utiliser-extensions/modules/modules-utilitaires/recherche-avance', 'index.php?option=com_content&view=article&id=70', 'component', 0, 414, 5, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 181, 182, 0, '*', 0),
(468, 'main', 'COM_MEDIAMALLFACTORY_COMPONENT_TITLE', 'com-mediamallfactory-component-title', '', 'com-mediamallfactory-component-title', 'index.php?option=com_mediamallfactory', 'component', 0, 1, 1, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 287, 304, 0, '', 1),
(469, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_LIST', 'com-briefcasefactory-component-menu-list', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-list', 'index.php?option=com_mediamallfactory&view=list', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 288, 289, 0, '', 1),
(470, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_USERS', 'com-briefcasefactory-component-menu-users', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-users', 'index.php?option=com_mediamallfactory&view=users', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 290, 291, 0, '', 1),
(471, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_ORDERS', 'com-briefcasefactory-component-menu-orders', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-orders', 'index.php?option=com_mediamallfactory&view=orders', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 292, 293, 0, '', 1),
(472, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_PAYMENTS', 'com-briefcasefactory-component-menu-payments', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-payments', 'index.php?option=com_mediamallfactory&view=payments', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 294, 295, 0, '', 1),
(473, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_INVOICES', 'com-briefcasefactory-component-menu-invoices', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-invoices', 'index.php?option=com_mediamallfactory&view=invoices', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 296, 297, 0, '', 1),
(474, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_REQUESTS', 'com-briefcasefactory-component-menu-requests', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-requests', 'index.php?option=com_mediamallfactory&view=requests', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 298, 299, 0, '', 1),
(475, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_SETTINGS', 'com-briefcasefactory-component-menu-settings', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-settings', 'index.php?option=com_mediamallfactory&view=configuration', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 300, 301, 0, '', 1),
(476, 'main', 'COM_BRIEFCASEFACTORY_COMPONENT_MENU_ABOUT', 'com-briefcasefactory-component-menu-about', '', 'com-mediamallfactory-component-title/com-briefcasefactory-component-menu-about', 'index.php?option=com_mediamallfactory&view=about', 'component', 0, 468, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 302, 303, 0, '', 1),
(477, 'kochk', 'Categories', 'categorie', '', 'categorie', 'index.php?option=com_mediamallfactory&view=categories&category_id=0', 'component', 1, 1, 1, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 309, 310, 0, '*', 0),
(479, 'menumembre', 'My Profile', 'my-profile', '', 'my-profile', 'index.php?option=com_mediamallfactory&view=profile', 'component', 1, 1, 1, 10000, 0, 0, '0000-00-00 00:00:00', 0, 2, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 305, 306, 0, '*', 0),
(478, 'kochk', 'medialist', 'medialist', '', 'medialist', 'index.php?option=com_mediamallfactory&view=list&filter[sort]=&filter[dir]=&filter[category]=0', 'component', 1, 1, 1, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 311, 312, 0, '*', 0),
(480, 'kochk', 'Achat crédits', 'achat-credits', '', 'achat-credits', 'index.php?option=com_mediamallfactory&view=purchasecredits', 'component', 1, 1, 1, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 307, 308, 0, '*', 0),
(481, 'main', 'Ajaxdemo', 'ajaxdemo', '', 'ajaxdemo', 'index.php?option=com_ajaxdemo', 'component', 0, 1, 1, 10007, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 313, 316, 0, '', 1),
(482, 'main', 'Ajaxdemo', 'ajaxdemo', '', 'ajaxdemo/ajaxdemo', 'index.php?option=com_ajaxdemo&view=ajaxdemo', 'component', 0, 481, 2, 10007, 0, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 314, 315, 0, '', 1),
(483, 'mainmenu', 'Ajax', 'ajax', '', 'ajax', 'index.php?option=com_ajaxdemo&view=colours', 'component', 1, 1, 1, 10007, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 317, 318, 0, '*', 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_menu_types`
--

DROP TABLE IF EXISTS `m5jbw_menu_types`;
CREATE TABLE IF NOT EXISTS `m5jbw_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `m5jbw_menu_types`
--

INSERT INTO `m5jbw_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(2, 'menumembre', 'Menu Membre', 'Menu pour les utilisateurs connectés'),
(3, 'menuhaut', 'Menu Haut', 'Liens pour la plupart des utilisateurs'),
(4, 'menujoomla', 'A propos de Joomla', 'Tout Joomla!'),
(5, 'menuparcs', 'Parcs Australiens', 'Menu du site des Parcs australiens'),
(6, 'mainmenu', 'Menu Principal', 'Menu principal du site'),
(7, 'menuboutique', 'Boutique de fruits', 'Menu du site exemple de boutique'),
(8, 'kochk', 'Kochk', '');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_messages`
--

DROP TABLE IF EXISTS `m5jbw_messages`;
CREATE TABLE IF NOT EXISTS `m5jbw_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_messages`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_messages_cfg`
--

DROP TABLE IF EXISTS `m5jbw_messages_cfg`;
CREATE TABLE IF NOT EXISTS `m5jbw_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_messages_cfg`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_modules`
--

DROP TABLE IF EXISTS `m5jbw_modules`;
CREATE TABLE IF NOT EXISTS `m5jbw_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=89 ;

--
-- Contenu de la table `m5jbw_modules`
--

INSERT INTO `m5jbw_modules` (`id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(1, 'Menu principal', '', '', 1, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","startLevel":"0","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"","moduleclass_sfx":"_menu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(2, 'Identification', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 'Articles populaires', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(4, 'Articles les plus récents', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(8, 'Barre d''outils', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 'Icônes de raccourcis', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 'Utilisateurs connectés', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(12, 'Menu principal', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","shownew":"1","showhelp":"1","forum_url":"http:\\/\\/forum.joomla.fr","cache":"0"}', 1, '*'),
(13, 'Sous-menu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 'Statut utilisateurs', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 'Titre', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(16, 'Connexion', '', '', 7, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"pretext":"","posttext":"","login":"","logout":"","greeting":"1","name":"0","usesecure":"0","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(17, 'Fil de navigation', '', '', 1, 'position-2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"moduleclass_sfx":"","showHome":"1","homeText":"Accueil","showComponent":"1","separator":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(79, 'Statut multilangue', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(86, 'Version Joomla', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(18, 'Bannières', '', '', 1, 'position-10', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_banners', 1, 0, '{"target":"1","count":"1","cid":"3","catid":[""],"tag_search":"0","ordering":"0","header_text":"","footer_text":"Livres Joomla! (en)","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, '*'),
(19, 'Menu Membre', '', '', 3, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 2, 1, '{"menutype":"menumembre","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"_menu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(20, 'Menu Haut', '', '', 1, 'position-1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"menuhaut","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","maxdepth":"10","window_open":"","layout":"","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(22, 'Parcs australiens', '', '', 2, 'position-5', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"menuparcs","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, 'fr-FR'),
(23, 'A propos de Joomla!', '', '', 4, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"menujoomla","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"","moduleclass_sfx":"_menu","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(68, 'Site des Parcs australiens', '', '<p style="text-align: justify;">Le site exemple des Parcs est conçu comme un site simple qui peut être  mis à jour régulièrement à partir de l''interface frontale de Joomla!.<br /> <br />Sur ce site, l''affichage est essentiellement axé sur un blog qui peut  être facilement mis à jour en utilisant la soumission frontale  d''article.<br /> <br />De nouveaux liens web peuvent également être soumis depuis l''interface frontale.<br /> <br />Une galerie d''images simple est proposée utilisant le composant  com_content (gestion des articles). Les vignettes sont affichées en tant  que texte d''introduction dans une mise en page de type blog, et les  images en taille réelle dans l''article affiché sans l''introduction.<br /> <br />Ce site utilise les fonctionnalités pour un affichage multilingue grâce  au sélecteur de langue. Tout le contenu et les modules sont associés au français (fr-FR). Si un pack de langue tiers est installé avec les données exemples traduites (le cas dans cet exemple en français), vous  pouvez choisir la langue d''affichage.<br /> <br />Ce site utilise le standard HTML5 qui est un le nouveau format web majeur, avec XHTML qui est utilisé pour certains contenus des données exemple.</p>', 2, 'position-4', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(67, 'Extensions', '', '', 2, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_menu', 1, 1, '{"menutype":"menujoomla","startLevel":"1","endLevel":"6","showAllChildren":"0","tag_id":"","class_sfx":"-menu","window_open":"","layout":"","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(25, 'Plan du site', '', '', 1, 'sitemapload', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{"menutype":"mainmenu","startLevel":"2","endLevel":"3","showAllChildren":"1","tag_id":"","class_sfx":"sitemap","window_open":"","layout":"","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(26, 'Ce site', '', '', 5, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","startLevel":"1","endLevel":"1","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"","moduleclass_sfx":"_menu","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(27, 'Articles archivés', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_archive', 1, 1, '{"count":"10","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(28, 'Derniers articles', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_latest', 1, 1, '{"catid":["19"],"count":"5","show_featured":"","ordering":"c_dsc","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(29, 'Articles les plus consultés', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_popular', 1, 1, '{"catid":["26","29"],"count":"5","show_front":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(30, 'Fil d''actualité', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_feed', 1, 1, '{"rssurl":"http:\\/\\/community.joomla.org\\/blogs\\/community.feed?type=rss","rssrtl":"0","rsstitle":"1","rssdesc":"1","rssimage":"1","rssitems":"3","rssitemdesc":"1","word_count":"0","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, '*'),
(31, 'Flash info', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_news', 1, 1, '{"catid":["19"],"image":"0","item_title":"0","link_titles":"","item_heading":"h4","showLastSeparator":"1","readmore":"1","count":"1","ordering":"a.publish_up","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(33, 'Image aléatoire', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_random_image', 1, 1, '{"type":"jpg","folder":"images\\/sampledata\\/parks\\/animals","link":"","width":"180","height":"","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(34, 'Articles en relation', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_related_items', 1, 1, '{"showDate":"0","layout":"_:default","moduleclass_sfx":"","owncache":"1"}', 0, '*'),
(35, 'Recherche', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_search', 1, 1, '{"label":"","width":"20","text":"","button":"","button_pos":"right","imagebutton":"","button_text":"","opensearch":"1","opensearch_title":"","set_itemid":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(36, 'Statistiques', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_stats', 1, 1, '{"serverinfo":"1","siteinfo":"1","counter":"1","increase":"0","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(37, 'Flux d''actualité', '', '', 1, 'syndicateload', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_syndicate', 1, 1, '{"text":"Flux RSS","format":"rss","layout":"","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(38, 'Derniers Inscrits', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_users_latest', 1, 1, '{"shownumber":"5","linknames":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"static"}', 0, '*'),
(39, 'Qui est en ligne', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_whosonline', 1, 1, '{"showmode":"2","linknames":"0","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(40, 'Fenêtre intégrée', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_wrapper', 1, 1, '{"url":"http:\\/\\/www.youtube.com\\/embed\\/vb2eObvmvdI","add":"1","scrolling":"auto","width":"640","height":"390","height_auto":"1","target":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(41, 'Pied de page', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_footer', 1, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(44, 'Identification', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"pretext":"","posttext":"","login":"280","logout":"280","greeting":"1","name":"0","usesecure":"0","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(45, 'Menu', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(47, 'Parcs - Derniers articles', '', '', 6, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_latest', 1, 1, '{"count":"5","ordering":"c_dsc","user_id":"0","show_front":"1","catid":"35","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, 'fr-FR'),
(48, 'HTML personnalisé', '', '<p>Ceci est un module HTML personnalisé, ce qui veut dire que vous pouvez y saisir le contenu que vous souhaitez.</p>', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(49, 'Liens web', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_weblinks', 1, 1, '{"catid":"32","count":"5","ordering":"title","direction":"asc","target":"3","description":"0","hits":"0","count_clicks":"0","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(52, 'Fil de navigation', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"showHere":"1","showHome":"1","homeText":"Accueil","showLast":"1","separator":"","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(61, 'Liste de catégories', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_categories', 1, 1, '{"parent":"29","show_description":"0","show_children":"0","count":"0","maxlevel":"0","layout":"_:default","item_heading":"4","moduleclass_sfx":"","owncache":"1","cache_time":"900"}', 0, '*'),
(56, 'Bannières', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_banners', 1, 1, '{"target":"1","count":"1","cid":"1","catid":["15"],"tag_search":"0","ordering":"random","header_text":"","footer_text":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, '*'),
(57, 'Boutique de fruits', '', '', 3, 'position-5', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"menuboutique","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(58, 'Promotion !', '', '<h1>Promotion cette semaine : remise de 50% sur de délicieuses oranges !</h1><div>Uniquement pour nos clients !</div><div>Saisissez le code : Joomla! lors de la commande</div><p><em>Ce module n''est visible que pour les clients ou membres à statut plus élevé.</em></p>', 1, 'position-12', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 4, 1, '{"prepare_content":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(62, 'Sélecteur de langue', '', '', 3, 'position-4', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_languages', 1, 1, '{"header_text":"","footer_text":"","image":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(63, 'Module de Recherche', '', '', 1, 'position-0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_search', 1, 1, '{"width":"20","text":"","button":"","button_pos":"right","imagebutton":"1","button_text":"","set_itemid":"","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(64, 'Sélecteur de langue', '', '', 1, 'languageswitcherload', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_languages', 1, 1, '{"header_text":"","footer_text":"","image":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(65, 'Site Boutique de fruits', '', '<p style="text-align: justify;">La Boutique de fruits utilise de nombreuses fonctionnalités Joomla!</p><p style="text-align: justify;">Le template utilise des classe CSS pour  modifier l''aspect des contenus tel par exemple la liste alphabétique horizontale de l''Encyclopédie des fruits.</p>', 1, 'position-4', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(69, 'Articles d''une catégorie', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_category', 1, 1, '{"mode":"normal","show_on_article_page":"1","show_front":"show","count":"0","category_filtering_type":"1","catid":["72"],"show_child_category_articles":"0","levels":"1","author_filtering_type":"1","created_by":[""],"author_alias_filtering_type":"1","created_by_alias":[""],"excluded_articles":"","date_filtering":"off","date_field":"a.created","start_date_range":"","end_date_range":"","relative_date":"30","article_ordering":"a.title","article_ordering_direction":"ASC","article_grouping":"none","article_grouping_direction":"ksort","month_year_format":"F Y","item_heading":"4","link_titles":"1","show_date":"0","show_date_field":"created","show_date_format":"Y-m-d H:i:s","show_category":"0","show_hits":"0","show_author":"0","show_introtext":"0","introtext_limit":"100","show_readmore":"0","show_readmore_title":"1","readmore_limit":"15","layout":"_:default","moduleclass_sfx":"","owncache":"1","cache_time":"900"}', 0, '*'),
(70, 'Recherche (Atomic Template)', '', '', 1, 'atomic-search', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_search', 1, 0, '{"width":"20","text":"","button":"","button_pos":"right","imagebutton":"","button_text":"","set_itemid":"","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(71, 'Menu Haut (Atomic Template)', '', '', 1, 'atomic-topmenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{"menutype":"menujoomla","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(72, 'Citation d''entête (Atomic Template)', '', '<hr /><h2>Un système de gestion de contenu accessible à tous sur un Framework extensible.</h2><hr />', 1, 'atomic-topquote', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(73, 'Colonne gauche du pied de page (Atomic Template)', '', '<h6>Ce contenu est une colonne imbriquée</h6>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>', 1, 'atomic-bottomleft', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(74, 'Colonne centrale du pied de page (Atomic Template)', '', '<h6>Ce contenu est une autre colonne imbriquée</h6>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>', 1, 'atomic-bottommiddle', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(75, 'Barre latérale (Atomic Template)', '', '<h3>A <span class="alt">Simple</span> Sidebar</h3>\r\n<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue.</p>\r\n<p class="quiet">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue.</p>\r\n<h5>Incremental leading</h5>\r\n<p class="incr">Vestibulum ante ipsum primis in faucibus orci luctus vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. sed aliquet vehicula, lectus tellus.</p>\r\n<p class="incr">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue.</p>', 1, 'atomic-sidebar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","layout":"","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(76, 'Identification (Atomic Template)', '', '', 2, 'atomic-sidebar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 0, '{"pretext":"","posttext":"","login":"","logout":"","greeting":"1","name":"0","usesecure":"0","layout":"","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(77, 'Boutique', '', '', 1, 'position-11', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_banners', 1, 0, '{"target":"1","count":"1","cid":"2","catid":["15"],"tag_search":"0","ordering":"0","header_text":"","footer_text":"Boutique Joomla!","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, '*'),
(78, 'Contribuer', '', '', 1, 'position-9', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_banners', 1, 0, '{"target":"1","count":"1","cid":"1","catid":["15"],"tag_search":"0","ordering":"0","header_text":"","footer_text":"Contribution & Dons ","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, '*'),
(84, 'Module Recherche avancée', '', '', 2, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_finder', 1, 1, '{"searchfilter":"","show_autosuggest":"1","show_advanced":"0","layout":"_:default","moduleclass_sfx":"","field_size":20,"alt_label":"","show_label":"0","label_pos":"top","show_button":"0","button_pos":"right","opensearch":"1","opensearch_title":""}', 0, '*'),
(87, 'mod_mediamallfactory', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_mediamallfactory', 1, 1, '{"mode":"latest","cost":"","limit":"5","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(88, 'Kochk', '', '', 1, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"kochk","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_modules_menu`
--

DROP TABLE IF EXISTS `m5jbw_modules_menu`;
CREATE TABLE IF NOT EXISTS `m5jbw_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_modules_menu`
--

INSERT INTO `m5jbw_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 101),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 201),
(16, 233),
(16, 435),
(16, 449),
(16, 450),
(16, 477),
(16, 478),
(16, 479),
(16, 480),
(17, 0),
(18, 0),
(19, -463),
(19, -462),
(19, -433),
(19, -432),
(19, -431),
(19, -430),
(19, -429),
(19, -427),
(19, -400),
(19, -399),
(19, -296),
(19, -244),
(19, -243),
(19, -242),
(19, -234),
(20, 0),
(22, 231),
(22, 234),
(22, 238),
(22, 242),
(22, 243),
(22, 244),
(22, 296),
(22, 399),
(22, 400),
(23, -463),
(23, -462),
(23, -433),
(23, -432),
(23, -431),
(23, -430),
(23, -429),
(23, -427),
(23, -400),
(23, -399),
(23, -296),
(23, -244),
(23, -243),
(23, -242),
(23, -238),
(23, -234),
(25, 294),
(26, -463),
(26, -462),
(26, -433),
(26, -432),
(26, -431),
(26, -430),
(26, -429),
(26, -427),
(26, -400),
(26, -399),
(26, -296),
(26, -244),
(26, -243),
(26, -242),
(26, -238),
(26, -234),
(27, 325),
(28, 310),
(29, 302),
(30, 410),
(31, 309),
(32, 309),
(33, 307),
(34, 326),
(35, 306),
(36, 304),
(37, 311),
(38, 300),
(39, 301),
(40, 313),
(41, 324),
(44, 312),
(45, 303),
(47, 231),
(47, 234),
(47, 242),
(47, 243),
(47, 244),
(47, 296),
(47, 399),
(47, 400),
(48, 418),
(49, 417),
(52, 416),
(56, 305),
(57, 238),
(57, 427),
(57, 429),
(57, 430),
(57, 431),
(57, 432),
(57, 433),
(57, 462),
(57, 463),
(58, 427),
(58, 429),
(58, 430),
(58, 431),
(58, 432),
(58, 433),
(58, 462),
(58, 463),
(61, 443),
(62, 231),
(62, 234),
(62, 242),
(62, 243),
(62, 244),
(62, 296),
(62, 399),
(62, 400),
(63, 0),
(64, 447),
(65, 427),
(65, 429),
(65, 430),
(65, 431),
(65, 432),
(65, 433),
(65, 462),
(65, 463),
(68, 243),
(69, 201),
(69, 459),
(70, 285),
(70, 316),
(71, 285),
(71, 316),
(72, 285),
(72, 316),
(73, 285),
(73, 316),
(74, 285),
(74, 316),
(75, 285),
(75, 316),
(76, 285),
(76, 316),
(77, 0),
(78, 0),
(79, 0),
(84, 467),
(86, 0),
(87, 0),
(88, 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_newsfeeds`
--

DROP TABLE IF EXISTS `m5jbw_newsfeeds`;
CREATE TABLE IF NOT EXISTS `m5jbw_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `m5jbw_newsfeeds`
--

INSERT INTO `m5jbw_newsfeeds` (`catid`, `id`, `name`, `alias`, `link`, `filename`, `published`, `numarticles`, `cache_time`, `checked_out`, `checked_out_time`, `ordering`, `rtl`, `access`, `language`, `params`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `xreference`, `publish_up`, `publish_down`) VALUES
(17, 1, 'Annonces Joomla!', 'annonces-joomla', 'http://www.joomla.org/announcements.feed?type=rss', NULL, 1, 5, 3600, 0, '0000-00-00 00:00:00', 1, 1, 1, 'fr-FR', '{"show_feed_image":"","show_feed_description":"","show_item_description":"","feed_character_count":"0","newsfeed_layout":"","feed_display_order":""}', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","rights":""}', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 2, 'Nouvelles Extensions Joomla!', 'nouvelles-extensions-joomla', 'http://feeds.joomla.org/JoomlaExtensions', NULL, 1, 5, 3600, 0, '0000-00-00 00:00:00', 4, 0, 1, 'fr-FR', '{"show_feed_image":"","show_feed_description":"","show_item_description":"","feed_character_count":"0"}', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 3, 'Informations de sécurité Joomla!', 'informations-de-securite-joomla', 'http://feeds.joomla.org/JoomlaSecurityNews', NULL, 1, 5, 3600, 0, '0000-00-00 00:00:00', 2, 0, 1, 'fr-FR', '{"show_feed_image":"","show_feed_description":"","show_item_description":"","feed_character_count":"0"}', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 4, 'Joomla! Connect', 'joomla-connect', 'http://feeds.joomla.org/JoomlaConnect', NULL, 1, 5, 3600, 0, '0000-00-00 00:00:00', 3, 0, 1, 'fr-FR', '{"show_feed_image":"","show_feed_description":"","show_item_description":"","feed_character_count":"0"}', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_overrider`
--

DROP TABLE IF EXISTS `m5jbw_overrider`;
CREATE TABLE IF NOT EXISTS `m5jbw_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_overrider`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_redirect_links`
--

DROP TABLE IF EXISTS `m5jbw_redirect_links`;
CREATE TABLE IF NOT EXISTS `m5jbw_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) NOT NULL,
  `new_url` varchar(255) NOT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `m5jbw_redirect_links`
--

INSERT INTO `m5jbw_redirect_links` (`id`, `old_url`, `new_url`, `referer`, `comment`, `hits`, `published`, `created_date`, `modified_date`) VALUES
(1, 'http://localhost/kochk_project/index.php?option=com_mediamallfactory&view=media&media=&Itemid=478', '', 'http://localhost/kochk_project/index.php?option=com_users&view=login', '', 1, 0, '2013-09-09 20:39:46', '0000-00-00 00:00:00'),
(2, 'http://localhost/kochk_project/index.php?option=com_mediamallfactory&view=media&media=1&Itemid=478', '', '', '', 1, 0, '2013-09-09 20:40:02', '0000-00-00 00:00:00'),
(3, 'http://localhost/kochk_project/index.php?option=com_mediamallfactory&view=media&media_id=&Itemid=478', '', 'http://localhost/kochk_project/index.php?option=com_users&view=login', '', 1, 0, '2013-09-09 20:41:07', '0000-00-00 00:00:00'),
(4, 'http://localhost/kochk_project/index.php?option=com_mediamallfactory&view=registration', '', '', '', 2, 0, '2013-09-12 19:06:40', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_schemas`
--

DROP TABLE IF EXISTS `m5jbw_schemas`;
CREATE TABLE IF NOT EXISTS `m5jbw_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_schemas`
--

INSERT INTO `m5jbw_schemas` (`extension_id`, `version_id`) VALUES
(700, '2.5.14'),
(10007, '1.0.0');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_session`
--

DROP TABLE IF EXISTS `m5jbw_session`;
CREATE TABLE IF NOT EXISTS `m5jbw_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  `usertype` varchar(50) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_session`
--

INSERT INTO `m5jbw_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`, `usertype`) VALUES
('deebcb103b2e8ae32ffd7d9900b7b729', 1, 0, '1379197167', '__default|a:8:{s:22:"session.client.browser";s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36";s:15:"session.counter";i:27;s:8:"registry";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":3:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:0:"";}s:13:"com_installer";O:8:"stdClass":4:{s:7:"message";s:0:"";s:17:"extension_message";s:0:"";s:7:"install";O:8:"stdClass":1:{s:17:"install_directory";s:23:"C:\\xampp\\htdocs\\kiosque";}s:12:"redirect_url";N;}s:13:"com_templates";O:8:"stdClass":1:{s:6:"styles";O:8:"stdClass":1:{s:10:"limitstart";i:0;}}}}s:4:"user";O:5:"JUser":25:{s:9:"\0*\0isRoot";b:1;s:2:"id";s:3:"342";s:4:"name";s:17:"Super Utilisateur";s:8:"username";s:9:"behappy78";s:5:"email";s:22:"mehdi.louati@gmail.com";s:8:"password";s:65:"76219c79f787adcad8ba8ffd1f5ff844:HdR0pcOl2uFKNDWb17U6WG4tzAz29c60";s:14:"password_clear";s:0:"";s:8:"usertype";s:10:"deprecated";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"1";s:12:"registerDate";s:19:"2013-09-05 14:31:42";s:13:"lastvisitDate";s:19:"2013-09-14 20:57:35";s:10:"activation";s:1:"0";s:6:"params";s:0:"";s:6:"groups";a:1:{i:8;s:1:"8";}s:5:"guest";i:0;s:13:"lastResetTime";s:19:"0000-00-00 00:00:00";s:10:"resetCount";s:1:"0";s:10:"\0*\0_params";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":0:{}}s:14:"\0*\0_authGroups";a:2:{i:0;i:1;i:1;i:8;}s:14:"\0*\0_authLevels";a:4:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;}s:15:"\0*\0_authActions";N;s:12:"\0*\0_errorMsg";N;s:10:"\0*\0_errors";a:0:{}s:3:"aid";i:0;}s:13:"session.token";s:32:"8e2c281cce465271edf54b469830b7d5";s:19:"session.timer.start";i:1379195954;s:18:"session.timer.last";i:1379197165;s:17:"session.timer.now";i:1379197166;}', 342, 'behappy78', ''),
('02c1618de720c4a5bb0e787843f01434', 0, 1, '1379197179', '__default|a:7:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1379197178;s:18:"session.timer.last";i:1379197178;s:17:"session.timer.now";i:1379197178;s:22:"session.client.browser";s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36";s:8:"registry";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":2:{s:6:"global";O:8:"stdClass":1:{s:4:"list";O:8:"stdClass":1:{s:5:"limit";i:10;}}s:28:"com_mediamallfactoryfrontend";O:8:"stdClass":1:{s:4:"list";O:8:"stdClass":1:{s:8:"ordercol";N;}}}}s:4:"user";O:5:"JUser":25:{s:9:"\0*\0isRoot";N;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:0:{}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\0*\0_params";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":0:{}}s:14:"\0*\0_authGroups";N;s:14:"\0*\0_authLevels";a:2:{i:0;i:1;i:1;i:1;}s:15:"\0*\0_authActions";N;s:12:"\0*\0_errorMsg";N;s:10:"\0*\0_errors";a:0:{}s:3:"aid";i:0;}}', 0, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_template_styles`
--

DROP TABLE IF EXISTS `m5jbw_template_styles`;
CREATE TABLE IF NOT EXISTS `m5jbw_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=116 ;

--
-- Contenu de la table `m5jbw_template_styles`
--

INSERT INTO `m5jbw_template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES
(2, 'bluestork', 1, '1', 'Bluestork - Défault', '{"useRoundedCorners":"1","showSiteName":"0"}'),
(3, 'atomic', 0, '0', 'Atomic - Défault', '{}'),
(4, 'beez_20', 0, '0', 'Beez2 - Défault', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/joomla_black.gif","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","templatecolor":"personal","html5":"0"}'),
(5, 'hathor', 1, '0', 'Hathor - Défault', '{"showSiteName":"0","colourChoice":"","boldText":"0"}'),
(6, 'beez5', 0, '0', 'Beez5 - Défault', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/sampledata\\/fruitshop\\/fruits.gif","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","html5":"0"}'),
(114, 'beez_20', 0, '0', 'Beez2 - Parks Site', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"","sitetitle":"Australian Parks","sitedescription":"Parks Sample Site","navposition":"center","templatecolor":"nature"}'),
(115, 'kiosque', 0, '1', 'Kiosque - Par défaut', '{}');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_updates`
--

DROP TABLE IF EXISTS `m5jbw_updates`;
CREATE TABLE IF NOT EXISTS `m5jbw_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `categoryid` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(10) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  PRIMARY KEY (`update_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Available Updates' AUTO_INCREMENT=62 ;

--
-- Contenu de la table `m5jbw_updates`
--

INSERT INTO `m5jbw_updates` (`update_id`, `update_site_id`, `extension_id`, `categoryid`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`) VALUES
(1, 3, 0, 0, 'Armenian', '', 'pkg_hy-AM', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/hy-AM_details.xml', ''),
(2, 3, 0, 0, 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/id-ID_details.xml', ''),
(3, 3, 0, 0, 'Danish', '', 'pkg_da-DK', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/da-DK_details.xml', ''),
(4, 3, 0, 0, 'Khmer', '', 'pkg_km-KH', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/km-KH_details.xml', ''),
(5, 3, 0, 0, 'Swedish', '', 'pkg_sv-SE', 'package', '', 0, '2.5.10.1', '', 'http://update.joomla.org/language/details/sv-SE_details.xml', ''),
(6, 3, 0, 0, 'Hungarian', '', 'pkg_hu-HU', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/hu-HU_details.xml', ''),
(7, 3, 0, 0, 'Bulgarian', '', 'pkg_bg-BG', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/bg-BG_details.xml', ''),
(8, 3, 0, 0, 'Italian', '', 'pkg_it-IT', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/it-IT_details.xml', ''),
(9, 3, 0, 0, 'Spanish', '', 'pkg_es-ES', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/es-ES_details.xml', ''),
(10, 3, 0, 0, 'Dutch', '', 'pkg_nl-NL', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/nl-NL_details.xml', ''),
(11, 3, 0, 0, 'Turkish', '', 'pkg_tr-TR', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/tr-TR_details.xml', ''),
(12, 3, 0, 0, 'Ukrainian', '', 'pkg_uk-UA', 'package', '', 0, '2.5.13.11', '', 'http://update.joomla.org/language/details/uk-UA_details.xml', ''),
(13, 3, 0, 0, 'Slovak', '', 'pkg_sk-SK', 'package', '', 0, '2.5.14.2', '', 'http://update.joomla.org/language/details/sk-SK_details.xml', ''),
(14, 3, 0, 0, 'Belarusian', '', 'pkg_be-BY', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/be-BY_details.xml', ''),
(15, 3, 0, 0, 'Latvian', '', 'pkg_lv-LV', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/lv-LV_details.xml', ''),
(16, 3, 0, 0, 'Estonian', '', 'pkg_et-EE', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/et-EE_details.xml', ''),
(17, 3, 0, 0, 'Romanian', '', 'pkg_ro-RO', 'package', '', 0, '2.5.11.1', '', 'http://update.joomla.org/language/details/ro-RO_details.xml', ''),
(18, 3, 0, 0, 'Flemish', '', 'pkg_nl-BE', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/nl-BE_details.xml', ''),
(19, 3, 0, 0, 'Macedonian', '', 'pkg_mk-MK', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/mk-MK_details.xml', ''),
(20, 3, 0, 0, 'Japanese', '', 'pkg_ja-JP', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/ja-JP_details.xml', ''),
(21, 3, 0, 0, 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/sr-YU_details.xml', ''),
(22, 3, 0, 0, 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/ar-AA_details.xml', ''),
(23, 3, 0, 0, 'German', '', 'pkg_de-DE', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/de-DE_details.xml', ''),
(24, 3, 0, 0, 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', 0, '2.5.11.1', '', 'http://update.joomla.org/language/details/nb-NO_details.xml', ''),
(25, 3, 0, 0, 'English AU', '', 'pkg_en-AU', 'package', '', 0, '2.5.10.1', '', 'http://update.joomla.org/language/details/en-AU_details.xml', ''),
(26, 3, 0, 0, 'English US', '', 'pkg_en-US', 'package', '', 0, '2.5.10.1', '', 'http://update.joomla.org/language/details/en-US_details.xml', ''),
(27, 3, 0, 0, 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/sr-RS_details.xml', ''),
(28, 3, 0, 0, 'Lithuanian', '', 'pkg_lt-LT', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/lt-LT_details.xml', ''),
(29, 3, 0, 0, 'Albanian', '', 'pkg_sq-AL', 'package', '', 0, '2.5.1.5', '', 'http://update.joomla.org/language/details/sq-AL_details.xml', ''),
(30, 3, 0, 0, 'Czech', '', 'pkg_cs-CZ', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/cs-CZ_details.xml', ''),
(31, 3, 0, 0, 'Persian', '', 'pkg_fa-IR', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/fa-IR_details.xml', ''),
(32, 3, 0, 0, 'Galician', '', 'pkg_gl-ES', 'package', '', 0, '2.5.7.4', '', 'http://update.joomla.org/language/details/gl-ES_details.xml', ''),
(33, 3, 0, 0, 'Polish', '', 'pkg_pl-PL', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/pl-PL_details.xml', ''),
(34, 3, 0, 0, 'Syriac', '', 'pkg_sy-IQ', 'package', '', 0, '2.5.10.1', '', 'http://update.joomla.org/language/details/sy-IQ_details.xml', ''),
(35, 3, 0, 0, 'Portuguese', '', 'pkg_pt-PT', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/pt-PT_details.xml', ''),
(36, 3, 0, 0, 'Russian', '', 'pkg_ru-RU', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/ru-RU_details.xml', ''),
(37, 3, 0, 0, 'Hebrew', '', 'pkg_he-IL', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/he-IL_details.xml', ''),
(38, 3, 0, 0, 'Catalan', '', 'pkg_ca-ES', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/ca-ES_details.xml', ''),
(39, 3, 0, 0, 'Laotian', '', 'pkg_lo-LA', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/lo-LA_details.xml', ''),
(40, 3, 0, 0, 'Afrikaans', '', 'pkg_af-ZA', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/af-ZA_details.xml', ''),
(41, 3, 0, 0, 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/zh-CN_details.xml', ''),
(42, 3, 0, 0, 'Greek', '', 'pkg_el-GR', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/el-GR_details.xml', ''),
(43, 3, 0, 0, 'Esperanto', '', 'pkg_eo-XX', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/eo-XX_details.xml', ''),
(44, 3, 0, 0, 'Finnish', '', 'pkg_fi-FI', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/fi-FI_details.xml', ''),
(45, 3, 0, 0, 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', 0, '2.5.9.1', '', 'http://update.joomla.org/language/details/pt-BR_details.xml', ''),
(46, 3, 0, 0, 'Chinese Traditional', '', 'pkg_zh-TW', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/zh-TW_details.xml', ''),
(47, 3, 0, 0, 'Vietnamese', '', 'pkg_vi-VN', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/vi-VN_details.xml', ''),
(48, 3, 0, 0, 'Kurdish Sorani', '', 'pkg_ckb-IQ', 'package', '', 0, '2.5.9.1', '', 'http://update.joomla.org/language/details/ckb-IQ_details.xml', ''),
(49, 3, 0, 0, 'Bosnian', '', 'pkg_bs-BA', 'package', '', 0, '2.5.11.1', '', 'http://update.joomla.org/language/details/bs-BA_details.xml', ''),
(50, 3, 0, 0, 'Croatian', '', 'pkg_hr-HR', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/hr-HR_details.xml', ''),
(51, 3, 0, 0, 'Azeri', '', 'pkg_az-AZ', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/az-AZ_details.xml', ''),
(52, 3, 0, 0, 'Norwegian Nynorsk', '', 'pkg_nn-NO', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/nn-NO_details.xml', ''),
(53, 3, 0, 0, 'Tamil India', '', 'pkg_ta-IN', 'package', '', 0, '2.5.14.2', '', 'http://update.joomla.org/language/details/ta-IN_details.xml', ''),
(54, 3, 0, 0, 'Scottish Gaelic', '', 'pkg_gd-GB', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/gd-GB_details.xml', ''),
(55, 3, 0, 0, 'Thai', '', 'pkg_th-TH', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/th-TH_details.xml', ''),
(56, 3, 0, 0, 'Basque', '', 'pkg_eu-ES', 'package', '', 0, '1.7.0.1', '', 'http://update.joomla.org/language/details/eu-ES_details.xml', ''),
(57, 3, 0, 0, 'Uyghur', '', 'pkg_ug-CN', 'package', '', 0, '2.5.7.2', '', 'http://update.joomla.org/language/details/ug-CN_details.xml', ''),
(58, 3, 0, 0, 'Korean', '', 'pkg_ko-KR', 'package', '', 0, '2.5.11.1', '', 'http://update.joomla.org/language/details/ko-KR_details.xml', ''),
(59, 3, 0, 0, 'Hindi', '', 'pkg_hi-IN', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/hi-IN_details.xml', ''),
(60, 3, 0, 0, 'Welsh', '', 'pkg_cy-GB', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/cy-GB_details.xml', ''),
(61, 3, 0, 0, 'Swahili', '', 'pkg_sw-KE', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/sw-KE_details.xml', '');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_update_categories`
--

DROP TABLE IF EXISTS `m5jbw_update_categories`;
CREATE TABLE IF NOT EXISTS `m5jbw_update_categories` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT '',
  `description` text NOT NULL,
  `parent` int(11) DEFAULT '0',
  `updatesite` int(11) DEFAULT '0',
  PRIMARY KEY (`categoryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Update Categories' AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_update_categories`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_update_sites`
--

DROP TABLE IF EXISTS `m5jbw_update_sites`;
CREATE TABLE IF NOT EXISTS `m5jbw_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`update_site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Update Sites' AUTO_INCREMENT=4 ;

--
-- Contenu de la table `m5jbw_update_sites`
--

INSERT INTO `m5jbw_update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`) VALUES
(1, 'Joomla Core', 'collection', 'http://update.joomla.org/core/list.xml', 1, 1379195986),
(2, 'Joomla Extension Directory', 'collection', 'http://update.joomla.org/jed/list.xml', 1, 1379195986),
(3, 'Accredited Joomla! Translations', 'collection', 'http://update.joomla.org/language/translationlist.xml', 1, 1379195986);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_update_sites_extensions`
--

DROP TABLE IF EXISTS `m5jbw_update_sites_extensions`;
CREATE TABLE IF NOT EXISTS `m5jbw_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

--
-- Contenu de la table `m5jbw_update_sites_extensions`
--

INSERT INTO `m5jbw_update_sites_extensions` (`update_site_id`, `extension_id`) VALUES
(1, 700),
(2, 700),
(3, 600),
(4, 602);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_usergroups`
--

DROP TABLE IF EXISTS `m5jbw_usergroups`;
CREATE TABLE IF NOT EXISTS `m5jbw_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Contenu de la table `m5jbw_usergroups`
--

INSERT INTO `m5jbw_usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES
(1, 0, 1, 20, 'Public'),
(2, 1, 6, 17, 'Enregistré'),
(3, 2, 7, 14, 'Auteur'),
(4, 3, 8, 11, 'Rédacteur'),
(5, 4, 9, 10, 'Éditeur'),
(6, 1, 2, 5, 'Gestionnaire'),
(7, 6, 3, 4, 'Administrateur'),
(8, 1, 18, 19, 'Super Utilisateur'),
(12, 2, 15, 16, 'Client (Exemple)'),
(10, 3, 12, 13, 'Fournisseur (Exemple)');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_users`
--

DROP TABLE IF EXISTS `m5jbw_users`;
CREATE TABLE IF NOT EXISTS `m5jbw_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=352 ;

--
-- Contenu de la table `m5jbw_users`
--

INSERT INTO `m5jbw_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`) VALUES
(342, 'Super Utilisateur', 'behappy78', 'mehdi.louati@gmail.com', '76219c79f787adcad8ba8ffd1f5ff844:HdR0pcOl2uFKNDWb17U6WG4tzAz29c60', 'deprecated', 0, 1, '2013-09-05 14:31:42', '2013-09-14 21:59:14', '0', '', '0000-00-00 00:00:00', 0),
(343, 'Feki Hichem', 'hichem', 'feki.hichem@gmail.com', '257069570bc8395ccfec71d16081080a:ewNQAR79xOJesk1DluxysRjY5PKsqsyw', '', 0, 0, '2013-09-05 23:18:17', '2013-09-14 20:15:53', '', '{}', '0000-00-00 00:00:00', 0),
(344, 'Eya Feki', 'eya', 'eya@eyasoft.net', '1ad000e7a4a271a5c1250d40bfbdf979:txO9Qvgihhhnu1gkyA60RLtQAUX3G2eQ', '', 0, 0, '2013-09-09 16:56:43', '2013-09-09 20:41:50', '', '{}', '0000-00-00 00:00:00', 0),
(348, 'Chaima', 'chaima', 'hichem@eyasoft.net', 'bbe693f4856f87d9fc02086290d6c6fb:tU7CCSB6wYP6xRE7fqskCDHEDf47dauV', '', 0, 0, '2013-09-10 17:23:48', '2013-09-10 18:08:17', '', '{}', '0000-00-00 00:00:00', 0),
(349, 'Emna', 'emna', 'emna@me.net', '7466095cd361088f95548cc1525dce45:79WsjHZqGAdeXU8ogm9LuEbtm9fnYG4P', '', 0, 0, '2013-09-14 20:29:06', '2013-09-14 20:29:21', '', '{}', '0000-00-00 00:00:00', 0),
(351, 'Souheila Chtourou', 'souheila', 'souhe1ila@me.net', '000e59a03a690d846caf76f2e6b5d6ab:dqfHj9ZkvCKrwxC2zegf365SObEvnStm', '', 0, 0, '2013-09-14 20:34:43', '2013-09-14 20:38:49', '', '{}', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_user_notes`
--

DROP TABLE IF EXISTS `m5jbw_user_notes`;
CREATE TABLE IF NOT EXISTS `m5jbw_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `m5jbw_user_notes`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_user_profiles`
--

DROP TABLE IF EXISTS `m5jbw_user_profiles`;
CREATE TABLE IF NOT EXISTS `m5jbw_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';

--
-- Contenu de la table `m5jbw_user_profiles`
--


-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_user_usergroup_map`
--

DROP TABLE IF EXISTS `m5jbw_user_usergroup_map`;
CREATE TABLE IF NOT EXISTS `m5jbw_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `m5jbw_user_usergroup_map`
--

INSERT INTO `m5jbw_user_usergroup_map` (`user_id`, `group_id`) VALUES
(342, 8),
(343, 2),
(344, 2),
(345, 2),
(346, 2),
(347, 2),
(348, 2),
(349, 1),
(349, 2),
(351, 1),
(351, 2);

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_viewlevels`
--

DROP TABLE IF EXISTS `m5jbw_viewlevels`;
CREATE TABLE IF NOT EXISTS `m5jbw_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `m5jbw_viewlevels`
--

INSERT INTO `m5jbw_viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES
(1, 'Accès Public', 0, '[1]'),
(2, 'Accès Enregistré', 1, '[6,2,8]'),
(3, 'Accès Spécial', 2, '[6,3,8]'),
(4, 'Niveau d''accès personnalisé (Exemple)', 3, '[6,3,12]');

-- --------------------------------------------------------

--
-- Structure de la table `m5jbw_weblinks`
--

DROP TABLE IF EXISTS `m5jbw_weblinks`;
CREATE TABLE IF NOT EXISTS `m5jbw_weblinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `access` int(11) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if link is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `m5jbw_weblinks`
--

INSERT INTO `m5jbw_weblinks` (`id`, `catid`, `sid`, `title`, `alias`, `url`, `description`, `date`, `hits`, `state`, `checked_out`, `checked_out_time`, `ordering`, `archived`, `approved`, `access`, `params`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`) VALUES
(1, 32, 0, 'Joomla!', 'joomla', 'http://www.joomla.org', '<p>Page d''accueil du site officiel de Joomla!</p>', '0000-00-00 00:00:00', 3, 1, 0, '0000-00-00 00:00:00', 1, 0, 1, 1, '{"target":"0","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 33, 0, 'php.net', 'php', 'http://www.php.net', '<p>Site présentant le langage de programmation PHP utilisé par Joomla!</p>', '0000-00-00 00:00:00', 6, 1, 0, '0000-00-00 00:00:00', 1, 0, 1, 1, '{"target":"","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 33, 0, 'MySQL', 'mysql', 'http://www.mysql.com', '<p>MySQL est le format de base de données utilisé par Joomla!</p>', '0000-00-00 00:00:00', 1, 1, 0, '0000-00-00 00:00:00', 2, 0, 1, 1, '{"target":"","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 32, 0, 'OpenSourceMatters', 'opensourcematters', 'http://www.opensourcematters.org', '<p>Page d''accueil d''OpenSourceMatters</p>', '0000-00-00 00:00:00', 11, 1, 0, '0000-00-00 00:00:00', 3, 0, 1, 1, '{"target":"0","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 32, 0, 'Forums Joomla!', 'forums-joomla', 'http://forum.joomla.org', '<p>Les forums Joomla!</p>', '0000-00-00 00:00:00', 4, 1, 0, '0000-00-00 00:00:00', 2, 0, 1, 1, '{"target":"0","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 33, 0, 'Rapport d''activité de Joomla! Ohloh', 'rapport-activite-joomla-ohloh', 'http://www.ohloh.net/projects/20', '<p>Objectif de rapports sur l''activité de développement Joomla! Ohloh et de ses développeurs stars.</p>', '0000-00-00 00:00:00', 1, 1, 0, '0000-00-00 00:00:00', 3, 0, 1, 1, '{"target":"0","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 31, 0, 'Parc national Baw Baw', 'parc-national-baw-baw', 'http://www.parkweb.vic.gov.au/1park_display.cfm?park=44', '<p>Liens sur  le parc national BAW BAW des Alpes australiennes, les fonctions de la végétation alpine, de belles vues et, les possibilités de randonnée, de ski et autres activités de plein air.</p>', '0000-00-00 00:00:00', 0, 1, 0, '0000-00-00 00:00:00', 1, 0, 1, 1, '{"target":"0","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 31, 0, 'Kakadu', 'kakadu', 'http://www.environment.gov.au/parks/kakadu/index.html', '<p style="text-align: justify;">Kakadu est connu à la fois pour son patrimoine culturel et ses caractéristiques naturelles. Il  fait partie d''un petit nombre de lieux cités comme des lieux  patrimoniaux du monde pour plusieurs raisons. Une des principales est l''art rupestre qu''il est possible d''admirer.</p>', '0000-00-00 00:00:00', 0, 1, 0, '0000-00-00 00:00:00', 2, 0, 1, 1, '{"target":"0","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 31, 0, 'Pulu Keeling', 'pulu-keeling', 'http://www.environment.gov.au/parks/cocos/index.html', '<p>Situé sur un atoll à 2000 kilomètres au nord de Perth, Pulu Keeling est le plus petit parc national d''Australie.</p>', '0000-00-00 00:00:00', 0, 1, 0, '0000-00-00 00:00:00', 3, 0, 1, 1, '{"target":"0","count_clicks":""}', 'fr-FR', '2012-01-01 00:00:01', 342, '', '2012-01-01 00:00:01', 42, '', '', '{"robots":"","author":"","rights":""}', 0, '', '2010-07-10 23:44:03', '0000-00-00 00:00:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
